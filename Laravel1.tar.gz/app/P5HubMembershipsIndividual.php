<?php
namespace App;

use Illuminate\Database\Eloquent\Model;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\Traits\FilterByUser;

/**
 * Class P5HubMembershipsIndividual
 *
 * @package App
 * @property string $hub
 * @property string $individual
 * @property string $member_type
 * @property string $linked_hub_membership_status
 * @property string $linked_membership_class
 * @property string $membership_number
 * @property string $membership_start
 * @property string $membership_end
 * @property string $billing_fee
 * @property string $billing_period
 * @property string $billing_payment_method
 * @property string $on_group_facebook
 * @property string $on_group_mailer
 * @property string $on_group_meetup
 * @property string $on_signup_sheet
 * @property text $notes
 * @property string $dq
 * @property string $created_by
*/
class P5HubMembershipsIndividual extends Model
{
    use SoftDeletes, FilterByUser;

    protected $fillable = ['membership_number', 'membership_start', 'membership_end', 'billing_fee', 'billing_period', 'billing_payment_method', 'on_group_facebook', 'on_group_mailer', 'on_group_meetup', 'on_signup_sheet', 'notes', 'dq', 'hub_id', 'individual_id', 'member_type_id', 'linked_hub_membership_status_id', 'linked_membership_class_id', 'created_by_id'];
    public static $searchable = [
    ];
    
    public static function boot()
    {
        parent::boot();

        P5HubMembershipsIndividual::observe(new \App\Observers\UserActionsObserver);
    }

    /**
     * Set to null if empty
     * @param $input
     */
    public function setHubIdAttribute($input)
    {
        $this->attributes['hub_id'] = $input ? $input : null;
    }

    /**
     * Set to null if empty
     * @param $input
     */
    public function setIndividualIdAttribute($input)
    {
        $this->attributes['individual_id'] = $input ? $input : null;
    }

    /**
     * Set to null if empty
     * @param $input
     */
    public function setMemberTypeIdAttribute($input)
    {
        $this->attributes['member_type_id'] = $input ? $input : null;
    }

    /**
     * Set to null if empty
     * @param $input
     */
    public function setLinkedHubMembershipStatusIdAttribute($input)
    {
        $this->attributes['linked_hub_membership_status_id'] = $input ? $input : null;
    }

    /**
     * Set to null if empty
     * @param $input
     */
    public function setLinkedMembershipClassIdAttribute($input)
    {
        $this->attributes['linked_membership_class_id'] = $input ? $input : null;
    }

    /**
     * Set attribute to date format
     * @param $input
     */
    public function setMembershipStartAttribute($input)
    {
        if ($input != null && $input != '') {
            $this->attributes['membership_start'] = Carbon::createFromFormat(config('app.date_format'), $input)->format('Y-m-d');
        } else {
            $this->attributes['membership_start'] = null;
        }
    }

    /**
     * Get attribute from date format
     * @param $input
     *
     * @return string
     */
    public function getMembershipStartAttribute($input)
    {
        $zeroDate = str_replace(['Y', 'm', 'd'], ['0000', '00', '00'], config('app.date_format'));

        if ($input != $zeroDate && $input != null) {
            return Carbon::createFromFormat('Y-m-d', $input)->format(config('app.date_format'));
        } else {
            return '';
        }
    }

    /**
     * Set attribute to date format
     * @param $input
     */
    public function setMembershipEndAttribute($input)
    {
        if ($input != null && $input != '') {
            $this->attributes['membership_end'] = Carbon::createFromFormat(config('app.date_format'), $input)->format('Y-m-d');
        } else {
            $this->attributes['membership_end'] = null;
        }
    }

    /**
     * Get attribute from date format
     * @param $input
     *
     * @return string
     */
    public function getMembershipEndAttribute($input)
    {
        $zeroDate = str_replace(['Y', 'm', 'd'], ['0000', '00', '00'], config('app.date_format'));

        if ($input != $zeroDate && $input != null) {
            return Carbon::createFromFormat('Y-m-d', $input)->format(config('app.date_format'));
        } else {
            return '';
        }
    }

    /**
     * Set to null if empty
     * @param $input
     */
    public function setCreatedByIdAttribute($input)
    {
        $this->attributes['created_by_id'] = $input ? $input : null;
    }
    
    public function hub()
    {
        return $this->belongsTo(P5Hub::class, 'hub_id')->withTrashed();
    }
    
    public function individual()
    {
        return $this->belongsTo(User::class, 'individual_id');
    }
    
    public function member_type()
    {
        return $this->belongsTo(P5HubMembershipType::class, 'member_type_id')->withTrashed();
    }
    
    public function linked_hub_membership_status()
    {
        return $this->belongsTo(P5HubMembershipsStatus::class, 'linked_hub_membership_status_id')->withTrashed();
    }
    
    public function linked_membership_class()
    {
        return $this->belongsTo(P5HubMembershipsClass::class, 'linked_membership_class_id')->withTrashed();
    }
    
    public function created_by()
    {
        return $this->belongsTo(User::class, 'created_by_id');
    }
    
}
