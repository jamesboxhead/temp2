<?php
namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * Class P5BusinessModel
 *
 * @package App
 * @property string $business_model
 * @property text $description
 * @property string $sort_code
*/
class P5BusinessModel extends Model
{
    use SoftDeletes;

    protected $fillable = ['business_model', 'description', 'sort_code'];
    public static $searchable = [
        'description',
    ];
    
    public static function boot()
    {
        parent::boot();

        P5BusinessModel::observe(new \App\Observers\UserActionsObserver);
    }
    
    public function p5_organisations() {
        return $this->hasMany(P5Organisation::class, 'business_model_id');
    }
}
