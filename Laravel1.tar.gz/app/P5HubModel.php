<?php
namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * Class P5HubModel
 *
 * @package App
 * @property string $hub_model
 * @property string $sort_code
 * @property string $dq
*/
class P5HubModel extends Model
{
    use SoftDeletes;

    protected $fillable = ['hub_model', 'sort_code', 'dq'];
    public static $searchable = [
    ];
    
    public static function boot()
    {
        parent::boot();

        P5HubModel::observe(new \App\Observers\UserActionsObserver);
    }
    
    public function p5_hubs() {
        return $this->hasMany(P5Hub::class, 'hub_model_id');
    }
}
