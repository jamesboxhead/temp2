<?php
namespace App;

use Illuminate\Database\Eloquent\Model;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\Traits\FilterByUser;

/**
 * Class P5Intake
 *
 * @package App
 * @property string $program
 * @property string $intake_group
 * @property string $start_date
 * @property string $end_date1
 * @property text $description
 * @property string $website
 * @property string $created_by
 * @property string $dq
*/
class P5Intake extends Model
{
    use SoftDeletes, FilterByUser;

    protected $fillable = ['intake_group', 'start_date', 'end_date1', 'description', 'website', 'dq', 'program_id', 'created_by_id'];
    public static $searchable = [
    ];
    
    public static function boot()
    {
        parent::boot();

        P5Intake::observe(new \App\Observers\UserActionsObserver);
    }

    /**
     * Set to null if empty
     * @param $input
     */
    public function setProgramIdAttribute($input)
    {
        $this->attributes['program_id'] = $input ? $input : null;
    }

    /**
     * Set attribute to date format
     * @param $input
     */
    public function setStartDateAttribute($input)
    {
        if ($input != null && $input != '') {
            $this->attributes['start_date'] = Carbon::createFromFormat(config('app.date_format'), $input)->format('Y-m-d');
        } else {
            $this->attributes['start_date'] = null;
        }
    }

    /**
     * Get attribute from date format
     * @param $input
     *
     * @return string
     */
    public function getStartDateAttribute($input)
    {
        $zeroDate = str_replace(['Y', 'm', 'd'], ['0000', '00', '00'], config('app.date_format'));

        if ($input != $zeroDate && $input != null) {
            return Carbon::createFromFormat('Y-m-d', $input)->format(config('app.date_format'));
        } else {
            return '';
        }
    }

    /**
     * Set attribute to date format
     * @param $input
     */
    public function setEndDate1Attribute($input)
    {
        if ($input != null && $input != '') {
            $this->attributes['end_date1'] = Carbon::createFromFormat(config('app.date_format'), $input)->format('Y-m-d');
        } else {
            $this->attributes['end_date1'] = null;
        }
    }

    /**
     * Get attribute from date format
     * @param $input
     *
     * @return string
     */
    public function getEndDate1Attribute($input)
    {
        $zeroDate = str_replace(['Y', 'm', 'd'], ['0000', '00', '00'], config('app.date_format'));

        if ($input != $zeroDate && $input != null) {
            return Carbon::createFromFormat('Y-m-d', $input)->format(config('app.date_format'));
        } else {
            return '';
        }
    }

    /**
     * Set to null if empty
     * @param $input
     */
    public function setCreatedByIdAttribute($input)
    {
        $this->attributes['created_by_id'] = $input ? $input : null;
    }
    
    public function program()
    {
        return $this->belongsTo(P5Program::class, 'program_id')->withTrashed();
    }
    
    public function org_link()
    {
        return $this->belongsToMany(P5Organisation::class, 'p5_intake_p5_organisation')->withTrashed();
    }
    
    public function users_linked()
    {
        return $this->belongsToMany(User::class, 'p5_intake_user');
    }
    
    public function created_by()
    {
        return $this->belongsTo(User::class, 'created_by_id');
    }
    
}
