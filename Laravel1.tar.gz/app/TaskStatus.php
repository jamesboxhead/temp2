<?php
namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * Class TaskStatus
 *
 * @package App
 * @property string $name
 * @property string $sort_code
*/
class TaskStatus extends Model
{
    protected $fillable = ['name', 'sort_code'];
    public static $searchable = [
    ];
    
    public static function boot()
    {
        parent::boot();

        TaskStatus::observe(new \App\Observers\UserActionsObserver);
    }
    
}
