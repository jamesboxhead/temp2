<?php
namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * Class P5InvestmentSource
 *
 * @package App
 * @property string $investment_source_description
 * @property string $sort_code
*/
class P5InvestmentSource extends Model
{
    use SoftDeletes;

    protected $fillable = ['investment_source_description', 'sort_code'];
    public static $searchable = [
    ];
    
    public static function boot()
    {
        parent::boot();

        P5InvestmentSource::observe(new \App\Observers\UserActionsObserver);
    }
    
}
