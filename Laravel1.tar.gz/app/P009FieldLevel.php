<?php
namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * Class P009FieldLevel
 *
 * @package App
 * @property string $graph
 * @property integer $level
 * @property string $level_num_table
 * @property string $level_num_show_field
 * @property string $level_num_join_field
 * @property string $level_num_join_statement
 * @property string $level_num_method
 * @property string $level_num_groupby
*/
class P009FieldLevel extends Model
{
    use SoftDeletes;

    protected $fillable = ['level', 'level_num_table', 'level_num_show_field', 'level_num_join_field', 'level_num_join_statement', 'level_num_method', 'level_num_groupby', 'graph_id'];
    public static $searchable = [
    ];
    
    public static function boot()
    {
        parent::boot();

        P009FieldLevel::observe(new \App\Observers\UserActionsObserver);
    }

    /**
     * Set to null if empty
     * @param $input
     */
    public function setGraphIdAttribute($input)
    {
        $this->attributes['graph_id'] = $input ? $input : null;
    }

    /**
     * Set attribute to money format
     * @param $input
     */
    public function setLevelAttribute($input)
    {
        $this->attributes['level'] = $input ? $input : null;
    }
    
    public function graph()
    {
        return $this->belongsTo(P009Graph::class, 'graph_id')->withTrashed();
    }
    
}
