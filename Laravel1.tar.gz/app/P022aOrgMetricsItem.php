<?php
namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * Class P022aOrgMetricsItem
 *
 * @package App
 * @property string $metric_description
 * @property string $metric_display_format
 * @property string $metric_units
 * @property string $p022a_org_metric_group
 * @property text $notes
 * @property string $sort_order
*/
class P022aOrgMetricsItem extends Model
{
    use SoftDeletes;

    protected $fillable = ['metric_description', 'metric_display_format', 'metric_units', 'notes', 'sort_order', 'p022a_org_metric_group_id'];
    public static $searchable = [
    ];
    
    public static function boot()
    {
        parent::boot();

        P022aOrgMetricsItem::observe(new \App\Observers\UserActionsObserver);
    }

    /**
     * Set to null if empty
     * @param $input
     */
    public function setP022aOrgMetricGroupIdAttribute($input)
    {
        $this->attributes['p022a_org_metric_group_id'] = $input ? $input : null;
    }
    
    public function p022a_org_metric_group()
    {
        return $this->belongsTo(P022aOrgMetricsLookupGroup::class, 'p022a_org_metric_group_id')->withTrashed();
    }
    
}
