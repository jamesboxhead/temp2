<?php
namespace App;

use Illuminate\Database\Eloquent\Model;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\Traits\FilterByUser;

/**
 * Class P023DataSubmission
 *
 * @package App
 * @property string $submission_code
 * @property string $linked_p5_hubs
 * @property string $linked_p023_data_standards
 * @property string $data_element_as_at
 * @property string $data_element_x_text
 * @property string $data_element_x_date
 * @property integer $data_element_x_num
 * @property string $data_element_x_sort_order
 * @property string $data_element_y_text
 * @property string $data_element_y_date
 * @property integer $data_element_y_num
 * @property string $data_element_label
 * @property string $created_by
*/
class P023DataSubmission extends Model
{
    use SoftDeletes, FilterByUser;

    protected $fillable = ['submission_code', 'data_element_as_at', 'data_element_x_text', 'data_element_x_date', 'data_element_x_num', 'data_element_x_sort_order', 'data_element_y_text', 'data_element_y_date', 'data_element_y_num', 'data_element_label', 'linked_p5_hubs_id', 'linked_p023_data_standards_id', 'created_by_id'];
    public static $searchable = [
    ];
    
    public static function boot()
    {
        parent::boot();

        P023DataSubmission::observe(new \App\Observers\UserActionsObserver);
    }

    /**
     * Set to null if empty
     * @param $input
     */
    public function setLinkedP5HubsIdAttribute($input)
    {
        $this->attributes['linked_p5_hubs_id'] = $input ? $input : null;
    }

    /**
     * Set to null if empty
     * @param $input
     */
    public function setLinkedP023DataStandardsIdAttribute($input)
    {
        $this->attributes['linked_p023_data_standards_id'] = $input ? $input : null;
    }

    /**
     * Set attribute to date format
     * @param $input
     */
    public function setDataElementAsAtAttribute($input)
    {
        if ($input != null && $input != '') {
            $this->attributes['data_element_as_at'] = Carbon::createFromFormat(config('app.date_format'), $input)->format('Y-m-d');
        } else {
            $this->attributes['data_element_as_at'] = null;
        }
    }

    /**
     * Get attribute from date format
     * @param $input
     *
     * @return string
     */
    public function getDataElementAsAtAttribute($input)
    {
        $zeroDate = str_replace(['Y', 'm', 'd'], ['0000', '00', '00'], config('app.date_format'));

        if ($input != $zeroDate && $input != null) {
            return Carbon::createFromFormat('Y-m-d', $input)->format(config('app.date_format'));
        } else {
            return '';
        }
    }

    /**
     * Set attribute to date format
     * @param $input
     */
    public function setDataElementXDateAttribute($input)
    {
        if ($input != null && $input != '') {
            $this->attributes['data_element_x_date'] = Carbon::createFromFormat(config('app.date_format'), $input)->format('Y-m-d');
        } else {
            $this->attributes['data_element_x_date'] = null;
        }
    }

    /**
     * Get attribute from date format
     * @param $input
     *
     * @return string
     */
    public function getDataElementXDateAttribute($input)
    {
        $zeroDate = str_replace(['Y', 'm', 'd'], ['0000', '00', '00'], config('app.date_format'));

        if ($input != $zeroDate && $input != null) {
            return Carbon::createFromFormat('Y-m-d', $input)->format(config('app.date_format'));
        } else {
            return '';
        }
    }

    /**
     * Set attribute to money format
     * @param $input
     */
    public function setDataElementXNumAttribute($input)
    {
        $this->attributes['data_element_x_num'] = $input ? $input : null;
    }

    /**
     * Set attribute to date format
     * @param $input
     */
    public function setDataElementYDateAttribute($input)
    {
        if ($input != null && $input != '') {
            $this->attributes['data_element_y_date'] = Carbon::createFromFormat(config('app.date_format'), $input)->format('Y-m-d');
        } else {
            $this->attributes['data_element_y_date'] = null;
        }
    }

    /**
     * Get attribute from date format
     * @param $input
     *
     * @return string
     */
    public function getDataElementYDateAttribute($input)
    {
        $zeroDate = str_replace(['Y', 'm', 'd'], ['0000', '00', '00'], config('app.date_format'));

        if ($input != $zeroDate && $input != null) {
            return Carbon::createFromFormat('Y-m-d', $input)->format(config('app.date_format'));
        } else {
            return '';
        }
    }

    /**
     * Set attribute to money format
     * @param $input
     */
    public function setDataElementYNumAttribute($input)
    {
        $this->attributes['data_element_y_num'] = $input ? $input : null;
    }

    /**
     * Set to null if empty
     * @param $input
     */
    public function setCreatedByIdAttribute($input)
    {
        $this->attributes['created_by_id'] = $input ? $input : null;
    }
    
    public function linked_p5_hubs()
    {
        return $this->belongsTo(P5Hub::class, 'linked_p5_hubs_id')->withTrashed();
    }
    
    public function linked_p023_data_standards()
    {
        return $this->belongsTo(P023DataStandard::class, 'linked_p023_data_standards_id')->withTrashed();
    }
    
    public function created_by()
    {
        return $this->belongsTo(User::class, 'created_by_id');
    }
    
}
