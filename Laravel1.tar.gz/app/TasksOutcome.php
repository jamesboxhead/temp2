<?php
namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * Class TasksOutcome
 *
 * @package App
 * @property string $outcome
 * @property string $sort_code
*/
class TasksOutcome extends Model
{
    protected $fillable = ['outcome', 'sort_code'];
    public static $searchable = [
    ];
    
    public static function boot()
    {
        parent::boot();

        TasksOutcome::observe(new \App\Observers\UserActionsObserver);
    }
    
}
