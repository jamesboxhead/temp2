<?php
namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * Class P5OrgStatus
 *
 * @package App
 * @property string $org_status
 * @property string $sort_code
 * @property string $dq
*/
class P5OrgStatus extends Model
{
    use SoftDeletes;

    protected $fillable = ['org_status', 'sort_code', 'dq'];
    public static $searchable = [
    ];
    
    public static function boot()
    {
        parent::boot();

        P5OrgStatus::observe(new \App\Observers\UserActionsObserver);
    }
    
    public function p5_organisations() {
        return $this->hasMany(P5Organisation::class, 'org_status_id');
    }
}
