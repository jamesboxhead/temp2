<?php
namespace App;

use Illuminate\Database\Eloquent\Model;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\Traits\FilterByUser;

/**
 * Class P016Session
 *
 * @package App
 * @property string $linked_p5_hub
 * @property string $linked_session_status
 * @property string $short_description
 * @property text $session_long_description
 * @property string $session_pin
 * @property string $session_start
 * @property string $session_end
 * @property text $session_info
 * @property string $session_map_location
 * @property tinyInteger $offer_preso_email
 * @property string $url_presentation_to_send
 * @property string $created_by
 * @property tinyInteger $offer_email_survey_detail
 * @property tinyInteger $offer_hub_info
 * @property tinyInteger $offer_pass_on_email
 * @property tinyInteger $offer_voting
 * @property string $live_results_url
 * @property integer $voting_duration
 * @property string $voting_headline
 * @property text $voting_info_presented
 * @property text $voting_info_mobile
*/
class P016Session extends Model
{
    use SoftDeletes, FilterByUser;

    protected $fillable = ['short_description', 'session_long_description', 'session_pin', 'session_start', 'session_end', 'session_info', 'offer_preso_email', 'url_presentation_to_send', 'offer_email_survey_detail', 'offer_hub_info', 'offer_pass_on_email', 'offer_voting', 'live_results_url', 'voting_duration', 'voting_headline', 'voting_info_presented', 'voting_info_mobile', 'session_map_location_address', 'session_map_location_latitude', 'session_map_location_longitude', 'linked_p5_hub_id', 'linked_session_status_id', 'created_by_id'];
    public static $searchable = [
        'short_description',
        'session_long_description',
    ];
    
    public static function boot()
    {
        parent::boot();

        P016Session::observe(new \App\Observers\UserActionsObserver);
    }

    /**
     * Set to null if empty
     * @param $input
     */
    public function setLinkedP5HubIdAttribute($input)
    {
        $this->attributes['linked_p5_hub_id'] = $input ? $input : null;
    }

    /**
     * Set to null if empty
     * @param $input
     */
    public function setLinkedSessionStatusIdAttribute($input)
    {
        $this->attributes['linked_session_status_id'] = $input ? $input : null;
    }

    /**
     * Set attribute to date format
     * @param $input
     */
    public function setSessionStartAttribute($input)
    {
        if ($input != null && $input != '') {
            $this->attributes['session_start'] = Carbon::createFromFormat(config('app.date_format') . ' H:i:s', $input)->format('Y-m-d H:i:s');
        } else {
            $this->attributes['session_start'] = null;
        }
    }

    /**
     * Get attribute from date format
     * @param $input
     *
     * @return string
     */
    public function getSessionStartAttribute($input)
    {
        $zeroDate = str_replace(['Y', 'm', 'd'], ['0000', '00', '00'], config('app.date_format') . ' H:i:s');

        if ($input != $zeroDate && $input != null) {
            return Carbon::createFromFormat('Y-m-d H:i:s', $input)->format(config('app.date_format') . ' H:i:s');
        } else {
            return '';
        }
    }

    /**
     * Set attribute to date format
     * @param $input
     */
    public function setSessionEndAttribute($input)
    {
        if ($input != null && $input != '') {
            $this->attributes['session_end'] = Carbon::createFromFormat(config('app.date_format') . ' H:i:s', $input)->format('Y-m-d H:i:s');
        } else {
            $this->attributes['session_end'] = null;
        }
    }

    /**
     * Get attribute from date format
     * @param $input
     *
     * @return string
     */
    public function getSessionEndAttribute($input)
    {
        $zeroDate = str_replace(['Y', 'm', 'd'], ['0000', '00', '00'], config('app.date_format') . ' H:i:s');

        if ($input != $zeroDate && $input != null) {
            return Carbon::createFromFormat('Y-m-d H:i:s', $input)->format(config('app.date_format') . ' H:i:s');
        } else {
            return '';
        }
    }

    /**
     * Set to null if empty
     * @param $input
     */
    public function setCreatedByIdAttribute($input)
    {
        $this->attributes['created_by_id'] = $input ? $input : null;
    }

    /**
     * Set attribute to money format
     * @param $input
     */
    public function setVotingDurationAttribute($input)
    {
        $this->attributes['voting_duration'] = $input ? $input : null;
    }
    
    public function linked_p5_hub()
    {
        return $this->belongsTo(P5Hub::class, 'linked_p5_hub_id')->withTrashed();
    }
    
    public function linked_session_status()
    {
        return $this->belongsTo(P016SessionStatus::class, 'linked_session_status_id')->withTrashed();
    }
    
    public function session_tags()
    {
        return $this->belongsToMany(P5Tag::class, 'p016_session_p5_tag')->withTrashed();
    }
    
    public function created_by()
    {
        return $this->belongsTo(User::class, 'created_by_id');
    }
    
}
