<?php
namespace App;

use Illuminate\Database\Eloquent\Model;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\Traits\FilterByUser;

/**
 * Class P016MobiMeetingParticipant
 *
 * @package App
 * @property string $linked_session
 * @property string $created_uid
 * @property string $participant_status
 * @property string $participant_email
 * @property string $ip_addr
 * @property string $date_recorded
 * @property string $offer_preso_email_status
 * @property string $offer_email_survey_detail_status
 * @property string $offer_hub_info_status
 * @property string $offer_pass_on_email_status
 * @property string $linked_user
 * @property string $created_by
*/
class P016MobiMeetingParticipant extends Model
{
    use SoftDeletes, FilterByUser;

    protected $fillable = ['created_uid', 'participant_status', 'participant_email', 'ip_addr', 'date_recorded', 'offer_preso_email_status', 'offer_email_survey_detail_status', 'offer_hub_info_status', 'offer_pass_on_email_status', 'linked_session_id', 'linked_user_id', 'created_by_id'];
    public static $searchable = [
    ];
    
    public static function boot()
    {
        parent::boot();

        P016MobiMeetingParticipant::observe(new \App\Observers\UserActionsObserver);
    }

    /**
     * Set to null if empty
     * @param $input
     */
    public function setLinkedSessionIdAttribute($input)
    {
        $this->attributes['linked_session_id'] = $input ? $input : null;
    }

    /**
     * Set attribute to date format
     * @param $input
     */
    public function setDateRecordedAttribute($input)
    {
        if ($input != null && $input != '') {
            $this->attributes['date_recorded'] = Carbon::createFromFormat(config('app.date_format') . ' H:i:s', $input)->format('Y-m-d H:i:s');
        } else {
            $this->attributes['date_recorded'] = null;
        }
    }

    /**
     * Get attribute from date format
     * @param $input
     *
     * @return string
     */
    public function getDateRecordedAttribute($input)
    {
        $zeroDate = str_replace(['Y', 'm', 'd'], ['0000', '00', '00'], config('app.date_format') . ' H:i:s');

        if ($input != $zeroDate && $input != null) {
            return Carbon::createFromFormat('Y-m-d H:i:s', $input)->format(config('app.date_format') . ' H:i:s');
        } else {
            return '';
        }
    }

    /**
     * Set to null if empty
     * @param $input
     */
    public function setLinkedUserIdAttribute($input)
    {
        $this->attributes['linked_user_id'] = $input ? $input : null;
    }

    /**
     * Set to null if empty
     * @param $input
     */
    public function setCreatedByIdAttribute($input)
    {
        $this->attributes['created_by_id'] = $input ? $input : null;
    }
    
    public function linked_session()
    {
        return $this->belongsTo(P016Session::class, 'linked_session_id')->withTrashed();
    }
    
    public function linked_user()
    {
        return $this->belongsTo(User::class, 'linked_user_id');
    }
    
    public function created_by()
    {
        return $this->belongsTo(User::class, 'created_by_id');
    }
    
}
