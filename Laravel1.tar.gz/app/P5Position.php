<?php
namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * Class P5Position
 *
 * @package App
 * @property string $pos_title
 * @property string $sort_code
 * @property string $dq
*/
class P5Position extends Model
{
    use SoftDeletes;

    protected $fillable = ['pos_title', 'sort_code', 'dq'];
    public static $searchable = [
    ];
    
    public static function boot()
    {
        parent::boot();

        P5Position::observe(new \App\Observers\UserActionsObserver);
    }
    
}
