<?php
namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\Traits\FilterByUser;

/**
 * Class P5Hub
 *
 * @package App
 * @property string $hub_name
 * @property text $hub_description
 * @property string $website
 * @property string $email
 * @property string $state
 * @property string $hub_model
 * @property tinyInteger $public_view
 * @property string $logo
 * @property string $address_line_1
 * @property string $address_line_2
 * @property string $city
 * @property string $postcode
 * @property string $map_location
 * @property integer $wm_id
 * @property string $created_by
 * @property string $dq
*/
class P5Hub extends Model
{
    use SoftDeletes, FilterByUser;

    protected $fillable = ['hub_name', 'hub_description', 'website', 'email', 'public_view', 'logo', 'address_line_1', 'address_line_2', 'city', 'postcode', 'wm_id', 'dq', 'map_location_address', 'map_location_latitude', 'map_location_longitude', 'state_id', 'hub_model_id', 'created_by_id'];
    public static $searchable = [
        'hub_name',
        'hub_description',
        'website',
        'email',
    ];
    
    public static function boot()
    {
        parent::boot();

        P5Hub::observe(new \App\Observers\UserActionsObserver);
    }

    /**
     * Set to null if empty
     * @param $input
     */
    public function setStateIdAttribute($input)
    {
        $this->attributes['state_id'] = $input ? $input : null;
    }

    /**
     * Set to null if empty
     * @param $input
     */
    public function setHubModelIdAttribute($input)
    {
        $this->attributes['hub_model_id'] = $input ? $input : null;
    }

    /**
     * Set attribute to money format
     * @param $input
     */
    public function setWmIdAttribute($input)
    {
        $this->attributes['wm_id'] = $input ? $input : null;
    }

    /**
     * Set to null if empty
     * @param $input
     */
    public function setCreatedByIdAttribute($input)
    {
        $this->attributes['created_by_id'] = $input ? $input : null;
    }
    
    public function state()
    {
        return $this->belongsTo(P5State::class, 'state_id')->withTrashed();
    }
    
    public function hub_tags()
    {
        return $this->belongsToMany(P5Tag::class, 'p5_hub_p5_tag')->withTrashed();
    }
    
    public function hub_roles()
    {
        return $this->belongsToMany(P5HubRole::class, 'p5_hub_p5_hub_role')->withTrashed();
    }
    
    public function hub_model()
    {
        return $this->belongsTo(P5HubModel::class, 'hub_model_id')->withTrashed();
    }
    
    public function created_by()
    {
        return $this->belongsTo(User::class, 'created_by_id');
    }
    
}
