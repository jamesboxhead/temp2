<?php
namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * Class P5Tag
 *
 * @package App
 * @property string $tag
 * @property text $notes
 * @property string $dq
*/
class P5Tag extends Model
{
    use SoftDeletes;

    protected $fillable = ['tag', 'notes', 'dq'];
    public static $searchable = [
        'notes',
    ];
    
    public static function boot()
    {
        parent::boot();

        P5Tag::observe(new \App\Observers\UserActionsObserver);
    }
    
}
