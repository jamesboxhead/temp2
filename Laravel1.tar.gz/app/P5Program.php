<?php
namespace App;

use Illuminate\Database\Eloquent\Model;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\Traits\FilterByUser;

/**
 * Class P5Program
 *
 * @package App
 * @property string $title
 * @property text $description
 * @property string $established
 * @property string $website
 * @property string $logo
 * @property string $hub_link
 * @property string $created_by
 * @property string $dq
*/
class P5Program extends Model
{
    use SoftDeletes, FilterByUser;

    protected $fillable = ['title', 'description', 'established', 'website', 'logo', 'dq', 'hub_link_id', 'created_by_id'];
    public static $searchable = [
    ];
    
    public static function boot()
    {
        parent::boot();

        P5Program::observe(new \App\Observers\UserActionsObserver);
    }

    /**
     * Set attribute to date format
     * @param $input
     */
    public function setEstablishedAttribute($input)
    {
        if ($input != null && $input != '') {
            $this->attributes['established'] = Carbon::createFromFormat(config('app.date_format'), $input)->format('Y-m-d');
        } else {
            $this->attributes['established'] = null;
        }
    }

    /**
     * Get attribute from date format
     * @param $input
     *
     * @return string
     */
    public function getEstablishedAttribute($input)
    {
        $zeroDate = str_replace(['Y', 'm', 'd'], ['0000', '00', '00'], config('app.date_format'));

        if ($input != $zeroDate && $input != null) {
            return Carbon::createFromFormat('Y-m-d', $input)->format(config('app.date_format'));
        } else {
            return '';
        }
    }

    /**
     * Set to null if empty
     * @param $input
     */
    public function setHubLinkIdAttribute($input)
    {
        $this->attributes['hub_link_id'] = $input ? $input : null;
    }

    /**
     * Set to null if empty
     * @param $input
     */
    public function setCreatedByIdAttribute($input)
    {
        $this->attributes['created_by_id'] = $input ? $input : null;
    }
    
    public function hub_link()
    {
        return $this->belongsTo(P5Hub::class, 'hub_link_id')->withTrashed();
    }
    
    public function prog_tags()
    {
        return $this->belongsToMany(P5Tag::class, 'p5_program_p5_tag')->withTrashed();
    }
    
    public function created_by()
    {
        return $this->belongsTo(User::class, 'created_by_id');
    }
    
    public function p5_intakes() {
        return $this->hasMany(P5Intake::class, 'program_id');
    }
}
