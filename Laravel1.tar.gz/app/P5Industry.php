<?php
namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * Class P5Industry
 *
 * @package App
 * @property string $anzsic_lvl1_code
 * @property string $anzic_description
 * @property text $notes
*/
class P5Industry extends Model
{
    use SoftDeletes;

    protected $fillable = ['anzsic_lvl1_code', 'anzic_description', 'notes'];
    public static $searchable = [
    ];
    
    public static function boot()
    {
        parent::boot();

        P5Industry::observe(new \App\Observers\UserActionsObserver);
    }
    
}
