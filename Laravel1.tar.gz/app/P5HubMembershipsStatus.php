<?php
namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\Traits\FilterByUser;

/**
 * Class P5HubMembershipsStatus
 *
 * @package App
 * @property string $status_code
 * @property string $status
 * @property string $sort_code
 * @property string $status_notes
 * @property string $dq
 * @property string $created_by
*/
class P5HubMembershipsStatus extends Model
{
    use SoftDeletes, FilterByUser;

    protected $fillable = ['status_code', 'status', 'sort_code', 'status_notes', 'dq', 'created_by_id'];
    public static $searchable = [
    ];
    
    public static function boot()
    {
        parent::boot();

        P5HubMembershipsStatus::observe(new \App\Observers\UserActionsObserver);
    }

    /**
     * Set to null if empty
     * @param $input
     */
    public function setCreatedByIdAttribute($input)
    {
        $this->attributes['created_by_id'] = $input ? $input : null;
    }
    
    public function created_by()
    {
        return $this->belongsTo(User::class, 'created_by_id');
    }
    
}
