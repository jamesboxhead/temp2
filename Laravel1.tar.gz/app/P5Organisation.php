<?php
namespace App;

use Illuminate\Database\Eloquent\Model;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\Traits\FilterByUser;

/**
 * Class P5Organisation
 *
 * @package App
 * @property string $trading_name
 * @property string $legal_name
 * @property string $org_status
 * @property string $org_location
 * @property string $address_line_1
 * @property string $address_line_2
 * @property string $surburb
 * @property string $post_code
 * @property string $state
 * @property string $established
 * @property string $primary_web_site
 * @property string $business_model
 * @property string $p5_anzic_level1
 * @property text $general_info
 * @property string $logo
 * @property string $primary_email
 * @property string $url_linkedin
 * @property string $url_facebook
 * @property string $url_twitter
 * @property string $url_instagram
 * @property string $url_angellist
 * @property string $url_crunchbase
 * @property string $map_style_url
 * @property string $created_by
 * @property string $dq
*/
class P5Organisation extends Model
{
    use SoftDeletes, FilterByUser;

    protected $fillable = ['trading_name', 'legal_name', 'address_line_1', 'address_line_2', 'surburb', 'post_code', 'established', 'primary_web_site', 'general_info', 'logo', 'primary_email', 'url_linkedin', 'url_facebook', 'url_twitter', 'url_instagram', 'url_angellist', 'url_crunchbase', 'map_style_url', 'dq', 'org_location_address', 'org_location_latitude', 'org_location_longitude', 'org_status_id', 'state_id', 'business_model_id', 'p5_anzic_level1_id', 'created_by_id'];
    public static $searchable = [
        'general_info',
    ];
    
    public static function boot()
    {
        parent::boot();

        P5Organisation::observe(new \App\Observers\UserActionsObserver);
    }

    /**
     * Set to null if empty
     * @param $input
     */
    public function setOrgStatusIdAttribute($input)
    {
        $this->attributes['org_status_id'] = $input ? $input : null;
    }

    /**
     * Set to null if empty
     * @param $input
     */
    public function setStateIdAttribute($input)
    {
        $this->attributes['state_id'] = $input ? $input : null;
    }

    /**
     * Set attribute to date format
     * @param $input
     */
    public function setEstablishedAttribute($input)
    {
        if ($input != null && $input != '') {
            $this->attributes['established'] = Carbon::createFromFormat(config('app.date_format'), $input)->format('Y-m-d');
        } else {
            $this->attributes['established'] = null;
        }
    }

    /**
     * Get attribute from date format
     * @param $input
     *
     * @return string
     */
    public function getEstablishedAttribute($input)
    {
        $zeroDate = str_replace(['Y', 'm', 'd'], ['0000', '00', '00'], config('app.date_format'));

        if ($input != $zeroDate && $input != null) {
            return Carbon::createFromFormat('Y-m-d', $input)->format(config('app.date_format'));
        } else {
            return '';
        }
    }

    /**
     * Set to null if empty
     * @param $input
     */
    public function setBusinessModelIdAttribute($input)
    {
        $this->attributes['business_model_id'] = $input ? $input : null;
    }

    /**
     * Set to null if empty
     * @param $input
     */
    public function setP5AnzicLevel1IdAttribute($input)
    {
        $this->attributes['p5_anzic_level1_id'] = $input ? $input : null;
    }

    /**
     * Set to null if empty
     * @param $input
     */
    public function setCreatedByIdAttribute($input)
    {
        $this->attributes['created_by_id'] = $input ? $input : null;
    }
    
    public function org_status()
    {
        return $this->belongsTo(P5OrgStatus::class, 'org_status_id')->withTrashed();
    }
    
    public function state()
    {
        return $this->belongsTo(P5State::class, 'state_id')->withTrashed();
    }
    
    public function org_tags()
    {
        return $this->belongsToMany(P5Tag::class, 'p5_organisation_p5_tag')->withTrashed();
    }
    
    public function org_cat()
    {
        return $this->belongsToMany(P5OrgCategory::class, 'p5_org_category_p5_organisation')->withTrashed();
    }
    
    public function business_model()
    {
        return $this->belongsTo(P5BusinessModel::class, 'business_model_id')->withTrashed();
    }
    
    public function p5_anzic_level1()
    {
        return $this->belongsTo(P5Industry::class, 'p5_anzic_level1_id')->withTrashed();
    }
    
    public function created_by()
    {
        return $this->belongsTo(User::class, 'created_by_id');
    }
    
}
