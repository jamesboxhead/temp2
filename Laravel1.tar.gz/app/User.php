<?php
namespace App;

use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Illuminate\Auth\Notifications\ResetPassword;
use Hash;
use App\Traits\FilterByUser;

/**
 * Class User
 *
 * @package App
 * @property string $name
 * @property string $first_name
 * @property string $last_name
 * @property string $email
 * @property string $primary_phone_contact
 * @property string $primary_web_address
 * @property string $linked_gender
 * @property string $user_photo
 * @property string $address_line_1
 * @property string $address_line_2
 * @property string $city
 * @property string $linked_state
 * @property string $postcode
 * @property string $map_location
 * @property integer $year_of_birth
 * @property string $password
 * @property string $remember_token
 * @property string $created_by
 * @property string $dq
*/
class User extends Authenticatable
{
    use Notifiable;
    use FilterByUser;

    protected $fillable = ['name', 'first_name', 'last_name', 'email', 'primary_phone_contact', 'primary_web_address', 'user_photo', 'address_line_1', 'address_line_2', 'city', 'postcode', 'year_of_birth', 'password', 'remember_token', 'dq', 'map_location_address', 'map_location_latitude', 'map_location_longitude', 'linked_gender_id', 'linked_state_id', 'created_by_id'];
    public static $searchable = [
        'name',
        'first_name',
        'last_name',
        'email',
        'primary_phone_contact',
        'primary_web_address',
        'address_line_1',
    ];
    
    public static function boot()
    {
        parent::boot();

        User::observe(new \App\Observers\UserActionsObserver);
    }
    
    

    /**
     * Set to null if empty
     * @param $input
     */
    public function setLinkedGenderIdAttribute($input)
    {
        $this->attributes['linked_gender_id'] = $input ? $input : null;
    }

    /**
     * Set to null if empty
     * @param $input
     */
    public function setLinkedStateIdAttribute($input)
    {
        $this->attributes['linked_state_id'] = $input ? $input : null;
    }

    /**
     * Set attribute to money format
     * @param $input
     */
    public function setYearOfBirthAttribute($input)
    {
        $this->attributes['year_of_birth'] = $input ? $input : null;
    }/**
     * Hash password
     * @param $input
     */
    public function setPasswordAttribute($input)
    {
        if ($input)
            $this->attributes['password'] = app('hash')->needsRehash($input) ? Hash::make($input) : $input;
    }
    

    /**
     * Set to null if empty
     * @param $input
     */
    public function setCreatedByIdAttribute($input)
    {
        $this->attributes['created_by_id'] = $input ? $input : null;
    }
    
    public function user_tags()
    {
        return $this->belongsToMany(P5Tag::class, 'p5_tag_user')->withTrashed();
    }
    
    public function linked_gender()
    {
        return $this->belongsTo(P5UserGender::class, 'linked_gender_id')->withTrashed();
    }
    
    public function role()
    {
        return $this->belongsToMany(Role::class, 'role_user');
    }
    
    public function linked_state()
    {
        return $this->belongsTo(P5State::class, 'linked_state_id')->withTrashed();
    }
    
    public function created_by()
    {
        return $this->belongsTo(User::class, 'created_by_id');
    }
    
    public function topics() {
        return $this->hasMany(MessengerTopic::class, 'receiver_id')->orWhere('sender_id', $this->id);
    }

    public function inbox()
    {
        return $this->hasMany(MessengerTopic::class, 'receiver_id');
    }

    public function outbox()
    {
        return $this->hasMany(MessengerTopic::class, 'sender_id');
    }
    public function internalNotifications()
    {
        return $this->belongsToMany(InternalNotification::class)
            ->withPivot('read_at')
            ->orderBy('internal_notification_user.created_at', 'desc')
            ->limit(10);
    }

    public function sendPasswordResetNotification($token)
    {
       $this->notify(new ResetPassword($token));
    }
}
