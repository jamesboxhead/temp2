<?php
namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * Class P012SurveyLog
 *
 * @package App
 * @property string $survey_target
 * @property string $p012_survey_code
 * @property string $ext_survey_code
 * @property string $p012_survey_status
 * @property string $ext_survey_status
 * @property string $linked_task
*/
class P012SurveyLog extends Model
{
    protected $fillable = ['p012_survey_code', 'ext_survey_code', 'p012_survey_status', 'ext_survey_status', 'survey_target_id', 'linked_task_id'];
    public static $searchable = [
    ];
    
    public static function boot()
    {
        parent::boot();

        P012SurveyLog::observe(new \App\Observers\UserActionsObserver);
    }

    /**
     * Set to null if empty
     * @param $input
     */
    public function setSurveyTargetIdAttribute($input)
    {
        $this->attributes['survey_target_id'] = $input ? $input : null;
    }

    /**
     * Set to null if empty
     * @param $input
     */
    public function setLinkedTaskIdAttribute($input)
    {
        $this->attributes['linked_task_id'] = $input ? $input : null;
    }
    
    public function survey_target()
    {
        return $this->belongsTo(User::class, 'survey_target_id');
    }
    
    public function linked_task()
    {
        return $this->belongsTo(Task::class, 'linked_task_id');
    }
    
}
