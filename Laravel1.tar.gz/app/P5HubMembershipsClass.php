<?php
namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\Traits\FilterByUser;

/**
 * Class P5HubMembershipsClass
 *
 * @package App
 * @property string $class_code
 * @property string $class
 * @property string $notes
 * @property string $sort_order
 * @property string $dq
 * @property string $created_by
*/
class P5HubMembershipsClass extends Model
{
    use SoftDeletes, FilterByUser;

    protected $fillable = ['class_code', 'class', 'notes', 'sort_order', 'dq', 'created_by_id'];
    public static $searchable = [
    ];
    
    public static function boot()
    {
        parent::boot();

        P5HubMembershipsClass::observe(new \App\Observers\UserActionsObserver);
    }

    /**
     * Set to null if empty
     * @param $input
     */
    public function setCreatedByIdAttribute($input)
    {
        $this->attributes['created_by_id'] = $input ? $input : null;
    }
    
    public function created_by()
    {
        return $this->belongsTo(User::class, 'created_by_id');
    }
    
    public function p5_hub_memberships_individuals() {
        return $this->hasMany(P5HubMembershipsIndividual::class, 'linked_membership_class_id');
    }
}
