<?php
namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * Class P023DataStandard
 *
 * @package App
 * @property string $data_standard_code
 * @property string $data_standard_short
 * @property string $data_standard_fa_icon
 * @property text $data_standard_notes
 * @property string $dash_board_title
 * @property string $dash_board_x_label
 * @property string $dash_board_y_label
 * @property string $dash_board_attr1
 * @property string $dash_board_attr2
 * @property string $dash_board_attr3
 * @property string $dash_board_attr4
 * @property string $dash_board_attr5
 * @property string $dash_board_notes
 * @property text $dash_board_short_notes
*/
class P023DataStandard extends Model
{
    use SoftDeletes;

    protected $fillable = ['data_standard_code', 'data_standard_short', 'data_standard_fa_icon', 'data_standard_notes', 'dash_board_title', 'dash_board_x_label', 'dash_board_y_label', 'dash_board_attr1', 'dash_board_attr2', 'dash_board_attr3', 'dash_board_attr4', 'dash_board_attr5', 'dash_board_notes', 'dash_board_short_notes'];
    public static $searchable = [
    ];
    
    public static function boot()
    {
        parent::boot();

        P023DataStandard::observe(new \App\Observers\UserActionsObserver);
    }
    
}
