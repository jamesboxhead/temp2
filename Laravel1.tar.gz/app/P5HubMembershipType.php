<?php
namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * Class P5HubMembershipType
 *
 * @package App
 * @property string $description
 * @property string $sort_order
 * @property string $dq
*/
class P5HubMembershipType extends Model
{
    use SoftDeletes;

    protected $fillable = ['description', 'sort_order', 'dq'];
    public static $searchable = [
    ];
    
    public static function boot()
    {
        parent::boot();

        P5HubMembershipType::observe(new \App\Observers\UserActionsObserver);
    }
    
    public function p5_hub_memberships_individuals() {
        return $this->hasMany(P5HubMembershipsIndividual::class, 'member_type_id');
    }
}
