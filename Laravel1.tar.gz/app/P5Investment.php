<?php
namespace App;

use Illuminate\Database\Eloquent\Model;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\Traits\FilterByUser;

/**
 * Class P5Investment
 *
 * @package App
 * @property string $org_invested_in
 * @property string $date_of_investment
 * @property decimal $amnt_of_investment
 * @property string $investment_currency
 * @property string $p5_actual_investment_souce
 * @property enum $inverstor_entity_type
 * @property string $investor_org
 * @property string $investor_individual
 * @property text $notes
 * @property string $dq
 * @property string $created_by
*/
class P5Investment extends Model
{
    use SoftDeletes, FilterByUser;

    protected $fillable = ['date_of_investment', 'amnt_of_investment', 'investment_currency', 'inverstor_entity_type', 'notes', 'dq', 'org_invested_in_id', 'p5_actual_investment_souce_id', 'investor_org_id', 'investor_individual_id', 'created_by_id'];
    public static $searchable = [
        'notes',
    ];
    
    public static function boot()
    {
        parent::boot();

        P5Investment::observe(new \App\Observers\UserActionsObserver);
    }

    public static $enum_inverstor_entity_type = ["Incorporated" => "Incorporated", "Individual" => "Individual"];

    /**
     * Set to null if empty
     * @param $input
     */
    public function setOrgInvestedInIdAttribute($input)
    {
        $this->attributes['org_invested_in_id'] = $input ? $input : null;
    }

    /**
     * Set attribute to date format
     * @param $input
     */
    public function setDateOfInvestmentAttribute($input)
    {
        if ($input != null && $input != '') {
            $this->attributes['date_of_investment'] = Carbon::createFromFormat(config('app.date_format'), $input)->format('Y-m-d');
        } else {
            $this->attributes['date_of_investment'] = null;
        }
    }

    /**
     * Get attribute from date format
     * @param $input
     *
     * @return string
     */
    public function getDateOfInvestmentAttribute($input)
    {
        $zeroDate = str_replace(['Y', 'm', 'd'], ['0000', '00', '00'], config('app.date_format'));

        if ($input != $zeroDate && $input != null) {
            return Carbon::createFromFormat('Y-m-d', $input)->format(config('app.date_format'));
        } else {
            return '';
        }
    }

    /**
     * Set attribute to money format
     * @param $input
     */
    public function setAmntOfInvestmentAttribute($input)
    {
        $this->attributes['amnt_of_investment'] = $input ? $input : null;
    }

    /**
     * Set to null if empty
     * @param $input
     */
    public function setP5ActualInvestmentSouceIdAttribute($input)
    {
        $this->attributes['p5_actual_investment_souce_id'] = $input ? $input : null;
    }

    /**
     * Set to null if empty
     * @param $input
     */
    public function setInvestorOrgIdAttribute($input)
    {
        $this->attributes['investor_org_id'] = $input ? $input : null;
    }

    /**
     * Set to null if empty
     * @param $input
     */
    public function setInvestorIndividualIdAttribute($input)
    {
        $this->attributes['investor_individual_id'] = $input ? $input : null;
    }

    /**
     * Set to null if empty
     * @param $input
     */
    public function setCreatedByIdAttribute($input)
    {
        $this->attributes['created_by_id'] = $input ? $input : null;
    }
    
    public function org_invested_in()
    {
        return $this->belongsTo(P5Organisation::class, 'org_invested_in_id')->withTrashed();
    }
    
    public function p5_actual_investment_souce()
    {
        return $this->belongsTo(P5InvestmentSource::class, 'p5_actual_investment_souce_id')->withTrashed();
    }
    
    public function investor_org()
    {
        return $this->belongsTo(P5Organisation::class, 'investor_org_id')->withTrashed();
    }
    
    public function investor_individual()
    {
        return $this->belongsTo(User::class, 'investor_individual_id');
    }
    
    public function created_by()
    {
        return $this->belongsTo(User::class, 'created_by_id');
    }
    
}
