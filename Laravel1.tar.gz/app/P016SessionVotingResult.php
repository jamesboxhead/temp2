<?php
namespace App;

use Illuminate\Database\Eloquent\Model;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\Traits\FilterByUser;

/**
 * Class P016SessionVotingResult
 *
 * @package App
 * @property string $linked_session
 * @property string $created_uid
 * @property string $option_code
 * @property string $ip_addr
 * @property string $date_recorded
 * @property string $created_by
*/
class P016SessionVotingResult extends Model
{
    use SoftDeletes, FilterByUser;

    protected $fillable = ['created_uid', 'option_code', 'ip_addr', 'date_recorded', 'linked_session_id', 'created_by_id'];
    public static $searchable = [
    ];
    
    public static function boot()
    {
        parent::boot();

        P016SessionVotingResult::observe(new \App\Observers\UserActionsObserver);
    }

    /**
     * Set to null if empty
     * @param $input
     */
    public function setLinkedSessionIdAttribute($input)
    {
        $this->attributes['linked_session_id'] = $input ? $input : null;
    }

    /**
     * Set attribute to date format
     * @param $input
     */
    public function setDateRecordedAttribute($input)
    {
        if ($input != null && $input != '') {
            $this->attributes['date_recorded'] = Carbon::createFromFormat(config('app.date_format') . ' H:i:s', $input)->format('Y-m-d H:i:s');
        } else {
            $this->attributes['date_recorded'] = null;
        }
    }

    /**
     * Get attribute from date format
     * @param $input
     *
     * @return string
     */
    public function getDateRecordedAttribute($input)
    {
        $zeroDate = str_replace(['Y', 'm', 'd'], ['0000', '00', '00'], config('app.date_format') . ' H:i:s');

        if ($input != $zeroDate && $input != null) {
            return Carbon::createFromFormat('Y-m-d H:i:s', $input)->format(config('app.date_format') . ' H:i:s');
        } else {
            return '';
        }
    }

    /**
     * Set to null if empty
     * @param $input
     */
    public function setCreatedByIdAttribute($input)
    {
        $this->attributes['created_by_id'] = $input ? $input : null;
    }
    
    public function linked_session()
    {
        return $this->belongsTo(P016Session::class, 'linked_session_id')->withTrashed();
    }
    
    public function created_by()
    {
        return $this->belongsTo(User::class, 'created_by_id');
    }
    
}
