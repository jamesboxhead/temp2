<?php
namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * Class P5OrgCategory
 *
 * @package App
 * @property string $org_category
 * @property string $sort_code
 * @property text $notes
*/
class P5OrgCategory extends Model
{
    use SoftDeletes;

    protected $fillable = ['org_category', 'sort_code', 'notes'];
    public static $searchable = [
    ];
    
    public static function boot()
    {
        parent::boot();

        P5OrgCategory::observe(new \App\Observers\UserActionsObserver);
    }
    
}
