<?php
namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * Class P5UserGender
 *
 * @package App
 * @property string $gender_description
 * @property string $gender_code
 * @property string $gender_fa_icon
 * @property string $sort_code
*/
class P5UserGender extends Model
{
    use SoftDeletes;

    protected $fillable = ['gender_description', 'gender_code', 'gender_fa_icon', 'sort_code'];
    public static $searchable = [
    ];
    
    public static function boot()
    {
        parent::boot();

        P5UserGender::observe(new \App\Observers\UserActionsObserver);
    }
    
}
