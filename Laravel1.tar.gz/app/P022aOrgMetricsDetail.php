<?php
namespace App;

use Illuminate\Database\Eloquent\Model;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\Traits\FilterByUser;

/**
 * Class P022aOrgMetricsDetail
 *
 * @package App
 * @property string $result_as_at
 * @property string $result_p5_organisation
 * @property string $p022_result_raw
 * @property string $result_p022_org_metrics_lookup
 * @property string $result_source
 * @property integer $p022_result_value
 * @property string $p022_validation_status
 * @property string $created_by
*/
class P022aOrgMetricsDetail extends Model
{
    use SoftDeletes, FilterByUser;

    protected $fillable = ['result_as_at', 'p022_result_raw', 'result_source', 'p022_result_value', 'p022_validation_status', 'result_p5_organisation_id', 'result_p022_org_metrics_lookup_id', 'created_by_id'];
    public static $searchable = [
    ];
    
    public static function boot()
    {
        parent::boot();

        P022aOrgMetricsDetail::observe(new \App\Observers\UserActionsObserver);
    }

    /**
     * Set attribute to date format
     * @param $input
     */
    public function setResultAsAtAttribute($input)
    {
        if ($input != null && $input != '') {
            $this->attributes['result_as_at'] = Carbon::createFromFormat(config('app.date_format'), $input)->format('Y-m-d');
        } else {
            $this->attributes['result_as_at'] = null;
        }
    }

    /**
     * Get attribute from date format
     * @param $input
     *
     * @return string
     */
    public function getResultAsAtAttribute($input)
    {
        $zeroDate = str_replace(['Y', 'm', 'd'], ['0000', '00', '00'], config('app.date_format'));

        if ($input != $zeroDate && $input != null) {
            return Carbon::createFromFormat('Y-m-d', $input)->format(config('app.date_format'));
        } else {
            return '';
        }
    }

    /**
     * Set to null if empty
     * @param $input
     */
    public function setResultP5OrganisationIdAttribute($input)
    {
        $this->attributes['result_p5_organisation_id'] = $input ? $input : null;
    }

    /**
     * Set to null if empty
     * @param $input
     */
    public function setResultP022OrgMetricsLookupIdAttribute($input)
    {
        $this->attributes['result_p022_org_metrics_lookup_id'] = $input ? $input : null;
    }

    /**
     * Set attribute to money format
     * @param $input
     */
    public function setP022ResultValueAttribute($input)
    {
        $this->attributes['p022_result_value'] = $input ? $input : null;
    }

    /**
     * Set to null if empty
     * @param $input
     */
    public function setCreatedByIdAttribute($input)
    {
        $this->attributes['created_by_id'] = $input ? $input : null;
    }
    
    public function result_p5_organisation()
    {
        return $this->belongsTo(P5Organisation::class, 'result_p5_organisation_id')->withTrashed();
    }
    
    public function result_p022_org_metrics_lookup()
    {
        return $this->belongsTo(P022aOrgMetricsItem::class, 'result_p022_org_metrics_lookup_id')->withTrashed();
    }
    
    public function created_by()
    {
        return $this->belongsTo(User::class, 'created_by_id');
    }
    
}
