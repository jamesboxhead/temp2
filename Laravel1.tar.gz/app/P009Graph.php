<?php
namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * Class P009Graph
 *
 * @package App
 * @property string $sort_code
 * @property string $dataset_title
 * @property string $graph_root
 * @property string $graph_name
 * @property string $graph_description
*/
class P009Graph extends Model
{
    use SoftDeletes;

    protected $fillable = ['sort_code', 'dataset_title', 'graph_root', 'graph_name', 'graph_description'];
    public static $searchable = [
    ];
    
    public static function boot()
    {
        parent::boot();

        P009Graph::observe(new \App\Observers\UserActionsObserver);
    }
    
}
