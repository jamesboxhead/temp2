<?php
namespace App;

use Illuminate\Database\Eloquent\Model;
use Carbon\Carbon;
use App\Traits\FilterByUser;

/**
 * Class P5OrgPosUserLink
 *
 * @package App
 * @property string $username
 * @property string $org_link
 * @property string $org_relationship
 * @property tinyInteger $relationship_is_current
 * @property string $relationship_started
 * @property string $relationship_ended
 * @property text $notes
 * @property string $dq
 * @property string $created_by
*/
class P5OrgPosUserLink extends Model
{
    use FilterByUser;

    protected $fillable = ['relationship_is_current', 'relationship_started', 'relationship_ended', 'notes', 'dq', 'username_id', 'org_link_id', 'org_relationship_id', 'created_by_id'];
    public static $searchable = [
        'notes',
    ];
    
    public static function boot()
    {
        parent::boot();

        P5OrgPosUserLink::observe(new \App\Observers\UserActionsObserver);
    }

    /**
     * Set to null if empty
     * @param $input
     */
    public function setUsernameIdAttribute($input)
    {
        $this->attributes['username_id'] = $input ? $input : null;
    }

    /**
     * Set to null if empty
     * @param $input
     */
    public function setOrgLinkIdAttribute($input)
    {
        $this->attributes['org_link_id'] = $input ? $input : null;
    }

    /**
     * Set to null if empty
     * @param $input
     */
    public function setOrgRelationshipIdAttribute($input)
    {
        $this->attributes['org_relationship_id'] = $input ? $input : null;
    }

    /**
     * Set attribute to date format
     * @param $input
     */
    public function setRelationshipStartedAttribute($input)
    {
        if ($input != null && $input != '') {
            $this->attributes['relationship_started'] = Carbon::createFromFormat(config('app.date_format'), $input)->format('Y-m-d');
        } else {
            $this->attributes['relationship_started'] = null;
        }
    }

    /**
     * Get attribute from date format
     * @param $input
     *
     * @return string
     */
    public function getRelationshipStartedAttribute($input)
    {
        $zeroDate = str_replace(['Y', 'm', 'd'], ['0000', '00', '00'], config('app.date_format'));

        if ($input != $zeroDate && $input != null) {
            return Carbon::createFromFormat('Y-m-d', $input)->format(config('app.date_format'));
        } else {
            return '';
        }
    }

    /**
     * Set attribute to date format
     * @param $input
     */
    public function setRelationshipEndedAttribute($input)
    {
        if ($input != null && $input != '') {
            $this->attributes['relationship_ended'] = Carbon::createFromFormat(config('app.date_format'), $input)->format('Y-m-d');
        } else {
            $this->attributes['relationship_ended'] = null;
        }
    }

    /**
     * Get attribute from date format
     * @param $input
     *
     * @return string
     */
    public function getRelationshipEndedAttribute($input)
    {
        $zeroDate = str_replace(['Y', 'm', 'd'], ['0000', '00', '00'], config('app.date_format'));

        if ($input != $zeroDate && $input != null) {
            return Carbon::createFromFormat('Y-m-d', $input)->format(config('app.date_format'));
        } else {
            return '';
        }
    }

    /**
     * Set to null if empty
     * @param $input
     */
    public function setCreatedByIdAttribute($input)
    {
        $this->attributes['created_by_id'] = $input ? $input : null;
    }
    
    public function username()
    {
        return $this->belongsTo(User::class, 'username_id');
    }
    
    public function org_link()
    {
        return $this->belongsTo(P5Organisation::class, 'org_link_id')->withTrashed();
    }
    
    public function org_relationship()
    {
        return $this->belongsTo(P5Position::class, 'org_relationship_id')->withTrashed();
    }
    
    public function created_by()
    {
        return $this->belongsTo(User::class, 'created_by_id');
    }
    
}
