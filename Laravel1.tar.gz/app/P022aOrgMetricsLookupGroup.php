<?php
namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * Class P022aOrgMetricsLookupGroup
 *
 * @package App
 * @property string $org_metrics_group
 * @property string $sort_code
*/
class P022aOrgMetricsLookupGroup extends Model
{
    use SoftDeletes;

    protected $fillable = ['org_metrics_group', 'sort_code'];
    public static $searchable = [
    ];
    
    public static function boot()
    {
        parent::boot();

        P022aOrgMetricsLookupGroup::observe(new \App\Observers\UserActionsObserver);
    }
    
    public function p022a_org_metrics_items() {
        return $this->hasMany(P022aOrgMetricsItem::class, 'p022a_org_metric_group_id');
    }
}
