<?php
namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * Class P5HubRole
 *
 * @package App
 * @property string $hub_role
 * @property string $maps_styleurl
 * @property string $dq
*/
class P5HubRole extends Model
{
    use SoftDeletes;

    protected $fillable = ['hub_role', 'maps_styleurl', 'dq'];
    public static $searchable = [
    ];
    
    public static function boot()
    {
        parent::boot();

        P5HubRole::observe(new \App\Observers\UserActionsObserver);
    }
    
}
