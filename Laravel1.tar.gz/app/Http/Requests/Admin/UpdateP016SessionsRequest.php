<?php
namespace App\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;

class UpdateP016SessionsRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            
            'session_tags.*' => 'exists:p5_tags,id',
            'session_start' => 'nullable|date_format:'.config('app.date_format').' H:i:s',
            'session_end' => 'nullable|date_format:'.config('app.date_format').' H:i:s',
            'voting_duration' => 'max:2147483647|nullable|numeric',
        ];
    }
}
