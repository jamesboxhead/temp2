<?php
namespace App\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;

class StoreP5OrganisationsRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'org_tags.*' => 'exists:p5_tags,id',
            'established' => 'nullable|date_format:'.config('app.date_format'),
            'org_cat.*' => 'exists:p5_org_categories,id',
            'primary_email' => 'email',
        ];
    }
}
