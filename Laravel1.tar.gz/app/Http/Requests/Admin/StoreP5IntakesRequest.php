<?php
namespace App\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;

class StoreP5IntakesRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'start_date' => 'nullable|date_format:'.config('app.date_format'),
            'end_date1' => 'nullable|date_format:'.config('app.date_format'),
            'org_link.*' => 'exists:p5_organisations,id',
            'users_linked.*' => 'exists:users,id',
        ];
    }
}
