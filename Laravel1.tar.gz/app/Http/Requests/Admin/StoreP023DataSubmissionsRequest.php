<?php
namespace App\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;

class StoreP023DataSubmissionsRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'data_element_as_at' => 'nullable|date_format:'.config('app.date_format'),
            'data_element_x_date' => 'nullable|date_format:'.config('app.date_format'),
            'data_element_x_num' => 'max:2147483647|nullable|numeric',
            'data_element_y_date' => 'nullable|date_format:'.config('app.date_format'),
            'data_element_y_num' => 'max:2147483647|nullable|numeric',
        ];
    }
}
