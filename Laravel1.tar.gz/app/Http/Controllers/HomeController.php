<?php

namespace App\Http\Controllers;

use App\Http\Requests;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        
        $users = \App\User::latest()->limit(5)->get(); 
        $useractions = \App\UserAction::latest()->limit(10)->get(); 
        $p5hubs = \App\P5Hub::latest()->limit(5)->get(); 
        $p5organisations = \App\P5Organisation::latest()->limit(5)->get(); 
        $p5programs = \App\P5Program::latest()->limit(5)->get(); 
        $p5intakes = \App\P5Intake::latest()->limit(5)->get(); 

        return view('home', compact( 'users', 'useractions', 'p5hubs', 'p5organisations', 'p5programs', 'p5intakes' ));
    }
}
