<?php

namespace App\Http\Controllers\Admin;

use App\P5Industry;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\StoreP5IndustriesRequest;
use App\Http\Requests\Admin\UpdateP5IndustriesRequest;
use Yajra\DataTables\DataTables;

use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
class P5IndustriesController extends Controller
{
    /**
     * Display a listing of P5Industry.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {


        
        if (request()->ajax()) {
            $query = P5Industry::query();
            $template = 'actionsTemplate';
            if(request('show_deleted') == 1) {
                
                $query->onlyTrashed();
                $template = 'restoreTemplate';
            }
            $query->select([
                'p5_industries.id',
                'p5_industries.anzsic_lvl1_code',
                'p5_industries.anzic_description',
                'p5_industries.notes',
            ]);
            $table = Datatables::of($query);

            $table->setRowAttr([
                'data-entry-id' => '{{$id}}',
            ]);
            $table->addColumn('massDelete', '&nbsp;');
            $table->addColumn('actions', '&nbsp;');
            $table->editColumn('actions', function ($row) use ($template) {
                $gateKey  = 'p5_industry_';
                $routeKey = 'admin.p5_industries';

                return view($template, compact('row', 'gateKey', 'routeKey'));
            });
            $table->editColumn('anzsic_lvl1_code', function ($row) {
                return $row->anzsic_lvl1_code ? $row->anzsic_lvl1_code : '';
            });
            $table->editColumn('anzic_description', function ($row) {
                return $row->anzic_description ? $row->anzic_description : '';
            });
            $table->editColumn('notes', function ($row) {
                return $row->notes ? $row->notes : '';
            });

            $table->rawColumns(['actions']);

            return $table->make(true);
        }

        return view('admin.p5_industries.index');
    }

    /**
     * Show the form for creating new P5Industry.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.p5_industries.create');
    }

    /**
     * Store a newly created P5Industry in storage.
     *
     * @param  \App\Http\Requests\StoreP5IndustriesRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreP5IndustriesRequest $request)
    {
        $p5_industry = P5Industry::create($request->all());



        return redirect()->route('admin.p5_industries.index');
    }


    /**
     * Show the form for editing P5Industry.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $p5_industry = P5Industry::findOrFail($id);

        return view('admin.p5_industries.edit', compact('p5_industry'));
    }

    /**
     * Update P5Industry in storage.
     *
     * @param  \App\Http\Requests\UpdateP5IndustriesRequest  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateP5IndustriesRequest $request, $id)
    {
        $p5_industry = P5Industry::findOrFail($id);
        $p5_industry->update($request->all());



        return redirect()->route('admin.p5_industries.index');
    }


    /**
     * Display P5Industry.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $p5_organisations = \App\P5Organisation::where('p5_anzic_level1_id', $id)->get();

        $p5_industry = P5Industry::findOrFail($id);

        return view('admin.p5_industries.show', compact('p5_industry', 'p5_organisations'));
    }


    /**
     * Remove P5Industry from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $p5_industry = P5Industry::findOrFail($id);
        $p5_industry->delete();

        return redirect()->route('admin.p5_industries.index');
    }

    /**
     * Delete all selected P5Industry at once.
     *
     * @param Request $request
     */
    public function massDestroy(Request $request)
    {
        if ($request->input('ids')) {
            $entries = P5Industry::whereIn('id', $request->input('ids'))->get();

            foreach ($entries as $entry) {
                $entry->delete();
            }
        }
    }


    /**
     * Restore P5Industry from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function restore($id)
    {
        $p5_industry = P5Industry::onlyTrashed()->findOrFail($id);
        $p5_industry->restore();

        return redirect()->route('admin.p5_industries.index');
    }

    /**
     * Permanently delete P5Industry from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function perma_del($id)
    {
        $p5_industry = P5Industry::onlyTrashed()->findOrFail($id);
        $p5_industry->forceDelete();

        return redirect()->route('admin.p5_industries.index');
    }
}
