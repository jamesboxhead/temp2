<?php
namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use App\Http\Controllers\Controller;

class P012SurveysController extends Controller
{
    public function index()
    {
        return view('admin.p012_surveys.index');
    }
}
