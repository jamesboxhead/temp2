<?php

namespace App\Http\Controllers\Admin;

use App\P012SurveyLog;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\StoreP012SurveyLogsRequest;
use App\Http\Requests\Admin\UpdateP012SurveyLogsRequest;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Input;

use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
class P012SurveyLogsController extends Controller
{
    /**
     * Display a listing of P012SurveyLog.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if ($filterBy = Input::get('filter')) {
            if ($filterBy == 'all') {
                Session::put('P012SurveyLog.filter', 'all');
            } elseif ($filterBy == 'my') {
                Session::put('P012SurveyLog.filter', 'my');
            }
        }

                $p012_survey_logs = P012SurveyLog::all();

        return view('admin.p012_survey_logs.index', compact('p012_survey_logs'));
    }

    /**
     * Show the form for creating new P012SurveyLog.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        
        $survey_targets = \App\User::get()->pluck('name', 'id')->prepend(trans('global.app_please_select'), '');
        $linked_tasks = \App\Task::get()->pluck('due_date', 'id')->prepend(trans('global.app_please_select'), '');

        return view('admin.p012_survey_logs.create', compact('survey_targets', 'linked_tasks'));
    }

    /**
     * Store a newly created P012SurveyLog in storage.
     *
     * @param  \App\Http\Requests\StoreP012SurveyLogsRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreP012SurveyLogsRequest $request)
    {
        $p012_survey_log = P012SurveyLog::create($request->all());



        return redirect()->route('admin.p012_survey_logs.index');
    }


    /**
     * Show the form for editing P012SurveyLog.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        
        $survey_targets = \App\User::get()->pluck('name', 'id')->prepend(trans('global.app_please_select'), '');
        $linked_tasks = \App\Task::get()->pluck('due_date', 'id')->prepend(trans('global.app_please_select'), '');

        $p012_survey_log = P012SurveyLog::findOrFail($id);

        return view('admin.p012_survey_logs.edit', compact('p012_survey_log', 'survey_targets', 'linked_tasks'));
    }

    /**
     * Update P012SurveyLog in storage.
     *
     * @param  \App\Http\Requests\UpdateP012SurveyLogsRequest  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateP012SurveyLogsRequest $request, $id)
    {
        $p012_survey_log = P012SurveyLog::findOrFail($id);
        $p012_survey_log->update($request->all());



        return redirect()->route('admin.p012_survey_logs.index');
    }


    /**
     * Display P012SurveyLog.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $p012_survey_log = P012SurveyLog::findOrFail($id);

        return view('admin.p012_survey_logs.show', compact('p012_survey_log'));
    }


    /**
     * Remove P012SurveyLog from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $p012_survey_log = P012SurveyLog::findOrFail($id);
        $p012_survey_log->delete();

        return redirect()->route('admin.p012_survey_logs.index');
    }

    /**
     * Delete all selected P012SurveyLog at once.
     *
     * @param Request $request
     */
    public function massDestroy(Request $request)
    {
        if ($request->input('ids')) {
            $entries = P012SurveyLog::whereIn('id', $request->input('ids'))->get();

            foreach ($entries as $entry) {
                $entry->delete();
            }
        }
    }

}
