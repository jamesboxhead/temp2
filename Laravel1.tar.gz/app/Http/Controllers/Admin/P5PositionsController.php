<?php

namespace App\Http\Controllers\Admin;

use App\P5Position;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\StoreP5PositionsRequest;
use App\Http\Requests\Admin\UpdateP5PositionsRequest;

use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
class P5PositionsController extends Controller
{
    /**
     * Display a listing of P5Position.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {


        if (request('show_deleted') == 1) {
            if (! Gate::allows('p5_position_delete')) {
                return abort(401);
            }
            $p5_positions = P5Position::onlyTrashed()->get();
        } else {
            $p5_positions = P5Position::all();
        }

        return view('admin.p5_positions.index', compact('p5_positions'));
    }

    /**
     * Show the form for creating new P5Position.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.p5_positions.create');
    }

    /**
     * Store a newly created P5Position in storage.
     *
     * @param  \App\Http\Requests\StoreP5PositionsRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreP5PositionsRequest $request)
    {
        $p5_position = P5Position::create($request->all());



        return redirect()->route('admin.p5_positions.index');
    }


    /**
     * Show the form for editing P5Position.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $p5_position = P5Position::findOrFail($id);

        return view('admin.p5_positions.edit', compact('p5_position'));
    }

    /**
     * Update P5Position in storage.
     *
     * @param  \App\Http\Requests\UpdateP5PositionsRequest  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateP5PositionsRequest $request, $id)
    {
        $p5_position = P5Position::findOrFail($id);
        $p5_position->update($request->all());



        return redirect()->route('admin.p5_positions.index');
    }


    /**
     * Display P5Position.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $p5_org_pos_user_links = \App\P5OrgPosUserLink::where('org_relationship_id', $id)->get();

        $p5_position = P5Position::findOrFail($id);

        return view('admin.p5_positions.show', compact('p5_position', 'p5_org_pos_user_links'));
    }


    /**
     * Remove P5Position from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $p5_position = P5Position::findOrFail($id);
        $p5_position->delete();

        return redirect()->route('admin.p5_positions.index');
    }

    /**
     * Delete all selected P5Position at once.
     *
     * @param Request $request
     */
    public function massDestroy(Request $request)
    {
        if ($request->input('ids')) {
            $entries = P5Position::whereIn('id', $request->input('ids'))->get();

            foreach ($entries as $entry) {
                $entry->delete();
            }
        }
    }


    /**
     * Restore P5Position from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function restore($id)
    {
        $p5_position = P5Position::onlyTrashed()->findOrFail($id);
        $p5_position->restore();

        return redirect()->route('admin.p5_positions.index');
    }

    /**
     * Permanently delete P5Position from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function perma_del($id)
    {
        $p5_position = P5Position::onlyTrashed()->findOrFail($id);
        $p5_position->forceDelete();

        return redirect()->route('admin.p5_positions.index');
    }
}
