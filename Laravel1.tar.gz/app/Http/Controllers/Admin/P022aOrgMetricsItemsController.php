<?php

namespace App\Http\Controllers\Admin;

use App\P022aOrgMetricsItem;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\StoreP022aOrgMetricsItemsRequest;
use App\Http\Requests\Admin\UpdateP022aOrgMetricsItemsRequest;
use Yajra\DataTables\DataTables;

use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
class P022aOrgMetricsItemsController extends Controller
{
    /**
     * Display a listing of P022aOrgMetricsItem.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {


        
        if (request()->ajax()) {
            $query = P022aOrgMetricsItem::query();
            $query->with("p022a_org_metric_group");
            $template = 'actionsTemplate';
            if(request('show_deleted') == 1) {
                
                $query->onlyTrashed();
                $template = 'restoreTemplate';
            }
            $query->select([
                'p022a_org_metrics_items.id',
                'p022a_org_metrics_items.metric_description',
                'p022a_org_metrics_items.metric_display_format',
                'p022a_org_metrics_items.metric_units',
                'p022a_org_metrics_items.p022a_org_metric_group_id',
                'p022a_org_metrics_items.notes',
                'p022a_org_metrics_items.sort_order',
            ]);
            $table = Datatables::of($query);

            $table->setRowAttr([
                'data-entry-id' => '{{$id}}',
            ]);
            $table->addColumn('massDelete', '&nbsp;');
            $table->addColumn('actions', '&nbsp;');
            $table->editColumn('actions', function ($row) use ($template) {
                $gateKey  = 'p022a_org_metrics_item_';
                $routeKey = 'admin.p022a_org_metrics_items';

                return view($template, compact('row', 'gateKey', 'routeKey'));
            });
            $table->editColumn('metric_description', function ($row) {
                return $row->metric_description ? $row->metric_description : '';
            });
            $table->editColumn('metric_display_format', function ($row) {
                return $row->metric_display_format ? $row->metric_display_format : '';
            });
            $table->editColumn('metric_units', function ($row) {
                return $row->metric_units ? $row->metric_units : '';
            });
            $table->editColumn('p022a_org_metric_group.org_metrics_group', function ($row) {
                return $row->p022a_org_metric_group ? $row->p022a_org_metric_group->org_metrics_group : '';
            });
            $table->editColumn('notes', function ($row) {
                return $row->notes ? $row->notes : '';
            });
            $table->editColumn('sort_order', function ($row) {
                return $row->sort_order ? $row->sort_order : '';
            });

            $table->rawColumns(['actions']);

            return $table->make(true);
        }

        return view('admin.p022a_org_metrics_items.index');
    }

    /**
     * Show the form for creating new P022aOrgMetricsItem.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        
        $p022a_org_metric_groups = \App\P022aOrgMetricsLookupGroup::get()->pluck('org_metrics_group', 'id')->prepend(trans('global.app_please_select'), '');

        return view('admin.p022a_org_metrics_items.create', compact('p022a_org_metric_groups'));
    }

    /**
     * Store a newly created P022aOrgMetricsItem in storage.
     *
     * @param  \App\Http\Requests\StoreP022aOrgMetricsItemsRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreP022aOrgMetricsItemsRequest $request)
    {
        $p022a_org_metrics_item = P022aOrgMetricsItem::create($request->all());



        return redirect()->route('admin.p022a_org_metrics_items.index');
    }


    /**
     * Show the form for editing P022aOrgMetricsItem.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        
        $p022a_org_metric_groups = \App\P022aOrgMetricsLookupGroup::get()->pluck('org_metrics_group', 'id')->prepend(trans('global.app_please_select'), '');

        $p022a_org_metrics_item = P022aOrgMetricsItem::findOrFail($id);

        return view('admin.p022a_org_metrics_items.edit', compact('p022a_org_metrics_item', 'p022a_org_metric_groups'));
    }

    /**
     * Update P022aOrgMetricsItem in storage.
     *
     * @param  \App\Http\Requests\UpdateP022aOrgMetricsItemsRequest  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateP022aOrgMetricsItemsRequest $request, $id)
    {
        $p022a_org_metrics_item = P022aOrgMetricsItem::findOrFail($id);
        $p022a_org_metrics_item->update($request->all());



        return redirect()->route('admin.p022a_org_metrics_items.index');
    }


    /**
     * Display P022aOrgMetricsItem.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        
        $p022a_org_metric_groups = \App\P022aOrgMetricsLookupGroup::get()->pluck('org_metrics_group', 'id')->prepend(trans('global.app_please_select'), '');$p022a_org_metrics_details = \App\P022aOrgMetricsDetail::where('result_p022_org_metrics_lookup_id', $id)->get();

        $p022a_org_metrics_item = P022aOrgMetricsItem::findOrFail($id);

        return view('admin.p022a_org_metrics_items.show', compact('p022a_org_metrics_item', 'p022a_org_metrics_details'));
    }


    /**
     * Remove P022aOrgMetricsItem from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $p022a_org_metrics_item = P022aOrgMetricsItem::findOrFail($id);
        $p022a_org_metrics_item->delete();

        return redirect()->route('admin.p022a_org_metrics_items.index');
    }

    /**
     * Delete all selected P022aOrgMetricsItem at once.
     *
     * @param Request $request
     */
    public function massDestroy(Request $request)
    {
        if ($request->input('ids')) {
            $entries = P022aOrgMetricsItem::whereIn('id', $request->input('ids'))->get();

            foreach ($entries as $entry) {
                $entry->delete();
            }
        }
    }


    /**
     * Restore P022aOrgMetricsItem from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function restore($id)
    {
        $p022a_org_metrics_item = P022aOrgMetricsItem::onlyTrashed()->findOrFail($id);
        $p022a_org_metrics_item->restore();

        return redirect()->route('admin.p022a_org_metrics_items.index');
    }

    /**
     * Permanently delete P022aOrgMetricsItem from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function perma_del($id)
    {
        $p022a_org_metrics_item = P022aOrgMetricsItem::onlyTrashed()->findOrFail($id);
        $p022a_org_metrics_item->forceDelete();

        return redirect()->route('admin.p022a_org_metrics_items.index');
    }
}
