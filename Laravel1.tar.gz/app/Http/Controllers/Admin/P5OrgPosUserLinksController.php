<?php

namespace App\Http\Controllers\Admin;

use App\P5OrgPosUserLink;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\StoreP5OrgPosUserLinksRequest;
use App\Http\Requests\Admin\UpdateP5OrgPosUserLinksRequest;
use Yajra\DataTables\DataTables;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Input;

use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
class P5OrgPosUserLinksController extends Controller
{
    /**
     * Display a listing of P5OrgPosUserLink.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if ($filterBy = Input::get('filter')) {
            if ($filterBy == 'all') {
                Session::put('P5OrgPosUserLink.filter', 'all');
            } elseif ($filterBy == 'my') {
                Session::put('P5OrgPosUserLink.filter', 'my');
            }
        }

        
        if (request()->ajax()) {
            $query = P5OrgPosUserLink::query();
            $query->with("username");
            $query->with("org_link");
            $query->with("org_relationship");
            $query->with("created_by");
            $template = 'actionsTemplate';
            
            $query->select([
                'p5_org_pos_user_links.id',
                'p5_org_pos_user_links.username_id',
                'p5_org_pos_user_links.org_link_id',
                'p5_org_pos_user_links.org_relationship_id',
                'p5_org_pos_user_links.relationship_is_current',
                'p5_org_pos_user_links.relationship_started',
                'p5_org_pos_user_links.relationship_ended',
                'p5_org_pos_user_links.notes',
                'p5_org_pos_user_links.dq',
                'p5_org_pos_user_links.created_by_id',
            ]);
            $table = Datatables::of($query);

            $table->setRowAttr([
                'data-entry-id' => '{{$id}}',
            ]);
            $table->addColumn('massDelete', '&nbsp;');
            $table->addColumn('actions', '&nbsp;');
            $table->editColumn('actions', function ($row) use ($template) {
                $gateKey  = 'p5_org_pos_user_link_';
                $routeKey = 'admin.p5_org_pos_user_links';

                return view($template, compact('row', 'gateKey', 'routeKey'));
            });
            $table->editColumn('username.name', function ($row) {
                return $row->username ? $row->username->name : '';
            });
            $table->editColumn('org_link.trading_name', function ($row) {
                return $row->org_link ? $row->org_link->trading_name : '';
            });
            $table->editColumn('org_relationship.pos_title', function ($row) {
                return $row->org_relationship ? $row->org_relationship->pos_title : '';
            });
            $table->editColumn('relationship_is_current', function ($row) {
                return \Form::checkbox("relationship_is_current", 1, $row->relationship_is_current == 1, ["disabled"]);
            });
            $table->editColumn('relationship_started', function ($row) {
                return $row->relationship_started ? $row->relationship_started : '';
            });
            $table->editColumn('relationship_ended', function ($row) {
                return $row->relationship_ended ? $row->relationship_ended : '';
            });
            $table->editColumn('notes', function ($row) {
                return $row->notes ? $row->notes : '';
            });
            $table->editColumn('dq', function ($row) {
                return $row->dq ? $row->dq : '';
            });
            $table->editColumn('created_by.name', function ($row) {
                return $row->created_by ? $row->created_by->name : '';
            });

            $table->rawColumns(['actions','relationship_is_current']);

            return $table->make(true);
        }

        return view('admin.p5_org_pos_user_links.index');
    }

    /**
     * Show the form for creating new P5OrgPosUserLink.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        
        $usernames = \App\User::get()->pluck('name', 'id')->prepend(trans('global.app_please_select'), '');
        $org_links = \App\P5Organisation::get()->pluck('trading_name', 'id')->prepend(trans('global.app_please_select'), '');
        $org_relationships = \App\P5Position::get()->pluck('pos_title', 'id')->prepend(trans('global.app_please_select'), '');
        $created_bies = \App\User::get()->pluck('name', 'id')->prepend(trans('global.app_please_select'), '');

        return view('admin.p5_org_pos_user_links.create', compact('usernames', 'org_links', 'org_relationships', 'created_bies'));
    }

    /**
     * Store a newly created P5OrgPosUserLink in storage.
     *
     * @param  \App\Http\Requests\StoreP5OrgPosUserLinksRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreP5OrgPosUserLinksRequest $request)
    {
        $p5_org_pos_user_link = P5OrgPosUserLink::create($request->all());



        return redirect()->route('admin.p5_org_pos_user_links.index');
    }


    /**
     * Show the form for editing P5OrgPosUserLink.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        
        $usernames = \App\User::get()->pluck('name', 'id')->prepend(trans('global.app_please_select'), '');
        $org_links = \App\P5Organisation::get()->pluck('trading_name', 'id')->prepend(trans('global.app_please_select'), '');
        $org_relationships = \App\P5Position::get()->pluck('pos_title', 'id')->prepend(trans('global.app_please_select'), '');
        $created_bies = \App\User::get()->pluck('name', 'id')->prepend(trans('global.app_please_select'), '');

        $p5_org_pos_user_link = P5OrgPosUserLink::findOrFail($id);

        return view('admin.p5_org_pos_user_links.edit', compact('p5_org_pos_user_link', 'usernames', 'org_links', 'org_relationships', 'created_bies'));
    }

    /**
     * Update P5OrgPosUserLink in storage.
     *
     * @param  \App\Http\Requests\UpdateP5OrgPosUserLinksRequest  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateP5OrgPosUserLinksRequest $request, $id)
    {
        $p5_org_pos_user_link = P5OrgPosUserLink::findOrFail($id);
        $p5_org_pos_user_link->update($request->all());



        return redirect()->route('admin.p5_org_pos_user_links.index');
    }


    /**
     * Display P5OrgPosUserLink.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $p5_org_pos_user_link = P5OrgPosUserLink::findOrFail($id);

        return view('admin.p5_org_pos_user_links.show', compact('p5_org_pos_user_link'));
    }


    /**
     * Remove P5OrgPosUserLink from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $p5_org_pos_user_link = P5OrgPosUserLink::findOrFail($id);
        $p5_org_pos_user_link->delete();

        return redirect()->route('admin.p5_org_pos_user_links.index');
    }

    /**
     * Delete all selected P5OrgPosUserLink at once.
     *
     * @param Request $request
     */
    public function massDestroy(Request $request)
    {
        if ($request->input('ids')) {
            $entries = P5OrgPosUserLink::whereIn('id', $request->input('ids'))->get();

            foreach ($entries as $entry) {
                $entry->delete();
            }
        }
    }

}
