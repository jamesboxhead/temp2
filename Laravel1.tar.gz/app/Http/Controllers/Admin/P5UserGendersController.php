<?php

namespace App\Http\Controllers\Admin;

use App\P5UserGender;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\StoreP5UserGendersRequest;
use App\Http\Requests\Admin\UpdateP5UserGendersRequest;
use Yajra\DataTables\DataTables;

use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
class P5UserGendersController extends Controller
{
    /**
     * Display a listing of P5UserGender.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {


        
        if (request()->ajax()) {
            $query = P5UserGender::query();
            $template = 'actionsTemplate';
            if(request('show_deleted') == 1) {
                
                $query->onlyTrashed();
                $template = 'restoreTemplate';
            }
            $query->select([
                'p5_user_genders.id',
                'p5_user_genders.gender_description',
                'p5_user_genders.gender_code',
                'p5_user_genders.gender_fa_icon',
                'p5_user_genders.sort_code',
            ]);
            $table = Datatables::of($query);

            $table->setRowAttr([
                'data-entry-id' => '{{$id}}',
            ]);
            $table->addColumn('massDelete', '&nbsp;');
            $table->addColumn('actions', '&nbsp;');
            $table->editColumn('actions', function ($row) use ($template) {
                $gateKey  = 'p5_user_gender_';
                $routeKey = 'admin.p5_user_genders';

                return view($template, compact('row', 'gateKey', 'routeKey'));
            });
            $table->editColumn('gender_description', function ($row) {
                return $row->gender_description ? $row->gender_description : '';
            });
            $table->editColumn('gender_code', function ($row) {
                return $row->gender_code ? $row->gender_code : '';
            });
            $table->editColumn('gender_fa_icon', function ($row) {
                return $row->gender_fa_icon ? $row->gender_fa_icon : '';
            });
            $table->editColumn('sort_code', function ($row) {
                return $row->sort_code ? $row->sort_code : '';
            });

            $table->rawColumns(['actions']);

            return $table->make(true);
        }

        return view('admin.p5_user_genders.index');
    }

    /**
     * Show the form for creating new P5UserGender.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.p5_user_genders.create');
    }

    /**
     * Store a newly created P5UserGender in storage.
     *
     * @param  \App\Http\Requests\StoreP5UserGendersRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreP5UserGendersRequest $request)
    {
        $p5_user_gender = P5UserGender::create($request->all());



        return redirect()->route('admin.p5_user_genders.index');
    }


    /**
     * Show the form for editing P5UserGender.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $p5_user_gender = P5UserGender::findOrFail($id);

        return view('admin.p5_user_genders.edit', compact('p5_user_gender'));
    }

    /**
     * Update P5UserGender in storage.
     *
     * @param  \App\Http\Requests\UpdateP5UserGendersRequest  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateP5UserGendersRequest $request, $id)
    {
        $p5_user_gender = P5UserGender::findOrFail($id);
        $p5_user_gender->update($request->all());



        return redirect()->route('admin.p5_user_genders.index');
    }


    /**
     * Display P5UserGender.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $users = \App\User::where('linked_gender_id', $id)->get();

        $p5_user_gender = P5UserGender::findOrFail($id);

        return view('admin.p5_user_genders.show', compact('p5_user_gender', 'users'));
    }


    /**
     * Remove P5UserGender from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $p5_user_gender = P5UserGender::findOrFail($id);
        $p5_user_gender->delete();

        return redirect()->route('admin.p5_user_genders.index');
    }

    /**
     * Delete all selected P5UserGender at once.
     *
     * @param Request $request
     */
    public function massDestroy(Request $request)
    {
        if ($request->input('ids')) {
            $entries = P5UserGender::whereIn('id', $request->input('ids'))->get();

            foreach ($entries as $entry) {
                $entry->delete();
            }
        }
    }


    /**
     * Restore P5UserGender from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function restore($id)
    {
        $p5_user_gender = P5UserGender::onlyTrashed()->findOrFail($id);
        $p5_user_gender->restore();

        return redirect()->route('admin.p5_user_genders.index');
    }

    /**
     * Permanently delete P5UserGender from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function perma_del($id)
    {
        $p5_user_gender = P5UserGender::onlyTrashed()->findOrFail($id);
        $p5_user_gender->forceDelete();

        return redirect()->route('admin.p5_user_genders.index');
    }
}
