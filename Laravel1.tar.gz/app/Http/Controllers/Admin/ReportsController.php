<?php
namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\UserAction;
use App\Task;

class ReportsController extends Controller
{
    public function test1Users()
    {
        $reportTitle = 'test1 users';
        $reportLabel = 'COUNT';
        $chartType   = 'line';

        $results = UserAction::get()->sortBy('created_at')->groupBy(function ($entry) {
            if ($entry->created_at instanceof \Carbon\Carbon) {
                return \Carbon\Carbon::parse($entry->created_at)->format('Y-m-d');
            }

            return \Carbon\Carbon::createFromFormat(config('app.date_format'), $entry->created_at)->format('Y-m-d');
        })->map(function ($entries, $group) {
            return $entries->count('id');
        });

        return view('admin.reports', compact('reportTitle', 'results', 'chartType', 'reportLabel'));
    }

    public function 11MeetingMinutes()
    {
        $reportTitle = '1:1 Meeting Minutes ';
        $reportLabel = 'SUM';
        $chartType   = 'bar';

        $results = Task::get()->sortBy('due_date')->groupBy(function ($entry) {
            if ($entry->due_date instanceof \Carbon\Carbon) {
                return \Carbon\Carbon::parse($entry->due_date)->format('Y-m-d');
            }

            return \Carbon\Carbon::createFromFormat(config('app.date_format'), $entry->due_date)->format('Y-m-d');
        })->map(function ($entries, $group) {
            return $entries->sum('meeting_time');
        });

        return view('admin.reports', compact('reportTitle', 'results', 'chartType', 'reportLabel'));
    }

}
