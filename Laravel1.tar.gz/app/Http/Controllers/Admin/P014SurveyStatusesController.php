<?php
namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use App\Http\Controllers\Controller;

class P014SurveyStatusesController extends Controller
{
    public function index()
    {
        return view('admin.p014_survey_statuses.index');
    }
}
