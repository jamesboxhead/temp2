<?php

namespace App\Http\Controllers\Admin;

use App\P023DataStandard;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\StoreP023DataStandardsRequest;
use App\Http\Requests\Admin\UpdateP023DataStandardsRequest;
use Yajra\DataTables\DataTables;

use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
class P023DataStandardsController extends Controller
{
    /**
     * Display a listing of P023DataStandard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {


        
        if (request()->ajax()) {
            $query = P023DataStandard::query();
            $template = 'actionsTemplate';
            if(request('show_deleted') == 1) {
                
                $query->onlyTrashed();
                $template = 'restoreTemplate';
            }
            $query->select([
                'p023_data_standards.id',
                'p023_data_standards.data_standard_code',
                'p023_data_standards.data_standard_short',
                'p023_data_standards.data_standard_fa_icon',
                'p023_data_standards.data_standard_notes',
                'p023_data_standards.dash_board_title',
                'p023_data_standards.dash_board_x_label',
                'p023_data_standards.dash_board_y_label',
                'p023_data_standards.dash_board_attr1',
                'p023_data_standards.dash_board_attr2',
                'p023_data_standards.dash_board_attr3',
                'p023_data_standards.dash_board_attr4',
                'p023_data_standards.dash_board_attr5',
                'p023_data_standards.dash_board_notes',
                'p023_data_standards.dash_board_short_notes',
            ]);
            $table = Datatables::of($query);

            $table->setRowAttr([
                'data-entry-id' => '{{$id}}',
            ]);
            $table->addColumn('massDelete', '&nbsp;');
            $table->addColumn('actions', '&nbsp;');
            $table->editColumn('actions', function ($row) use ($template) {
                $gateKey  = 'p023_data_standard_';
                $routeKey = 'admin.p023_data_standards';

                return view($template, compact('row', 'gateKey', 'routeKey'));
            });
            $table->editColumn('data_standard_code', function ($row) {
                return $row->data_standard_code ? $row->data_standard_code : '';
            });
            $table->editColumn('data_standard_short', function ($row) {
                return $row->data_standard_short ? $row->data_standard_short : '';
            });
            $table->editColumn('data_standard_fa_icon', function ($row) {
                return $row->data_standard_fa_icon ? $row->data_standard_fa_icon : '';
            });
            $table->editColumn('data_standard_notes', function ($row) {
                return $row->data_standard_notes ? $row->data_standard_notes : '';
            });
            $table->editColumn('dash_board_title', function ($row) {
                return $row->dash_board_title ? $row->dash_board_title : '';
            });
            $table->editColumn('dash_board_x_label', function ($row) {
                return $row->dash_board_x_label ? $row->dash_board_x_label : '';
            });
            $table->editColumn('dash_board_y_label', function ($row) {
                return $row->dash_board_y_label ? $row->dash_board_y_label : '';
            });
            $table->editColumn('dash_board_attr1', function ($row) {
                return $row->dash_board_attr1 ? $row->dash_board_attr1 : '';
            });
            $table->editColumn('dash_board_attr2', function ($row) {
                return $row->dash_board_attr2 ? $row->dash_board_attr2 : '';
            });
            $table->editColumn('dash_board_attr3', function ($row) {
                return $row->dash_board_attr3 ? $row->dash_board_attr3 : '';
            });
            $table->editColumn('dash_board_attr4', function ($row) {
                return $row->dash_board_attr4 ? $row->dash_board_attr4 : '';
            });
            $table->editColumn('dash_board_attr5', function ($row) {
                return $row->dash_board_attr5 ? $row->dash_board_attr5 : '';
            });
            $table->editColumn('dash_board_notes', function ($row) {
                return $row->dash_board_notes ? $row->dash_board_notes : '';
            });
            $table->editColumn('dash_board_short_notes', function ($row) {
                return $row->dash_board_short_notes ? $row->dash_board_short_notes : '';
            });

            $table->rawColumns(['actions']);

            return $table->make(true);
        }

        return view('admin.p023_data_standards.index');
    }

    /**
     * Show the form for creating new P023DataStandard.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.p023_data_standards.create');
    }

    /**
     * Store a newly created P023DataStandard in storage.
     *
     * @param  \App\Http\Requests\StoreP023DataStandardsRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreP023DataStandardsRequest $request)
    {
        $p023_data_standard = P023DataStandard::create($request->all());



        return redirect()->route('admin.p023_data_standards.index');
    }


    /**
     * Show the form for editing P023DataStandard.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $p023_data_standard = P023DataStandard::findOrFail($id);

        return view('admin.p023_data_standards.edit', compact('p023_data_standard'));
    }

    /**
     * Update P023DataStandard in storage.
     *
     * @param  \App\Http\Requests\UpdateP023DataStandardsRequest  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateP023DataStandardsRequest $request, $id)
    {
        $p023_data_standard = P023DataStandard::findOrFail($id);
        $p023_data_standard->update($request->all());



        return redirect()->route('admin.p023_data_standards.index');
    }


    /**
     * Display P023DataStandard.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $p023_data_submissions = \App\P023DataSubmission::where('linked_p023_data_standards_id', $id)->get();

        $p023_data_standard = P023DataStandard::findOrFail($id);

        return view('admin.p023_data_standards.show', compact('p023_data_standard', 'p023_data_submissions'));
    }


    /**
     * Remove P023DataStandard from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $p023_data_standard = P023DataStandard::findOrFail($id);
        $p023_data_standard->delete();

        return redirect()->route('admin.p023_data_standards.index');
    }

    /**
     * Delete all selected P023DataStandard at once.
     *
     * @param Request $request
     */
    public function massDestroy(Request $request)
    {
        if ($request->input('ids')) {
            $entries = P023DataStandard::whereIn('id', $request->input('ids'))->get();

            foreach ($entries as $entry) {
                $entry->delete();
            }
        }
    }


    /**
     * Restore P023DataStandard from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function restore($id)
    {
        $p023_data_standard = P023DataStandard::onlyTrashed()->findOrFail($id);
        $p023_data_standard->restore();

        return redirect()->route('admin.p023_data_standards.index');
    }

    /**
     * Permanently delete P023DataStandard from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function perma_del($id)
    {
        $p023_data_standard = P023DataStandard::onlyTrashed()->findOrFail($id);
        $p023_data_standard->forceDelete();

        return redirect()->route('admin.p023_data_standards.index');
    }
}
