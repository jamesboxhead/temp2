<?php
namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use App\Http\Controllers\Controller;

class P022aMetricsDataEntryForm1sController extends Controller
{
    public function index()
    {
        return view('admin.p022a_metrics_data_entry_form1s.index');
    }
}
