<?php

namespace App\Http\Controllers\Admin;

use App\P5HubMembershipType;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\StoreP5HubMembershipTypesRequest;
use App\Http\Requests\Admin\UpdateP5HubMembershipTypesRequest;
use Yajra\DataTables\DataTables;

use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
class P5HubMembershipTypesController extends Controller
{
    /**
     * Display a listing of P5HubMembershipType.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {


        
        if (request()->ajax()) {
            $query = P5HubMembershipType::query();
            $template = 'actionsTemplate';
            if(request('show_deleted') == 1) {
                
                $query->onlyTrashed();
                $template = 'restoreTemplate';
            }
            $query->select([
                'p5_hub_membership_types.id',
                'p5_hub_membership_types.description',
                'p5_hub_membership_types.sort_order',
                'p5_hub_membership_types.dq',
            ]);
            $table = Datatables::of($query);

            $table->setRowAttr([
                'data-entry-id' => '{{$id}}',
            ]);
            $table->addColumn('massDelete', '&nbsp;');
            $table->addColumn('actions', '&nbsp;');
            $table->editColumn('actions', function ($row) use ($template) {
                $gateKey  = 'p5_hub_membership_type_';
                $routeKey = 'admin.p5_hub_membership_types';

                return view($template, compact('row', 'gateKey', 'routeKey'));
            });
            $table->editColumn('description', function ($row) {
                return $row->description ? $row->description : '';
            });
            $table->editColumn('sort_order', function ($row) {
                return $row->sort_order ? $row->sort_order : '';
            });
            $table->editColumn('dq', function ($row) {
                return $row->dq ? $row->dq : '';
            });

            $table->rawColumns(['actions']);

            return $table->make(true);
        }

        return view('admin.p5_hub_membership_types.index');
    }

    /**
     * Show the form for creating new P5HubMembershipType.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.p5_hub_membership_types.create');
    }

    /**
     * Store a newly created P5HubMembershipType in storage.
     *
     * @param  \App\Http\Requests\StoreP5HubMembershipTypesRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreP5HubMembershipTypesRequest $request)
    {
        $p5_hub_membership_type = P5HubMembershipType::create($request->all());



        return redirect()->route('admin.p5_hub_membership_types.index');
    }


    /**
     * Show the form for editing P5HubMembershipType.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $p5_hub_membership_type = P5HubMembershipType::findOrFail($id);

        return view('admin.p5_hub_membership_types.edit', compact('p5_hub_membership_type'));
    }

    /**
     * Update P5HubMembershipType in storage.
     *
     * @param  \App\Http\Requests\UpdateP5HubMembershipTypesRequest  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateP5HubMembershipTypesRequest $request, $id)
    {
        $p5_hub_membership_type = P5HubMembershipType::findOrFail($id);
        $p5_hub_membership_type->update($request->all());



        return redirect()->route('admin.p5_hub_membership_types.index');
    }


    /**
     * Display P5HubMembershipType.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $p5_hub_memberships = \App\P5HubMembership::where('member_type_id', $id)->get();$p5_hub_memberships_individuals = \App\P5HubMembershipsIndividual::where('member_type_id', $id)->get();

        $p5_hub_membership_type = P5HubMembershipType::findOrFail($id);

        return view('admin.p5_hub_membership_types.show', compact('p5_hub_membership_type', 'p5_hub_memberships', 'p5_hub_memberships_individuals'));
    }


    /**
     * Remove P5HubMembershipType from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $p5_hub_membership_type = P5HubMembershipType::findOrFail($id);
        $p5_hub_membership_type->delete();

        return redirect()->route('admin.p5_hub_membership_types.index');
    }

    /**
     * Delete all selected P5HubMembershipType at once.
     *
     * @param Request $request
     */
    public function massDestroy(Request $request)
    {
        if ($request->input('ids')) {
            $entries = P5HubMembershipType::whereIn('id', $request->input('ids'))->get();

            foreach ($entries as $entry) {
                $entry->delete();
            }
        }
    }


    /**
     * Restore P5HubMembershipType from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function restore($id)
    {
        $p5_hub_membership_type = P5HubMembershipType::onlyTrashed()->findOrFail($id);
        $p5_hub_membership_type->restore();

        return redirect()->route('admin.p5_hub_membership_types.index');
    }

    /**
     * Permanently delete P5HubMembershipType from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function perma_del($id)
    {
        $p5_hub_membership_type = P5HubMembershipType::onlyTrashed()->findOrFail($id);
        $p5_hub_membership_type->forceDelete();

        return redirect()->route('admin.p5_hub_membership_types.index');
    }
}
