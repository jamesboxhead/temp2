<?php

namespace App\Http\Controllers\Admin;

use App\P5InvestmentSource;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\StoreP5InvestmentSourcesRequest;
use App\Http\Requests\Admin\UpdateP5InvestmentSourcesRequest;
use Yajra\DataTables\DataTables;

use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
class P5InvestmentSourcesController extends Controller
{
    /**
     * Display a listing of P5InvestmentSource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {


        
        if (request()->ajax()) {
            $query = P5InvestmentSource::query();
            $template = 'actionsTemplate';
            if(request('show_deleted') == 1) {
                
                $query->onlyTrashed();
                $template = 'restoreTemplate';
            }
            $query->select([
                'p5_investment_sources.id',
                'p5_investment_sources.investment_source_description',
                'p5_investment_sources.sort_code',
            ]);
            $table = Datatables::of($query);

            $table->setRowAttr([
                'data-entry-id' => '{{$id}}',
            ]);
            $table->addColumn('massDelete', '&nbsp;');
            $table->addColumn('actions', '&nbsp;');
            $table->editColumn('actions', function ($row) use ($template) {
                $gateKey  = 'p5_investment_source_';
                $routeKey = 'admin.p5_investment_sources';

                return view($template, compact('row', 'gateKey', 'routeKey'));
            });
            $table->editColumn('investment_source_description', function ($row) {
                return $row->investment_source_description ? $row->investment_source_description : '';
            });
            $table->editColumn('sort_code', function ($row) {
                return $row->sort_code ? $row->sort_code : '';
            });

            $table->rawColumns(['actions']);

            return $table->make(true);
        }

        return view('admin.p5_investment_sources.index');
    }

    /**
     * Show the form for creating new P5InvestmentSource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.p5_investment_sources.create');
    }

    /**
     * Store a newly created P5InvestmentSource in storage.
     *
     * @param  \App\Http\Requests\StoreP5InvestmentSourcesRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreP5InvestmentSourcesRequest $request)
    {
        $p5_investment_source = P5InvestmentSource::create($request->all());



        return redirect()->route('admin.p5_investment_sources.index');
    }


    /**
     * Show the form for editing P5InvestmentSource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $p5_investment_source = P5InvestmentSource::findOrFail($id);

        return view('admin.p5_investment_sources.edit', compact('p5_investment_source'));
    }

    /**
     * Update P5InvestmentSource in storage.
     *
     * @param  \App\Http\Requests\UpdateP5InvestmentSourcesRequest  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateP5InvestmentSourcesRequest $request, $id)
    {
        $p5_investment_source = P5InvestmentSource::findOrFail($id);
        $p5_investment_source->update($request->all());



        return redirect()->route('admin.p5_investment_sources.index');
    }


    /**
     * Display P5InvestmentSource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $p5_investments = \App\P5Investment::where('p5_actual_investment_souce_id', $id)->get();

        $p5_investment_source = P5InvestmentSource::findOrFail($id);

        return view('admin.p5_investment_sources.show', compact('p5_investment_source', 'p5_investments'));
    }


    /**
     * Remove P5InvestmentSource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $p5_investment_source = P5InvestmentSource::findOrFail($id);
        $p5_investment_source->delete();

        return redirect()->route('admin.p5_investment_sources.index');
    }

    /**
     * Delete all selected P5InvestmentSource at once.
     *
     * @param Request $request
     */
    public function massDestroy(Request $request)
    {
        if ($request->input('ids')) {
            $entries = P5InvestmentSource::whereIn('id', $request->input('ids'))->get();

            foreach ($entries as $entry) {
                $entry->delete();
            }
        }
    }


    /**
     * Restore P5InvestmentSource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function restore($id)
    {
        $p5_investment_source = P5InvestmentSource::onlyTrashed()->findOrFail($id);
        $p5_investment_source->restore();

        return redirect()->route('admin.p5_investment_sources.index');
    }

    /**
     * Permanently delete P5InvestmentSource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function perma_del($id)
    {
        $p5_investment_source = P5InvestmentSource::onlyTrashed()->findOrFail($id);
        $p5_investment_source->forceDelete();

        return redirect()->route('admin.p5_investment_sources.index');
    }
}
