<?php

namespace App\Http\Controllers\Admin;

use App\P5HubMembershipsStatus;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\StoreP5HubMembershipsStatusesRequest;
use App\Http\Requests\Admin\UpdateP5HubMembershipsStatusesRequest;
use Yajra\DataTables\DataTables;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Input;

use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
class P5HubMembershipsStatusesController extends Controller
{
    /**
     * Display a listing of P5HubMembershipsStatus.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if ($filterBy = Input::get('filter')) {
            if ($filterBy == 'all') {
                Session::put('P5HubMembershipsStatus.filter', 'all');
            } elseif ($filterBy == 'my') {
                Session::put('P5HubMembershipsStatus.filter', 'my');
            }
        }

        
        if (request()->ajax()) {
            $query = P5HubMembershipsStatus::query();
            $query->with("created_by");
            $template = 'actionsTemplate';
            if(request('show_deleted') == 1) {
                
                $query->onlyTrashed();
                $template = 'restoreTemplate';
            }
            $query->select([
                'p5_hub_memberships_statuses.id',
                'p5_hub_memberships_statuses.status_code',
                'p5_hub_memberships_statuses.status',
                'p5_hub_memberships_statuses.sort_code',
                'p5_hub_memberships_statuses.status_notes',
                'p5_hub_memberships_statuses.dq',
                'p5_hub_memberships_statuses.created_by_id',
            ]);
            $table = Datatables::of($query);

            $table->setRowAttr([
                'data-entry-id' => '{{$id}}',
            ]);
            $table->addColumn('massDelete', '&nbsp;');
            $table->addColumn('actions', '&nbsp;');
            $table->editColumn('actions', function ($row) use ($template) {
                $gateKey  = 'p5_hub_memberships_status_';
                $routeKey = 'admin.p5_hub_memberships_statuses';

                return view($template, compact('row', 'gateKey', 'routeKey'));
            });
            $table->editColumn('status_code', function ($row) {
                return $row->status_code ? $row->status_code : '';
            });
            $table->editColumn('status', function ($row) {
                return $row->status ? $row->status : '';
            });
            $table->editColumn('sort_code', function ($row) {
                return $row->sort_code ? $row->sort_code : '';
            });
            $table->editColumn('status_notes', function ($row) {
                return $row->status_notes ? $row->status_notes : '';
            });
            $table->editColumn('dq', function ($row) {
                return $row->dq ? $row->dq : '';
            });
            $table->editColumn('created_by.name', function ($row) {
                return $row->created_by ? $row->created_by->name : '';
            });

            $table->rawColumns(['actions']);

            return $table->make(true);
        }

        return view('admin.p5_hub_memberships_statuses.index');
    }

    /**
     * Show the form for creating new P5HubMembershipsStatus.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        
        $created_bies = \App\User::get()->pluck('name', 'id')->prepend(trans('global.app_please_select'), '');

        return view('admin.p5_hub_memberships_statuses.create', compact('created_bies'));
    }

    /**
     * Store a newly created P5HubMembershipsStatus in storage.
     *
     * @param  \App\Http\Requests\StoreP5HubMembershipsStatusesRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreP5HubMembershipsStatusesRequest $request)
    {
        $p5_hub_memberships_status = P5HubMembershipsStatus::create($request->all());



        return redirect()->route('admin.p5_hub_memberships_statuses.index');
    }


    /**
     * Show the form for editing P5HubMembershipsStatus.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        
        $created_bies = \App\User::get()->pluck('name', 'id')->prepend(trans('global.app_please_select'), '');

        $p5_hub_memberships_status = P5HubMembershipsStatus::findOrFail($id);

        return view('admin.p5_hub_memberships_statuses.edit', compact('p5_hub_memberships_status', 'created_bies'));
    }

    /**
     * Update P5HubMembershipsStatus in storage.
     *
     * @param  \App\Http\Requests\UpdateP5HubMembershipsStatusesRequest  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateP5HubMembershipsStatusesRequest $request, $id)
    {
        $p5_hub_memberships_status = P5HubMembershipsStatus::findOrFail($id);
        $p5_hub_memberships_status->update($request->all());



        return redirect()->route('admin.p5_hub_memberships_statuses.index');
    }


    /**
     * Display P5HubMembershipsStatus.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        
        $created_bies = \App\User::get()->pluck('name', 'id')->prepend(trans('global.app_please_select'), '');$p5_hub_memberships = \App\P5HubMembership::where('link_hub_membership_status_id', $id)->get();$p5_hub_memberships_individuals = \App\P5HubMembershipsIndividual::where('linked_hub_membership_status_id', $id)->get();

        $p5_hub_memberships_status = P5HubMembershipsStatus::findOrFail($id);

        return view('admin.p5_hub_memberships_statuses.show', compact('p5_hub_memberships_status', 'p5_hub_memberships', 'p5_hub_memberships_individuals'));
    }


    /**
     * Remove P5HubMembershipsStatus from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $p5_hub_memberships_status = P5HubMembershipsStatus::findOrFail($id);
        $p5_hub_memberships_status->delete();

        return redirect()->route('admin.p5_hub_memberships_statuses.index');
    }

    /**
     * Delete all selected P5HubMembershipsStatus at once.
     *
     * @param Request $request
     */
    public function massDestroy(Request $request)
    {
        if ($request->input('ids')) {
            $entries = P5HubMembershipsStatus::whereIn('id', $request->input('ids'))->get();

            foreach ($entries as $entry) {
                $entry->delete();
            }
        }
    }


    /**
     * Restore P5HubMembershipsStatus from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function restore($id)
    {
        $p5_hub_memberships_status = P5HubMembershipsStatus::onlyTrashed()->findOrFail($id);
        $p5_hub_memberships_status->restore();

        return redirect()->route('admin.p5_hub_memberships_statuses.index');
    }

    /**
     * Permanently delete P5HubMembershipsStatus from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function perma_del($id)
    {
        $p5_hub_memberships_status = P5HubMembershipsStatus::onlyTrashed()->findOrFail($id);
        $p5_hub_memberships_status->forceDelete();

        return redirect()->route('admin.p5_hub_memberships_statuses.index');
    }
}
