<?php

namespace App\Http\Controllers\Admin;

use App\P5HubMembership;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\StoreP5HubMembershipsRequest;
use App\Http\Requests\Admin\UpdateP5HubMembershipsRequest;
use Yajra\DataTables\DataTables;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Input;

use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
class P5HubMembershipsController extends Controller
{
    /**
     * Display a listing of P5HubMembership.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if ($filterBy = Input::get('filter')) {
            if ($filterBy == 'all') {
                Session::put('P5HubMembership.filter', 'all');
            } elseif ($filterBy == 'my') {
                Session::put('P5HubMembership.filter', 'my');
            }
        }

        
        if (request()->ajax()) {
            $query = P5HubMembership::query();
            $query->with("hub");
            $query->with("organisation");
            $query->with("member_type");
            $query->with("link_hub_membership_status");
            $query->with("linked_membership_class");
            $query->with("created_by");
            $template = 'actionsTemplate';
            if(request('show_deleted') == 1) {
                
                $query->onlyTrashed();
                $template = 'restoreTemplate';
            }
            $query->select([
                'p5_hub_memberships.id',
                'p5_hub_memberships.hub_id',
                'p5_hub_memberships.organisation_id',
                'p5_hub_memberships.member_type_id',
                'p5_hub_memberships.link_hub_membership_status_id',
                'p5_hub_memberships.linked_membership_class_id',
                'p5_hub_memberships.membership_number',
                'p5_hub_memberships.membership_start',
                'p5_hub_memberships.membership_end',
                'p5_hub_memberships.billing_fee',
                'p5_hub_memberships.billing_period',
                'p5_hub_memberships.billing_payment_method',
                'p5_hub_memberships.on_group_facebook',
                'p5_hub_memberships.on_group_mailer',
                'p5_hub_memberships.on_group_meetup',
                'p5_hub_memberships.on_signup_sheet',
                'p5_hub_memberships.notes',
                'p5_hub_memberships.dq',
                'p5_hub_memberships.created_by_id',
            ]);
            $table = Datatables::of($query);

            $table->setRowAttr([
                'data-entry-id' => '{{$id}}',
            ]);
            $table->addColumn('massDelete', '&nbsp;');
            $table->addColumn('actions', '&nbsp;');
            $table->editColumn('actions', function ($row) use ($template) {
                $gateKey  = 'p5_hub_membership_';
                $routeKey = 'admin.p5_hub_memberships';

                return view($template, compact('row', 'gateKey', 'routeKey'));
            });
            $table->editColumn('hub.hub_name', function ($row) {
                return $row->hub ? $row->hub->hub_name : '';
            });
            $table->editColumn('organisation.trading_name', function ($row) {
                return $row->organisation ? $row->organisation->trading_name : '';
            });
            $table->editColumn('member_type.description', function ($row) {
                return $row->member_type ? $row->member_type->description : '';
            });
            $table->editColumn('link_hub_membership_status.status', function ($row) {
                return $row->link_hub_membership_status ? $row->link_hub_membership_status->status : '';
            });
            $table->editColumn('linked_membership_class.class', function ($row) {
                return $row->linked_membership_class ? $row->linked_membership_class->class : '';
            });
            $table->editColumn('membership_number', function ($row) {
                return $row->membership_number ? $row->membership_number : '';
            });
            $table->editColumn('membership_start', function ($row) {
                return $row->membership_start ? $row->membership_start : '';
            });
            $table->editColumn('membership_end', function ($row) {
                return $row->membership_end ? $row->membership_end : '';
            });
            $table->editColumn('billing_fee', function ($row) {
                return $row->billing_fee ? $row->billing_fee : '';
            });
            $table->editColumn('billing_period', function ($row) {
                return $row->billing_period ? $row->billing_period : '';
            });
            $table->editColumn('billing_payment_method', function ($row) {
                return $row->billing_payment_method ? $row->billing_payment_method : '';
            });
            $table->editColumn('on_group_facebook', function ($row) {
                return $row->on_group_facebook ? $row->on_group_facebook : '';
            });
            $table->editColumn('on_group_mailer', function ($row) {
                return $row->on_group_mailer ? $row->on_group_mailer : '';
            });
            $table->editColumn('on_group_meetup', function ($row) {
                return $row->on_group_meetup ? $row->on_group_meetup : '';
            });
            $table->editColumn('on_signup_sheet', function ($row) {
                return $row->on_signup_sheet ? $row->on_signup_sheet : '';
            });
            $table->editColumn('notes', function ($row) {
                return $row->notes ? $row->notes : '';
            });
            $table->editColumn('dq', function ($row) {
                return $row->dq ? $row->dq : '';
            });
            $table->editColumn('created_by.name', function ($row) {
                return $row->created_by ? $row->created_by->name : '';
            });

            $table->rawColumns(['actions']);

            return $table->make(true);
        }

        return view('admin.p5_hub_memberships.index');
    }

    /**
     * Show the form for creating new P5HubMembership.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        
        $hubs = \App\P5Hub::get()->pluck('hub_name', 'id')->prepend(trans('global.app_please_select'), '');
        $organisations = \App\P5Organisation::get()->pluck('trading_name', 'id')->prepend(trans('global.app_please_select'), '');
        $member_types = \App\P5HubMembershipType::get()->pluck('description', 'id')->prepend(trans('global.app_please_select'), '');
        $link_hub_membership_statuses = \App\P5HubMembershipsStatus::get()->pluck('status', 'id')->prepend(trans('global.app_please_select'), '');
        $linked_membership_classes = \App\P5HubMembershipsClass::get()->pluck('class', 'id')->prepend(trans('global.app_please_select'), '');
        $created_bies = \App\User::get()->pluck('name', 'id')->prepend(trans('global.app_please_select'), '');

        return view('admin.p5_hub_memberships.create', compact('hubs', 'organisations', 'member_types', 'link_hub_membership_statuses', 'linked_membership_classes', 'created_bies'));
    }

    /**
     * Store a newly created P5HubMembership in storage.
     *
     * @param  \App\Http\Requests\StoreP5HubMembershipsRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreP5HubMembershipsRequest $request)
    {
        $p5_hub_membership = P5HubMembership::create($request->all());



        return redirect()->route('admin.p5_hub_memberships.index');
    }


    /**
     * Show the form for editing P5HubMembership.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        
        $hubs = \App\P5Hub::get()->pluck('hub_name', 'id')->prepend(trans('global.app_please_select'), '');
        $organisations = \App\P5Organisation::get()->pluck('trading_name', 'id')->prepend(trans('global.app_please_select'), '');
        $member_types = \App\P5HubMembershipType::get()->pluck('description', 'id')->prepend(trans('global.app_please_select'), '');
        $link_hub_membership_statuses = \App\P5HubMembershipsStatus::get()->pluck('status', 'id')->prepend(trans('global.app_please_select'), '');
        $linked_membership_classes = \App\P5HubMembershipsClass::get()->pluck('class', 'id')->prepend(trans('global.app_please_select'), '');
        $created_bies = \App\User::get()->pluck('name', 'id')->prepend(trans('global.app_please_select'), '');

        $p5_hub_membership = P5HubMembership::findOrFail($id);

        return view('admin.p5_hub_memberships.edit', compact('p5_hub_membership', 'hubs', 'organisations', 'member_types', 'link_hub_membership_statuses', 'linked_membership_classes', 'created_bies'));
    }

    /**
     * Update P5HubMembership in storage.
     *
     * @param  \App\Http\Requests\UpdateP5HubMembershipsRequest  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateP5HubMembershipsRequest $request, $id)
    {
        $p5_hub_membership = P5HubMembership::findOrFail($id);
        $p5_hub_membership->update($request->all());



        return redirect()->route('admin.p5_hub_memberships.index');
    }


    /**
     * Display P5HubMembership.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $p5_hub_membership = P5HubMembership::findOrFail($id);

        return view('admin.p5_hub_memberships.show', compact('p5_hub_membership'));
    }


    /**
     * Remove P5HubMembership from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $p5_hub_membership = P5HubMembership::findOrFail($id);
        $p5_hub_membership->delete();

        return redirect()->route('admin.p5_hub_memberships.index');
    }

    /**
     * Delete all selected P5HubMembership at once.
     *
     * @param Request $request
     */
    public function massDestroy(Request $request)
    {
        if ($request->input('ids')) {
            $entries = P5HubMembership::whereIn('id', $request->input('ids'))->get();

            foreach ($entries as $entry) {
                $entry->delete();
            }
        }
    }


    /**
     * Restore P5HubMembership from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function restore($id)
    {
        $p5_hub_membership = P5HubMembership::onlyTrashed()->findOrFail($id);
        $p5_hub_membership->restore();

        return redirect()->route('admin.p5_hub_memberships.index');
    }

    /**
     * Permanently delete P5HubMembership from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function perma_del($id)
    {
        $p5_hub_membership = P5HubMembership::onlyTrashed()->findOrFail($id);
        $p5_hub_membership->forceDelete();

        return redirect()->route('admin.p5_hub_memberships.index');
    }
}
