<?php

namespace App\Http\Controllers\Admin;

use App\P5Program;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\StoreP5ProgramsRequest;
use App\Http\Requests\Admin\UpdateP5ProgramsRequest;
use App\Http\Controllers\Traits\FileUploadTrait;
use Yajra\DataTables\DataTables;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Input;

use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
class P5ProgramsController extends Controller
{
    use FileUploadTrait;

    /**
     * Display a listing of P5Program.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if ($filterBy = Input::get('filter')) {
            if ($filterBy == 'all') {
                Session::put('P5Program.filter', 'all');
            } elseif ($filterBy == 'my') {
                Session::put('P5Program.filter', 'my');
            }
        }

        
        if (request()->ajax()) {
            $query = P5Program::query();
            $query->with("hub_link");
            $query->with("prog_tags");
            $query->with("created_by");
            $template = 'actionsTemplate';
            if(request('show_deleted') == 1) {
                
                $query->onlyTrashed();
                $template = 'restoreTemplate';
            }
            $query->select([
                'p5_programs.id',
                'p5_programs.title',
                'p5_programs.description',
                'p5_programs.established',
                'p5_programs.website',
                'p5_programs.logo',
                'p5_programs.hub_link_id',
                'p5_programs.created_by_id',
                'p5_programs.dq',
            ]);
            $table = Datatables::of($query);

            $table->setRowAttr([
                'data-entry-id' => '{{$id}}',
            ]);
            $table->addColumn('massDelete', '&nbsp;');
            $table->addColumn('actions', '&nbsp;');
            $table->editColumn('actions', function ($row) use ($template) {
                $gateKey  = 'p5_program_';
                $routeKey = 'admin.p5_programs';

                return view($template, compact('row', 'gateKey', 'routeKey'));
            });
            $table->editColumn('title', function ($row) {
                return $row->title ? $row->title : '';
            });
            $table->editColumn('description', function ($row) {
                return $row->description ? $row->description : '';
            });
            $table->editColumn('established', function ($row) {
                return $row->established ? $row->established : '';
            });
            $table->editColumn('website', function ($row) {
                return $row->website ? $row->website : '';
            });
            $table->editColumn('logo', function ($row) {
                if($row->logo) { return '<a href="'. asset(env('UPLOAD_PATH').'/' . $row->logo) .'" target="_blank"><img src="'. asset(env('UPLOAD_PATH').'/thumb/' . $row->logo) .'"/>'; };
            });
            $table->editColumn('hub_link.hub_name', function ($row) {
                return $row->hub_link ? $row->hub_link->hub_name : '';
            });
            $table->editColumn('prog_tags.tag', function ($row) {
                if(count($row->prog_tags) == 0) {
                    return '';
                }

                return '<span class="label label-info label-many">' . implode('</span><span class="label label-info label-many"> ',
                        $row->prog_tags->pluck('tag')->toArray()) . '</span>';
            });
            $table->editColumn('created_by.name', function ($row) {
                return $row->created_by ? $row->created_by->name : '';
            });
            $table->editColumn('dq', function ($row) {
                return $row->dq ? $row->dq : '';
            });

            $table->rawColumns(['actions','logo','prog_tags.tag']);

            return $table->make(true);
        }

        return view('admin.p5_programs.index');
    }

    /**
     * Show the form for creating new P5Program.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        
        $hub_links = \App\P5Hub::get()->pluck('hub_name', 'id')->prepend(trans('global.app_please_select'), '');
        $prog_tags = \App\P5Tag::get()->pluck('tag', 'id');

        $created_bies = \App\User::get()->pluck('name', 'id')->prepend(trans('global.app_please_select'), '');

        return view('admin.p5_programs.create', compact('hub_links', 'prog_tags', 'created_bies'));
    }

    /**
     * Store a newly created P5Program in storage.
     *
     * @param  \App\Http\Requests\StoreP5ProgramsRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreP5ProgramsRequest $request)
    {
        $request = $this->saveFiles($request);
        $p5_program = P5Program::create($request->all());
        $p5_program->prog_tags()->sync(array_filter((array)$request->input('prog_tags')));

        foreach ($request->input('p5_intakes', []) as $data) {
            $p5_program->p5_intakes()->create($data);
        }


        return redirect()->route('admin.p5_programs.index');
    }


    /**
     * Show the form for editing P5Program.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        
        $hub_links = \App\P5Hub::get()->pluck('hub_name', 'id')->prepend(trans('global.app_please_select'), '');
        $prog_tags = \App\P5Tag::get()->pluck('tag', 'id');

        $created_bies = \App\User::get()->pluck('name', 'id')->prepend(trans('global.app_please_select'), '');

        $p5_program = P5Program::findOrFail($id);

        return view('admin.p5_programs.edit', compact('p5_program', 'hub_links', 'prog_tags', 'created_bies'));
    }

    /**
     * Update P5Program in storage.
     *
     * @param  \App\Http\Requests\UpdateP5ProgramsRequest  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateP5ProgramsRequest $request, $id)
    {
        $request = $this->saveFiles($request);
        $p5_program = P5Program::findOrFail($id);
        $p5_program->update($request->all());
        $p5_program->prog_tags()->sync(array_filter((array)$request->input('prog_tags')));

        $p5Intakes           = $p5_program->p5_intakes;
        $currentP5IntakeData = [];
        foreach ($request->input('p5_intakes', []) as $index => $data) {
            if (is_integer($index)) {
                $p5_program->p5_intakes()->create($data);
            } else {
                $id                          = explode('-', $index)[1];
                $currentP5IntakeData[$id] = $data;
            }
        }
        foreach ($p5Intakes as $item) {
            if (isset($currentP5IntakeData[$item->id])) {
                $item->update($currentP5IntakeData[$item->id]);
            } else {
                $item->delete();
            }
        }


        return redirect()->route('admin.p5_programs.index');
    }


    /**
     * Display P5Program.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        
        $hub_links = \App\P5Hub::get()->pluck('hub_name', 'id')->prepend(trans('global.app_please_select'), '');
        $prog_tags = \App\P5Tag::get()->pluck('tag', 'id');

        $created_bies = \App\User::get()->pluck('name', 'id')->prepend(trans('global.app_please_select'), '');$p5_intakes = \App\P5Intake::where('program_id', $id)->get();

        $p5_program = P5Program::findOrFail($id);

        return view('admin.p5_programs.show', compact('p5_program', 'p5_intakes'));
    }


    /**
     * Remove P5Program from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $p5_program = P5Program::findOrFail($id);
        $p5_program->delete();

        return redirect()->route('admin.p5_programs.index');
    }

    /**
     * Delete all selected P5Program at once.
     *
     * @param Request $request
     */
    public function massDestroy(Request $request)
    {
        if ($request->input('ids')) {
            $entries = P5Program::whereIn('id', $request->input('ids'))->get();

            foreach ($entries as $entry) {
                $entry->delete();
            }
        }
    }


    /**
     * Restore P5Program from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function restore($id)
    {
        $p5_program = P5Program::onlyTrashed()->findOrFail($id);
        $p5_program->restore();

        return redirect()->route('admin.p5_programs.index');
    }

    /**
     * Permanently delete P5Program from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function perma_del($id)
    {
        $p5_program = P5Program::onlyTrashed()->findOrFail($id);
        $p5_program->forceDelete();

        return redirect()->route('admin.p5_programs.index');
    }
}
