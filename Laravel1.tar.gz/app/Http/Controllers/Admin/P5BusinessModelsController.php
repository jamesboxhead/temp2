<?php

namespace App\Http\Controllers\Admin;

use App\P5BusinessModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\StoreP5BusinessModelsRequest;
use App\Http\Requests\Admin\UpdateP5BusinessModelsRequest;
use Yajra\DataTables\DataTables;

use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
class P5BusinessModelsController extends Controller
{
    /**
     * Display a listing of P5BusinessModel.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {


        
        if (request()->ajax()) {
            $query = P5BusinessModel::query();
            $template = 'actionsTemplate';
            if(request('show_deleted') == 1) {
                
                $query->onlyTrashed();
                $template = 'restoreTemplate';
            }
            $query->select([
                'p5_business_models.id',
                'p5_business_models.business_model',
                'p5_business_models.description',
                'p5_business_models.sort_code',
            ]);
            $table = Datatables::of($query);

            $table->setRowAttr([
                'data-entry-id' => '{{$id}}',
            ]);
            $table->addColumn('massDelete', '&nbsp;');
            $table->addColumn('actions', '&nbsp;');
            $table->editColumn('actions', function ($row) use ($template) {
                $gateKey  = 'p5_business_model_';
                $routeKey = 'admin.p5_business_models';

                return view($template, compact('row', 'gateKey', 'routeKey'));
            });
            $table->editColumn('business_model', function ($row) {
                return $row->business_model ? $row->business_model : '';
            });
            $table->editColumn('description', function ($row) {
                return $row->description ? $row->description : '';
            });
            $table->editColumn('sort_code', function ($row) {
                return $row->sort_code ? $row->sort_code : '';
            });

            $table->rawColumns(['actions']);

            return $table->make(true);
        }

        return view('admin.p5_business_models.index');
    }

    /**
     * Show the form for creating new P5BusinessModel.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.p5_business_models.create');
    }

    /**
     * Store a newly created P5BusinessModel in storage.
     *
     * @param  \App\Http\Requests\StoreP5BusinessModelsRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreP5BusinessModelsRequest $request)
    {
        $p5_business_model = P5BusinessModel::create($request->all());



        return redirect()->route('admin.p5_business_models.index');
    }


    /**
     * Show the form for editing P5BusinessModel.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $p5_business_model = P5BusinessModel::findOrFail($id);

        return view('admin.p5_business_models.edit', compact('p5_business_model'));
    }

    /**
     * Update P5BusinessModel in storage.
     *
     * @param  \App\Http\Requests\UpdateP5BusinessModelsRequest  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateP5BusinessModelsRequest $request, $id)
    {
        $p5_business_model = P5BusinessModel::findOrFail($id);
        $p5_business_model->update($request->all());



        return redirect()->route('admin.p5_business_models.index');
    }


    /**
     * Display P5BusinessModel.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $p5_organisations = \App\P5Organisation::where('business_model_id', $id)->get();

        $p5_business_model = P5BusinessModel::findOrFail($id);

        return view('admin.p5_business_models.show', compact('p5_business_model', 'p5_organisations'));
    }


    /**
     * Remove P5BusinessModel from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $p5_business_model = P5BusinessModel::findOrFail($id);
        $p5_business_model->delete();

        return redirect()->route('admin.p5_business_models.index');
    }

    /**
     * Delete all selected P5BusinessModel at once.
     *
     * @param Request $request
     */
    public function massDestroy(Request $request)
    {
        if ($request->input('ids')) {
            $entries = P5BusinessModel::whereIn('id', $request->input('ids'))->get();

            foreach ($entries as $entry) {
                $entry->delete();
            }
        }
    }


    /**
     * Restore P5BusinessModel from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function restore($id)
    {
        $p5_business_model = P5BusinessModel::onlyTrashed()->findOrFail($id);
        $p5_business_model->restore();

        return redirect()->route('admin.p5_business_models.index');
    }

    /**
     * Permanently delete P5BusinessModel from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function perma_del($id)
    {
        $p5_business_model = P5BusinessModel::onlyTrashed()->findOrFail($id);
        $p5_business_model->forceDelete();

        return redirect()->route('admin.p5_business_models.index');
    }
}
