<?php

namespace App\Http\Controllers\Admin;

use App\P009FieldLevel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\StoreP009FieldLevelsRequest;
use App\Http\Requests\Admin\UpdateP009FieldLevelsRequest;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Input;

use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
class P009FieldLevelsController extends Controller
{
    /**
     * Display a listing of P009FieldLevel.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if ($filterBy = Input::get('filter')) {
            if ($filterBy == 'all') {
                Session::put('P009FieldLevel.filter', 'all');
            } elseif ($filterBy == 'my') {
                Session::put('P009FieldLevel.filter', 'my');
            }
        }

        if (request('show_deleted') == 1) {
            if (! Gate::allows('p009_field_level_delete')) {
                return abort(401);
            }
            $p009_field_levels = P009FieldLevel::onlyTrashed()->get();
        } else {
            $p009_field_levels = P009FieldLevel::all();
        }

        return view('admin.p009_field_levels.index', compact('p009_field_levels'));
    }

    /**
     * Show the form for creating new P009FieldLevel.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        
        $graphs = \App\P009Graph::get()->pluck('dataset_title', 'id')->prepend(trans('global.app_please_select'), '');

        return view('admin.p009_field_levels.create', compact('graphs'));
    }

    /**
     * Store a newly created P009FieldLevel in storage.
     *
     * @param  \App\Http\Requests\StoreP009FieldLevelsRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreP009FieldLevelsRequest $request)
    {
        $p009_field_level = P009FieldLevel::create($request->all());



        return redirect()->route('admin.p009_field_levels.index');
    }


    /**
     * Show the form for editing P009FieldLevel.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        
        $graphs = \App\P009Graph::get()->pluck('dataset_title', 'id')->prepend(trans('global.app_please_select'), '');

        $p009_field_level = P009FieldLevel::findOrFail($id);

        return view('admin.p009_field_levels.edit', compact('p009_field_level', 'graphs'));
    }

    /**
     * Update P009FieldLevel in storage.
     *
     * @param  \App\Http\Requests\UpdateP009FieldLevelsRequest  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateP009FieldLevelsRequest $request, $id)
    {
        $p009_field_level = P009FieldLevel::findOrFail($id);
        $p009_field_level->update($request->all());



        return redirect()->route('admin.p009_field_levels.index');
    }


    /**
     * Display P009FieldLevel.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $p009_field_level = P009FieldLevel::findOrFail($id);

        return view('admin.p009_field_levels.show', compact('p009_field_level'));
    }


    /**
     * Remove P009FieldLevel from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $p009_field_level = P009FieldLevel::findOrFail($id);
        $p009_field_level->delete();

        return redirect()->route('admin.p009_field_levels.index');
    }

    /**
     * Delete all selected P009FieldLevel at once.
     *
     * @param Request $request
     */
    public function massDestroy(Request $request)
    {
        if ($request->input('ids')) {
            $entries = P009FieldLevel::whereIn('id', $request->input('ids'))->get();

            foreach ($entries as $entry) {
                $entry->delete();
            }
        }
    }


    /**
     * Restore P009FieldLevel from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function restore($id)
    {
        $p009_field_level = P009FieldLevel::onlyTrashed()->findOrFail($id);
        $p009_field_level->restore();

        return redirect()->route('admin.p009_field_levels.index');
    }

    /**
     * Permanently delete P009FieldLevel from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function perma_del($id)
    {
        $p009_field_level = P009FieldLevel::onlyTrashed()->findOrFail($id);
        $p009_field_level->forceDelete();

        return redirect()->route('admin.p009_field_levels.index');
    }
}
