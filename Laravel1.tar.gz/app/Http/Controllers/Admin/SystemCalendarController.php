<?php
namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Carbon\Carbon;

class SystemCalendarController extends Controller
{
    public function index() 
    {
        $events = []; 

        foreach (\App\P5OrgPosUserLink::all() as $p5orgposuserlink) { 
           $crudFieldValue = $p5orgposuserlink->getOriginal('relationship_started'); 

           if (! $crudFieldValue) {
               continue;
           }

           $eventLabel     = $p5orgposuserlink->relationship_started; 
           $prefix         = ''; 
           $suffix         = ''; 
           $dataFieldValue = trim($prefix . " " . $eventLabel . " " . $suffix); 
           $events[]       = [ 
                'title' => $dataFieldValue, 
                'start' => $crudFieldValue, 
                'url'   => route('admin.p5orgposuserlinks.edit', $p5orgposuserlink->id)
           ]; 
        } 

        foreach (\App\P5HubMembership::all() as $p5hubmembership) { 
           $crudFieldValue = $p5hubmembership->getOriginal('membership_start'); 

           if (! $crudFieldValue) {
               continue;
           }

           $eventLabel     = $p5hubmembership->membership_start; 
           $prefix         = ''; 
           $suffix         = 'New Member today'; 
           $dataFieldValue = trim($prefix . " " . $eventLabel . " " . $suffix); 
           $events[]       = [ 
                'title' => $dataFieldValue, 
                'start' => $crudFieldValue, 
                'url'   => route('admin.p5hubmemberships.edit', $p5hubmembership->id)
           ]; 
        } 

        foreach (\App\Task::all() as $task) { 
           $crudFieldValue = $task->getOriginal('due_date'); 

           if (! $crudFieldValue) {
               continue;
           }

           $eventLabel     = $task->due_date; 
           $prefix         = 'Mentor Session:'; 
           $suffix         = ''; 
           $dataFieldValue = trim($prefix . " " . $eventLabel . " " . $suffix); 
           $events[]       = [ 
                'title' => $dataFieldValue, 
                'start' => $crudFieldValue, 
                'url'   => route('admin.tasks.edit', $task->id)
           ]; 
        } 


       return view('admin.calendar' , compact('events')); 
    }

}
