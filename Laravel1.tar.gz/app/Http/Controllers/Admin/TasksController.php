<?php

namespace App\Http\Controllers\Admin;

use App\Task;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\StoreTasksRequest;
use App\Http\Requests\Admin\UpdateTasksRequest;
use Yajra\DataTables\DataTables;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Input;

use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
class TasksController extends Controller
{
    /**
     * Display a listing of Task.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if ($filterBy = Input::get('filter')) {
            if ($filterBy == 'all') {
                Session::put('Task.filter', 'all');
            } elseif ($filterBy == 'my') {
                Session::put('Task.filter', 'my');
            }
        }

        
        if (request()->ajax()) {
            $query = Task::query();
            $query->with("user");
            $query->with("mentor");
            $query->with("status");
            $query->with("outcome");
            $query->with("tag");
            $query->with("created_by");
            $template = 'actionsTemplate';
            
            $query->select([
                'tasks.id',
                'tasks.user_id',
                'tasks.mentor_id',
                'tasks.due_date',
                'tasks.status_id',
                'tasks.outcome_id',
                'tasks.meeting_time',
                'tasks.name',
                'tasks.notes',
                'tasks.dq',
                'tasks.created_by_id',
            ]);
            $table = Datatables::of($query);

            $table->setRowAttr([
                'data-entry-id' => '{{$id}}',
            ]);
            $table->addColumn('massDelete', '&nbsp;');
            $table->addColumn('actions', '&nbsp;');
            $table->editColumn('actions', function ($row) use ($template) {
                $gateKey  = 'task_';
                $routeKey = 'admin.tasks';

                return view($template, compact('row', 'gateKey', 'routeKey'));
            });
            $table->editColumn('user.name', function ($row) {
                return $row->user ? $row->user->name : '';
            });
            $table->editColumn('mentor.name', function ($row) {
                return $row->mentor ? $row->mentor->name : '';
            });
            $table->editColumn('due_date', function ($row) {
                return $row->due_date ? $row->due_date : '';
            });
            $table->editColumn('status.name', function ($row) {
                return $row->status ? $row->status->name : '';
            });
            $table->editColumn('outcome.outcome', function ($row) {
                return $row->outcome ? $row->outcome->outcome : '';
            });
            $table->editColumn('meeting_time', function ($row) {
                return $row->meeting_time ? $row->meeting_time : '';
            });
            $table->editColumn('tag.name', function ($row) {
                if(count($row->tag) == 0) {
                    return '';
                }

                return '<span class="label label-info label-many">' . implode('</span><span class="label label-info label-many"> ',
                        $row->tag->pluck('name')->toArray()) . '</span>';
            });
            $table->editColumn('name', function ($row) {
                return $row->name ? $row->name : '';
            });
            $table->editColumn('notes', function ($row) {
                return $row->notes ? $row->notes : '';
            });
            $table->editColumn('dq', function ($row) {
                return $row->dq ? $row->dq : '';
            });
            $table->editColumn('created_by.name', function ($row) {
                return $row->created_by ? $row->created_by->name : '';
            });

            $table->rawColumns(['actions','tag.name']);

            return $table->make(true);
        }

        return view('admin.tasks.index');
    }

    /**
     * Show the form for creating new Task.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        
        $users = \App\User::get()->pluck('name', 'id')->prepend(trans('global.app_please_select'), '');
        $mentors = \App\User::get()->pluck('name', 'id')->prepend(trans('global.app_please_select'), '');
        $statuses = \App\TaskStatus::get()->pluck('name', 'id')->prepend(trans('global.app_please_select'), '');
        $outcomes = \App\TasksOutcome::get()->pluck('outcome', 'id')->prepend(trans('global.app_please_select'), '');
        $tags = \App\TaskTag::get()->pluck('name', 'id');

        $created_bies = \App\User::get()->pluck('name', 'id')->prepend(trans('global.app_please_select'), '');

        return view('admin.tasks.create', compact('users', 'mentors', 'statuses', 'outcomes', 'tags', 'created_bies'));
    }

    /**
     * Store a newly created Task in storage.
     *
     * @param  \App\Http\Requests\StoreTasksRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreTasksRequest $request)
    {
        $task = Task::create($request->all());
        $task->tag()->sync(array_filter((array)$request->input('tag')));



        return redirect()->route('admin.tasks.index');
    }


    /**
     * Show the form for editing Task.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        
        $users = \App\User::get()->pluck('name', 'id')->prepend(trans('global.app_please_select'), '');
        $mentors = \App\User::get()->pluck('name', 'id')->prepend(trans('global.app_please_select'), '');
        $statuses = \App\TaskStatus::get()->pluck('name', 'id')->prepend(trans('global.app_please_select'), '');
        $outcomes = \App\TasksOutcome::get()->pluck('outcome', 'id')->prepend(trans('global.app_please_select'), '');
        $tags = \App\TaskTag::get()->pluck('name', 'id');

        $created_bies = \App\User::get()->pluck('name', 'id')->prepend(trans('global.app_please_select'), '');

        $task = Task::findOrFail($id);

        return view('admin.tasks.edit', compact('task', 'users', 'mentors', 'statuses', 'outcomes', 'tags', 'created_bies'));
    }

    /**
     * Update Task in storage.
     *
     * @param  \App\Http\Requests\UpdateTasksRequest  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateTasksRequest $request, $id)
    {
        $task = Task::findOrFail($id);
        $task->update($request->all());
        $task->tag()->sync(array_filter((array)$request->input('tag')));



        return redirect()->route('admin.tasks.index');
    }


    /**
     * Display Task.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        
        $users = \App\User::get()->pluck('name', 'id')->prepend(trans('global.app_please_select'), '');
        $mentors = \App\User::get()->pluck('name', 'id')->prepend(trans('global.app_please_select'), '');
        $statuses = \App\TaskStatus::get()->pluck('name', 'id')->prepend(trans('global.app_please_select'), '');
        $outcomes = \App\TasksOutcome::get()->pluck('outcome', 'id')->prepend(trans('global.app_please_select'), '');
        $tags = \App\TaskTag::get()->pluck('name', 'id');

        $created_bies = \App\User::get()->pluck('name', 'id')->prepend(trans('global.app_please_select'), '');$p012_survey_logs = \App\P012SurveyLog::where('linked_task_id', $id)->get();

        $task = Task::findOrFail($id);

        return view('admin.tasks.show', compact('task', 'p012_survey_logs'));
    }


    /**
     * Remove Task from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $task = Task::findOrFail($id);
        $task->delete();

        return redirect()->route('admin.tasks.index');
    }

    /**
     * Delete all selected Task at once.
     *
     * @param Request $request
     */
    public function massDestroy(Request $request)
    {
        if ($request->input('ids')) {
            $entries = Task::whereIn('id', $request->input('ids'))->get();

            foreach ($entries as $entry) {
                $entry->delete();
            }
        }
    }

}
