<?php

namespace App\Http\Controllers\Admin;

use App\P016SessionStatus;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\StoreP016SessionStatusesRequest;
use App\Http\Requests\Admin\UpdateP016SessionStatusesRequest;
use Yajra\DataTables\DataTables;

use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
class P016SessionStatusesController extends Controller
{
    /**
     * Display a listing of P016SessionStatus.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {


        
        if (request()->ajax()) {
            $query = P016SessionStatus::query();
            $template = 'actionsTemplate';
            if(request('show_deleted') == 1) {
                
                $query->onlyTrashed();
                $template = 'restoreTemplate';
            }
            $query->select([
                'p016_session_statuses.id',
                'p016_session_statuses.session_status_code',
                'p016_session_statuses.sort_code',
            ]);
            $table = Datatables::of($query);

            $table->setRowAttr([
                'data-entry-id' => '{{$id}}',
            ]);
            $table->addColumn('massDelete', '&nbsp;');
            $table->addColumn('actions', '&nbsp;');
            $table->editColumn('actions', function ($row) use ($template) {
                $gateKey  = 'p016_session_status_';
                $routeKey = 'admin.p016_session_statuses';

                return view($template, compact('row', 'gateKey', 'routeKey'));
            });
            $table->editColumn('session_status_code', function ($row) {
                return $row->session_status_code ? $row->session_status_code : '';
            });
            $table->editColumn('sort_code', function ($row) {
                return $row->sort_code ? $row->sort_code : '';
            });

            $table->rawColumns(['actions']);

            return $table->make(true);
        }

        return view('admin.p016_session_statuses.index');
    }

    /**
     * Show the form for creating new P016SessionStatus.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.p016_session_statuses.create');
    }

    /**
     * Store a newly created P016SessionStatus in storage.
     *
     * @param  \App\Http\Requests\StoreP016SessionStatusesRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreP016SessionStatusesRequest $request)
    {
        $p016_session_status = P016SessionStatus::create($request->all());



        return redirect()->route('admin.p016_session_statuses.index');
    }


    /**
     * Show the form for editing P016SessionStatus.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $p016_session_status = P016SessionStatus::findOrFail($id);

        return view('admin.p016_session_statuses.edit', compact('p016_session_status'));
    }

    /**
     * Update P016SessionStatus in storage.
     *
     * @param  \App\Http\Requests\UpdateP016SessionStatusesRequest  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateP016SessionStatusesRequest $request, $id)
    {
        $p016_session_status = P016SessionStatus::findOrFail($id);
        $p016_session_status->update($request->all());



        return redirect()->route('admin.p016_session_statuses.index');
    }


    /**
     * Display P016SessionStatus.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $p016_sessions = \App\P016Session::where('linked_session_status_id', $id)->get();

        $p016_session_status = P016SessionStatus::findOrFail($id);

        return view('admin.p016_session_statuses.show', compact('p016_session_status', 'p016_sessions'));
    }


    /**
     * Remove P016SessionStatus from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $p016_session_status = P016SessionStatus::findOrFail($id);
        $p016_session_status->delete();

        return redirect()->route('admin.p016_session_statuses.index');
    }

    /**
     * Delete all selected P016SessionStatus at once.
     *
     * @param Request $request
     */
    public function massDestroy(Request $request)
    {
        if ($request->input('ids')) {
            $entries = P016SessionStatus::whereIn('id', $request->input('ids'))->get();

            foreach ($entries as $entry) {
                $entry->delete();
            }
        }
    }


    /**
     * Restore P016SessionStatus from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function restore($id)
    {
        $p016_session_status = P016SessionStatus::onlyTrashed()->findOrFail($id);
        $p016_session_status->restore();

        return redirect()->route('admin.p016_session_statuses.index');
    }

    /**
     * Permanently delete P016SessionStatus from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function perma_del($id)
    {
        $p016_session_status = P016SessionStatus::onlyTrashed()->findOrFail($id);
        $p016_session_status->forceDelete();

        return redirect()->route('admin.p016_session_statuses.index');
    }
}
