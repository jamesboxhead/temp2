<?php

namespace App\Http\Controllers\Admin;

use App\P016MobiMeetingParticipant;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\StoreP016MobiMeetingParticipantsRequest;
use App\Http\Requests\Admin\UpdateP016MobiMeetingParticipantsRequest;
use Yajra\DataTables\DataTables;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Input;

use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
class P016MobiMeetingParticipantsController extends Controller
{
    /**
     * Display a listing of P016MobiMeetingParticipant.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if ($filterBy = Input::get('filter')) {
            if ($filterBy == 'all') {
                Session::put('P016MobiMeetingParticipant.filter', 'all');
            } elseif ($filterBy == 'my') {
                Session::put('P016MobiMeetingParticipant.filter', 'my');
            }
        }

        
        if (request()->ajax()) {
            $query = P016MobiMeetingParticipant::query();
            $query->with("linked_session");
            $query->with("linked_user");
            $query->with("created_by");
            $template = 'actionsTemplate';
            if(request('show_deleted') == 1) {
                
                $query->onlyTrashed();
                $template = 'restoreTemplate';
            }
            $query->select([
                'p016_mobi_meeting_participants.id',
                'p016_mobi_meeting_participants.linked_session_id',
                'p016_mobi_meeting_participants.created_uid',
                'p016_mobi_meeting_participants.participant_status',
                'p016_mobi_meeting_participants.participant_email',
                'p016_mobi_meeting_participants.ip_addr',
                'p016_mobi_meeting_participants.date_recorded',
                'p016_mobi_meeting_participants.offer_preso_email_status',
                'p016_mobi_meeting_participants.offer_email_survey_detail_status',
                'p016_mobi_meeting_participants.offer_hub_info_status',
                'p016_mobi_meeting_participants.offer_pass_on_email_status',
                'p016_mobi_meeting_participants.linked_user_id',
                'p016_mobi_meeting_participants.created_by_id',
            ]);
            $table = Datatables::of($query);

            $table->setRowAttr([
                'data-entry-id' => '{{$id}}',
            ]);
            $table->addColumn('massDelete', '&nbsp;');
            $table->addColumn('actions', '&nbsp;');
            $table->editColumn('actions', function ($row) use ($template) {
                $gateKey  = 'p016_mobi_meeting_participant_';
                $routeKey = 'admin.p016_mobi_meeting_participants';

                return view($template, compact('row', 'gateKey', 'routeKey'));
            });
            $table->editColumn('linked_session.short_description', function ($row) {
                return $row->linked_session ? $row->linked_session->short_description : '';
            });
            $table->editColumn('created_uid', function ($row) {
                return $row->created_uid ? $row->created_uid : '';
            });
            $table->editColumn('participant_status', function ($row) {
                return $row->participant_status ? $row->participant_status : '';
            });
            $table->editColumn('participant_email', function ($row) {
                return $row->participant_email ? $row->participant_email : '';
            });
            $table->editColumn('ip_addr', function ($row) {
                return $row->ip_addr ? $row->ip_addr : '';
            });
            $table->editColumn('date_recorded', function ($row) {
                return $row->date_recorded ? $row->date_recorded : '';
            });
            $table->editColumn('offer_preso_email_status', function ($row) {
                return $row->offer_preso_email_status ? $row->offer_preso_email_status : '';
            });
            $table->editColumn('offer_email_survey_detail_status', function ($row) {
                return $row->offer_email_survey_detail_status ? $row->offer_email_survey_detail_status : '';
            });
            $table->editColumn('offer_hub_info_status', function ($row) {
                return $row->offer_hub_info_status ? $row->offer_hub_info_status : '';
            });
            $table->editColumn('offer_pass_on_email_status', function ($row) {
                return $row->offer_pass_on_email_status ? $row->offer_pass_on_email_status : '';
            });
            $table->editColumn('linked_user.name', function ($row) {
                return $row->linked_user ? $row->linked_user->name : '';
            });
            $table->editColumn('created_by.name', function ($row) {
                return $row->created_by ? $row->created_by->name : '';
            });

            $table->rawColumns(['actions']);

            return $table->make(true);
        }

        return view('admin.p016_mobi_meeting_participants.index');
    }

    /**
     * Show the form for creating new P016MobiMeetingParticipant.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        
        $linked_sessions = \App\P016Session::get()->pluck('short_description', 'id')->prepend(trans('global.app_please_select'), '');
        $linked_users = \App\User::get()->pluck('name', 'id')->prepend(trans('global.app_please_select'), '');
        $created_bies = \App\User::get()->pluck('name', 'id')->prepend(trans('global.app_please_select'), '');

        return view('admin.p016_mobi_meeting_participants.create', compact('linked_sessions', 'linked_users', 'created_bies'));
    }

    /**
     * Store a newly created P016MobiMeetingParticipant in storage.
     *
     * @param  \App\Http\Requests\StoreP016MobiMeetingParticipantsRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreP016MobiMeetingParticipantsRequest $request)
    {
        $p016_mobi_meeting_participant = P016MobiMeetingParticipant::create($request->all());



        return redirect()->route('admin.p016_mobi_meeting_participants.index');
    }


    /**
     * Show the form for editing P016MobiMeetingParticipant.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        
        $linked_sessions = \App\P016Session::get()->pluck('short_description', 'id')->prepend(trans('global.app_please_select'), '');
        $linked_users = \App\User::get()->pluck('name', 'id')->prepend(trans('global.app_please_select'), '');
        $created_bies = \App\User::get()->pluck('name', 'id')->prepend(trans('global.app_please_select'), '');

        $p016_mobi_meeting_participant = P016MobiMeetingParticipant::findOrFail($id);

        return view('admin.p016_mobi_meeting_participants.edit', compact('p016_mobi_meeting_participant', 'linked_sessions', 'linked_users', 'created_bies'));
    }

    /**
     * Update P016MobiMeetingParticipant in storage.
     *
     * @param  \App\Http\Requests\UpdateP016MobiMeetingParticipantsRequest  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateP016MobiMeetingParticipantsRequest $request, $id)
    {
        $p016_mobi_meeting_participant = P016MobiMeetingParticipant::findOrFail($id);
        $p016_mobi_meeting_participant->update($request->all());



        return redirect()->route('admin.p016_mobi_meeting_participants.index');
    }


    /**
     * Display P016MobiMeetingParticipant.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $p016_mobi_meeting_participant = P016MobiMeetingParticipant::findOrFail($id);

        return view('admin.p016_mobi_meeting_participants.show', compact('p016_mobi_meeting_participant'));
    }


    /**
     * Remove P016MobiMeetingParticipant from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $p016_mobi_meeting_participant = P016MobiMeetingParticipant::findOrFail($id);
        $p016_mobi_meeting_participant->delete();

        return redirect()->route('admin.p016_mobi_meeting_participants.index');
    }

    /**
     * Delete all selected P016MobiMeetingParticipant at once.
     *
     * @param Request $request
     */
    public function massDestroy(Request $request)
    {
        if ($request->input('ids')) {
            $entries = P016MobiMeetingParticipant::whereIn('id', $request->input('ids'))->get();

            foreach ($entries as $entry) {
                $entry->delete();
            }
        }
    }


    /**
     * Restore P016MobiMeetingParticipant from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function restore($id)
    {
        $p016_mobi_meeting_participant = P016MobiMeetingParticipant::onlyTrashed()->findOrFail($id);
        $p016_mobi_meeting_participant->restore();

        return redirect()->route('admin.p016_mobi_meeting_participants.index');
    }

    /**
     * Permanently delete P016MobiMeetingParticipant from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function perma_del($id)
    {
        $p016_mobi_meeting_participant = P016MobiMeetingParticipant::onlyTrashed()->findOrFail($id);
        $p016_mobi_meeting_participant->forceDelete();

        return redirect()->route('admin.p016_mobi_meeting_participants.index');
    }
}
