<?php

namespace App\Http\Controllers\Admin;

use App\P023DataSubmission;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\StoreP023DataSubmissionsRequest;
use App\Http\Requests\Admin\UpdateP023DataSubmissionsRequest;
use Yajra\DataTables\DataTables;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Input;

use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
class P023DataSubmissionsController extends Controller
{
    /**
     * Display a listing of P023DataSubmission.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if ($filterBy = Input::get('filter')) {
            if ($filterBy == 'all') {
                Session::put('P023DataSubmission.filter', 'all');
            } elseif ($filterBy == 'my') {
                Session::put('P023DataSubmission.filter', 'my');
            }
        }

        
        if (request()->ajax()) {
            $query = P023DataSubmission::query();
            $query->with("linked_p5_hubs");
            $query->with("linked_p023_data_standards");
            $query->with("created_by");
            $template = 'actionsTemplate';
            if(request('show_deleted') == 1) {
                
                $query->onlyTrashed();
                $template = 'restoreTemplate';
            }
            $query->select([
                'p023_data_submissions.id',
                'p023_data_submissions.submission_code',
                'p023_data_submissions.linked_p5_hubs_id',
                'p023_data_submissions.linked_p023_data_standards_id',
                'p023_data_submissions.data_element_as_at',
                'p023_data_submissions.data_element_x_text',
                'p023_data_submissions.data_element_x_date',
                'p023_data_submissions.data_element_x_num',
                'p023_data_submissions.data_element_x_sort_order',
                'p023_data_submissions.data_element_y_text',
                'p023_data_submissions.data_element_y_date',
                'p023_data_submissions.data_element_y_num',
                'p023_data_submissions.data_element_label',
                'p023_data_submissions.created_by_id',
            ]);
            $table = Datatables::of($query);

            $table->setRowAttr([
                'data-entry-id' => '{{$id}}',
            ]);
            $table->addColumn('massDelete', '&nbsp;');
            $table->addColumn('actions', '&nbsp;');
            $table->editColumn('actions', function ($row) use ($template) {
                $gateKey  = 'p023_data_submission_';
                $routeKey = 'admin.p023_data_submissions';

                return view($template, compact('row', 'gateKey', 'routeKey'));
            });
            $table->editColumn('submission_code', function ($row) {
                return $row->submission_code ? $row->submission_code : '';
            });
            $table->editColumn('linked_p5_hubs.hub_name', function ($row) {
                return $row->linked_p5_hubs ? $row->linked_p5_hubs->hub_name : '';
            });
            $table->editColumn('linked_p023_data_standards.data_standard_short', function ($row) {
                return $row->linked_p023_data_standards ? $row->linked_p023_data_standards->data_standard_short : '';
            });
            $table->editColumn('data_element_as_at', function ($row) {
                return $row->data_element_as_at ? $row->data_element_as_at : '';
            });
            $table->editColumn('data_element_x_text', function ($row) {
                return $row->data_element_x_text ? $row->data_element_x_text : '';
            });
            $table->editColumn('data_element_x_date', function ($row) {
                return $row->data_element_x_date ? $row->data_element_x_date : '';
            });
            $table->editColumn('data_element_x_num', function ($row) {
                return $row->data_element_x_num ? $row->data_element_x_num : '';
            });
            $table->editColumn('data_element_x_sort_order', function ($row) {
                return $row->data_element_x_sort_order ? $row->data_element_x_sort_order : '';
            });
            $table->editColumn('data_element_y_text', function ($row) {
                return $row->data_element_y_text ? $row->data_element_y_text : '';
            });
            $table->editColumn('data_element_y_date', function ($row) {
                return $row->data_element_y_date ? $row->data_element_y_date : '';
            });
            $table->editColumn('data_element_y_num', function ($row) {
                return $row->data_element_y_num ? $row->data_element_y_num : '';
            });
            $table->editColumn('data_element_label', function ($row) {
                return $row->data_element_label ? $row->data_element_label : '';
            });
            $table->editColumn('created_by.name', function ($row) {
                return $row->created_by ? $row->created_by->name : '';
            });

            $table->rawColumns(['actions']);

            return $table->make(true);
        }

        return view('admin.p023_data_submissions.index');
    }

    /**
     * Show the form for creating new P023DataSubmission.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        
        $linked_p5_hubs = \App\P5Hub::get()->pluck('hub_name', 'id')->prepend(trans('global.app_please_select'), '');
        $linked_p023_data_standards = \App\P023DataStandard::get()->pluck('data_standard_short', 'id')->prepend(trans('global.app_please_select'), '');
        $created_bies = \App\User::get()->pluck('name', 'id')->prepend(trans('global.app_please_select'), '');

        return view('admin.p023_data_submissions.create', compact('linked_p5_hubs', 'linked_p023_data_standards', 'created_bies'));
    }

    /**
     * Store a newly created P023DataSubmission in storage.
     *
     * @param  \App\Http\Requests\StoreP023DataSubmissionsRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreP023DataSubmissionsRequest $request)
    {
        $p023_data_submission = P023DataSubmission::create($request->all());



        return redirect()->route('admin.p023_data_submissions.index');
    }


    /**
     * Show the form for editing P023DataSubmission.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        
        $linked_p5_hubs = \App\P5Hub::get()->pluck('hub_name', 'id')->prepend(trans('global.app_please_select'), '');
        $linked_p023_data_standards = \App\P023DataStandard::get()->pluck('data_standard_short', 'id')->prepend(trans('global.app_please_select'), '');
        $created_bies = \App\User::get()->pluck('name', 'id')->prepend(trans('global.app_please_select'), '');

        $p023_data_submission = P023DataSubmission::findOrFail($id);

        return view('admin.p023_data_submissions.edit', compact('p023_data_submission', 'linked_p5_hubs', 'linked_p023_data_standards', 'created_bies'));
    }

    /**
     * Update P023DataSubmission in storage.
     *
     * @param  \App\Http\Requests\UpdateP023DataSubmissionsRequest  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateP023DataSubmissionsRequest $request, $id)
    {
        $p023_data_submission = P023DataSubmission::findOrFail($id);
        $p023_data_submission->update($request->all());



        return redirect()->route('admin.p023_data_submissions.index');
    }


    /**
     * Display P023DataSubmission.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $p023_data_submission = P023DataSubmission::findOrFail($id);

        return view('admin.p023_data_submissions.show', compact('p023_data_submission'));
    }


    /**
     * Remove P023DataSubmission from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $p023_data_submission = P023DataSubmission::findOrFail($id);
        $p023_data_submission->delete();

        return redirect()->route('admin.p023_data_submissions.index');
    }

    /**
     * Delete all selected P023DataSubmission at once.
     *
     * @param Request $request
     */
    public function massDestroy(Request $request)
    {
        if ($request->input('ids')) {
            $entries = P023DataSubmission::whereIn('id', $request->input('ids'))->get();

            foreach ($entries as $entry) {
                $entry->delete();
            }
        }
    }


    /**
     * Restore P023DataSubmission from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function restore($id)
    {
        $p023_data_submission = P023DataSubmission::onlyTrashed()->findOrFail($id);
        $p023_data_submission->restore();

        return redirect()->route('admin.p023_data_submissions.index');
    }

    /**
     * Permanently delete P023DataSubmission from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function perma_del($id)
    {
        $p023_data_submission = P023DataSubmission::onlyTrashed()->findOrFail($id);
        $p023_data_submission->forceDelete();

        return redirect()->route('admin.p023_data_submissions.index');
    }
}
