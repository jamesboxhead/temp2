<?php

namespace App\Http\Controllers\Admin;

use App\P009Graph;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\StoreP009GraphsRequest;
use App\Http\Requests\Admin\UpdateP009GraphsRequest;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Input;

use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
class P009GraphsController extends Controller
{
    /**
     * Display a listing of P009Graph.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if ($filterBy = Input::get('filter')) {
            if ($filterBy == 'all') {
                Session::put('P009Graph.filter', 'all');
            } elseif ($filterBy == 'my') {
                Session::put('P009Graph.filter', 'my');
            }
        }

        if (request('show_deleted') == 1) {
            if (! Gate::allows('p009_graph_delete')) {
                return abort(401);
            }
            $p009_graphs = P009Graph::onlyTrashed()->get();
        } else {
            $p009_graphs = P009Graph::all();
        }

        return view('admin.p009_graphs.index', compact('p009_graphs'));
    }

    /**
     * Show the form for creating new P009Graph.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.p009_graphs.create');
    }

    /**
     * Store a newly created P009Graph in storage.
     *
     * @param  \App\Http\Requests\StoreP009GraphsRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreP009GraphsRequest $request)
    {
        $p009_graph = P009Graph::create($request->all());



        return redirect()->route('admin.p009_graphs.index');
    }


    /**
     * Show the form for editing P009Graph.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $p009_graph = P009Graph::findOrFail($id);

        return view('admin.p009_graphs.edit', compact('p009_graph'));
    }

    /**
     * Update P009Graph in storage.
     *
     * @param  \App\Http\Requests\UpdateP009GraphsRequest  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateP009GraphsRequest $request, $id)
    {
        $p009_graph = P009Graph::findOrFail($id);
        $p009_graph->update($request->all());



        return redirect()->route('admin.p009_graphs.index');
    }


    /**
     * Display P009Graph.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $p009_field_levels = \App\P009FieldLevel::where('graph_id', $id)->get();

        $p009_graph = P009Graph::findOrFail($id);

        return view('admin.p009_graphs.show', compact('p009_graph', 'p009_field_levels'));
    }


    /**
     * Remove P009Graph from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $p009_graph = P009Graph::findOrFail($id);
        $p009_graph->delete();

        return redirect()->route('admin.p009_graphs.index');
    }

    /**
     * Delete all selected P009Graph at once.
     *
     * @param Request $request
     */
    public function massDestroy(Request $request)
    {
        if ($request->input('ids')) {
            $entries = P009Graph::whereIn('id', $request->input('ids'))->get();

            foreach ($entries as $entry) {
                $entry->delete();
            }
        }
    }


    /**
     * Restore P009Graph from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function restore($id)
    {
        $p009_graph = P009Graph::onlyTrashed()->findOrFail($id);
        $p009_graph->restore();

        return redirect()->route('admin.p009_graphs.index');
    }

    /**
     * Permanently delete P009Graph from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function perma_del($id)
    {
        $p009_graph = P009Graph::onlyTrashed()->findOrFail($id);
        $p009_graph->forceDelete();

        return redirect()->route('admin.p009_graphs.index');
    }
}
