<?php
namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use App\Http\Controllers\Controller;

class P022AnzsisReportingsController extends Controller
{
    public function index()
    {
        return view('admin.p022_anzsis_reportings.index');
    }
}
