<?php

namespace App\Http\Controllers\Admin;

use App\P016SessionVotingOption;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\StoreP016SessionVotingOptionsRequest;
use App\Http\Requests\Admin\UpdateP016SessionVotingOptionsRequest;
use Yajra\DataTables\DataTables;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Input;

use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
class P016SessionVotingOptionsController extends Controller
{
    /**
     * Display a listing of P016SessionVotingOption.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if ($filterBy = Input::get('filter')) {
            if ($filterBy == 'all') {
                Session::put('P016SessionVotingOption.filter', 'all');
            } elseif ($filterBy == 'my') {
                Session::put('P016SessionVotingOption.filter', 'my');
            }
        }

        
        if (request()->ajax()) {
            $query = P016SessionVotingOption::query();
            $query->with("linked_p016_session");
            $query->with("created_by");
            $template = 'actionsTemplate';
            if(request('show_deleted') == 1) {
                
                $query->onlyTrashed();
                $template = 'restoreTemplate';
            }
            $query->select([
                'p016_session_voting_options.id',
                'p016_session_voting_options.linked_p016_session_id',
                'p016_session_voting_options.option_code',
                'p016_session_voting_options.option_displayed',
                'p016_session_voting_options.option_more_info',
                'p016_session_voting_options.sort_order',
                'p016_session_voting_options.created_by_id',
            ]);
            $table = Datatables::of($query);

            $table->setRowAttr([
                'data-entry-id' => '{{$id}}',
            ]);
            $table->addColumn('massDelete', '&nbsp;');
            $table->addColumn('actions', '&nbsp;');
            $table->editColumn('actions', function ($row) use ($template) {
                $gateKey  = 'p016_session_voting_option_';
                $routeKey = 'admin.p016_session_voting_options';

                return view($template, compact('row', 'gateKey', 'routeKey'));
            });
            $table->editColumn('linked_p016_session.short_description', function ($row) {
                return $row->linked_p016_session ? $row->linked_p016_session->short_description : '';
            });
            $table->editColumn('option_code', function ($row) {
                return $row->option_code ? $row->option_code : '';
            });
            $table->editColumn('option_displayed', function ($row) {
                return $row->option_displayed ? $row->option_displayed : '';
            });
            $table->editColumn('option_more_info', function ($row) {
                return $row->option_more_info ? $row->option_more_info : '';
            });
            $table->editColumn('sort_order', function ($row) {
                return $row->sort_order ? $row->sort_order : '';
            });
            $table->editColumn('created_by.name', function ($row) {
                return $row->created_by ? $row->created_by->name : '';
            });

            $table->rawColumns(['actions']);

            return $table->make(true);
        }

        return view('admin.p016_session_voting_options.index');
    }

    /**
     * Show the form for creating new P016SessionVotingOption.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        
        $linked_p016_sessions = \App\P016Session::get()->pluck('short_description', 'id')->prepend(trans('global.app_please_select'), '');
        $created_bies = \App\User::get()->pluck('name', 'id')->prepend(trans('global.app_please_select'), '');

        return view('admin.p016_session_voting_options.create', compact('linked_p016_sessions', 'created_bies'));
    }

    /**
     * Store a newly created P016SessionVotingOption in storage.
     *
     * @param  \App\Http\Requests\StoreP016SessionVotingOptionsRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreP016SessionVotingOptionsRequest $request)
    {
        $p016_session_voting_option = P016SessionVotingOption::create($request->all());



        return redirect()->route('admin.p016_session_voting_options.index');
    }


    /**
     * Show the form for editing P016SessionVotingOption.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        
        $linked_p016_sessions = \App\P016Session::get()->pluck('short_description', 'id')->prepend(trans('global.app_please_select'), '');
        $created_bies = \App\User::get()->pluck('name', 'id')->prepend(trans('global.app_please_select'), '');

        $p016_session_voting_option = P016SessionVotingOption::findOrFail($id);

        return view('admin.p016_session_voting_options.edit', compact('p016_session_voting_option', 'linked_p016_sessions', 'created_bies'));
    }

    /**
     * Update P016SessionVotingOption in storage.
     *
     * @param  \App\Http\Requests\UpdateP016SessionVotingOptionsRequest  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateP016SessionVotingOptionsRequest $request, $id)
    {
        $p016_session_voting_option = P016SessionVotingOption::findOrFail($id);
        $p016_session_voting_option->update($request->all());



        return redirect()->route('admin.p016_session_voting_options.index');
    }


    /**
     * Display P016SessionVotingOption.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $p016_session_voting_option = P016SessionVotingOption::findOrFail($id);

        return view('admin.p016_session_voting_options.show', compact('p016_session_voting_option'));
    }


    /**
     * Remove P016SessionVotingOption from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $p016_session_voting_option = P016SessionVotingOption::findOrFail($id);
        $p016_session_voting_option->delete();

        return redirect()->route('admin.p016_session_voting_options.index');
    }

    /**
     * Delete all selected P016SessionVotingOption at once.
     *
     * @param Request $request
     */
    public function massDestroy(Request $request)
    {
        if ($request->input('ids')) {
            $entries = P016SessionVotingOption::whereIn('id', $request->input('ids'))->get();

            foreach ($entries as $entry) {
                $entry->delete();
            }
        }
    }


    /**
     * Restore P016SessionVotingOption from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function restore($id)
    {
        $p016_session_voting_option = P016SessionVotingOption::onlyTrashed()->findOrFail($id);
        $p016_session_voting_option->restore();

        return redirect()->route('admin.p016_session_voting_options.index');
    }

    /**
     * Permanently delete P016SessionVotingOption from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function perma_del($id)
    {
        $p016_session_voting_option = P016SessionVotingOption::onlyTrashed()->findOrFail($id);
        $p016_session_voting_option->forceDelete();

        return redirect()->route('admin.p016_session_voting_options.index');
    }
}
