<?php

namespace App\Http\Controllers\Admin;

use App\P5Hub;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\StoreP5HubsRequest;
use App\Http\Requests\Admin\UpdateP5HubsRequest;
use App\Http\Controllers\Traits\FileUploadTrait;
use Yajra\DataTables\DataTables;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Input;

use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
class P5HubsController extends Controller
{
    use FileUploadTrait;

    /**
     * Display a listing of P5Hub.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if ($filterBy = Input::get('filter')) {
            if ($filterBy == 'all') {
                Session::put('P5Hub.filter', 'all');
            } elseif ($filterBy == 'my') {
                Session::put('P5Hub.filter', 'my');
            }
        }

        
        if (request()->ajax()) {
            $query = P5Hub::query();
            $query->with("state");
            $query->with("hub_tags");
            $query->with("hub_roles");
            $query->with("hub_model");
            $query->with("created_by");
            $template = 'actionsTemplate';
            if(request('show_deleted') == 1) {
                
                $query->onlyTrashed();
                $template = 'restoreTemplate';
            }
            $query->select([
                'p5_hubs.id',
                'p5_hubs.hub_name',
                'p5_hubs.hub_description',
                'p5_hubs.website',
                'p5_hubs.email',
                'p5_hubs.state_id',
                'p5_hubs.hub_model_id',
                'p5_hubs.public_view',
                'p5_hubs.logo',
                'p5_hubs.address_line_1',
                'p5_hubs.address_line_2',
                'p5_hubs.city',
                'p5_hubs.postcode',
                'p5_hubs.map_location_address',
                'p5_hubs.wm_id',
                'p5_hubs.created_by_id',
                'p5_hubs.dq',
            ]);
            $table = Datatables::of($query);

            $table->setRowAttr([
                'data-entry-id' => '{{$id}}',
            ]);
            $table->addColumn('massDelete', '&nbsp;');
            $table->addColumn('actions', '&nbsp;');
            $table->editColumn('actions', function ($row) use ($template) {
                $gateKey  = 'p5_hub_';
                $routeKey = 'admin.p5_hubs';

                return view($template, compact('row', 'gateKey', 'routeKey'));
            });
            $table->editColumn('hub_name', function ($row) {
                return $row->hub_name ? $row->hub_name : '';
            });
            $table->editColumn('hub_description', function ($row) {
                return $row->hub_description ? $row->hub_description : '';
            });
            $table->editColumn('website', function ($row) {
                return $row->website ? $row->website : '';
            });
            $table->editColumn('email', function ($row) {
                return $row->email ? $row->email : '';
            });
            $table->editColumn('state.state', function ($row) {
                return $row->state ? $row->state->state : '';
            });
            $table->editColumn('hub_tags.tag', function ($row) {
                if(count($row->hub_tags) == 0) {
                    return '';
                }

                return '<span class="label label-info label-many">' . implode('</span><span class="label label-info label-many"> ',
                        $row->hub_tags->pluck('tag')->toArray()) . '</span>';
            });
            $table->editColumn('hub_roles.hub_role', function ($row) {
                if(count($row->hub_roles) == 0) {
                    return '';
                }

                return '<span class="label label-info label-many">' . implode('</span><span class="label label-info label-many"> ',
                        $row->hub_roles->pluck('hub_role')->toArray()) . '</span>';
            });
            $table->editColumn('hub_model.hub_model', function ($row) {
                return $row->hub_model ? $row->hub_model->hub_model : '';
            });
            $table->editColumn('public_view', function ($row) {
                return \Form::checkbox("public_view", 1, $row->public_view == 1, ["disabled"]);
            });
            $table->editColumn('logo', function ($row) {
                if($row->logo) { return '<a href="'. asset(env('UPLOAD_PATH').'/' . $row->logo) .'" target="_blank"><img src="'. asset(env('UPLOAD_PATH').'/thumb/' . $row->logo) .'"/>'; };
            });
            $table->editColumn('address_line_1', function ($row) {
                return $row->address_line_1 ? $row->address_line_1 : '';
            });
            $table->editColumn('address_line_2', function ($row) {
                return $row->address_line_2 ? $row->address_line_2 : '';
            });
            $table->editColumn('city', function ($row) {
                return $row->city ? $row->city : '';
            });
            $table->editColumn('postcode', function ($row) {
                return $row->postcode ? $row->postcode : '';
            });
            $table->editColumn('created_by.name', function ($row) {
                return $row->created_by ? $row->created_by->name : '';
            });
            $table->editColumn('dq', function ($row) {
                return $row->dq ? $row->dq : '';
            });

            $table->rawColumns(['actions','hub_tags.tag','hub_roles.hub_role','public_view','logo']);

            return $table->make(true);
        }

        return view('admin.p5_hubs.index');
    }

    /**
     * Show the form for creating new P5Hub.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        
        $states = \App\P5State::get()->pluck('state', 'id')->prepend(trans('global.app_please_select'), '');
        $hub_tags = \App\P5Tag::get()->pluck('tag', 'id');

        $hub_roles = \App\P5HubRole::get()->pluck('hub_role', 'id');

        $hub_models = \App\P5HubModel::get()->pluck('hub_model', 'id')->prepend(trans('global.app_please_select'), '');
        $created_bies = \App\User::get()->pluck('name', 'id')->prepend(trans('global.app_please_select'), '');

        return view('admin.p5_hubs.create', compact('states', 'hub_tags', 'hub_roles', 'hub_models', 'created_bies'));
    }

    /**
     * Store a newly created P5Hub in storage.
     *
     * @param  \App\Http\Requests\StoreP5HubsRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreP5HubsRequest $request)
    {
        $request = $this->saveFiles($request);
        $p5_hub = P5Hub::create($request->all());
        $p5_hub->hub_tags()->sync(array_filter((array)$request->input('hub_tags')));
        $p5_hub->hub_roles()->sync(array_filter((array)$request->input('hub_roles')));



        return redirect()->route('admin.p5_hubs.index');
    }


    /**
     * Show the form for editing P5Hub.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        
        $states = \App\P5State::get()->pluck('state', 'id')->prepend(trans('global.app_please_select'), '');
        $hub_tags = \App\P5Tag::get()->pluck('tag', 'id');

        $hub_roles = \App\P5HubRole::get()->pluck('hub_role', 'id');

        $hub_models = \App\P5HubModel::get()->pluck('hub_model', 'id')->prepend(trans('global.app_please_select'), '');
        $created_bies = \App\User::get()->pluck('name', 'id')->prepend(trans('global.app_please_select'), '');

        $p5_hub = P5Hub::findOrFail($id);

        return view('admin.p5_hubs.edit', compact('p5_hub', 'states', 'hub_tags', 'hub_roles', 'hub_models', 'created_bies'));
    }

    /**
     * Update P5Hub in storage.
     *
     * @param  \App\Http\Requests\UpdateP5HubsRequest  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateP5HubsRequest $request, $id)
    {
        $request = $this->saveFiles($request);
        $p5_hub = P5Hub::findOrFail($id);
        $p5_hub->update($request->all());
        $p5_hub->hub_tags()->sync(array_filter((array)$request->input('hub_tags')));
        $p5_hub->hub_roles()->sync(array_filter((array)$request->input('hub_roles')));



        return redirect()->route('admin.p5_hubs.index');
    }


    /**
     * Display P5Hub.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        
        $states = \App\P5State::get()->pluck('state', 'id')->prepend(trans('global.app_please_select'), '');
        $hub_tags = \App\P5Tag::get()->pluck('tag', 'id');

        $hub_roles = \App\P5HubRole::get()->pluck('hub_role', 'id');

        $hub_models = \App\P5HubModel::get()->pluck('hub_model', 'id')->prepend(trans('global.app_please_select'), '');
        $created_bies = \App\User::get()->pluck('name', 'id')->prepend(trans('global.app_please_select'), '');$p5_hub_memberships = \App\P5HubMembership::where('hub_id', $id)->get();$p016_sessions = \App\P016Session::where('linked_p5_hub_id', $id)->get();$p5_hub_memberships_individuals = \App\P5HubMembershipsIndividual::where('hub_id', $id)->get();$p023_data_submissions = \App\P023DataSubmission::where('linked_p5_hubs_id', $id)->get();$p5_programs = \App\P5Program::where('hub_link_id', $id)->get();

        $p5_hub = P5Hub::findOrFail($id);

        return view('admin.p5_hubs.show', compact('p5_hub', 'p5_hub_memberships', 'p016_sessions', 'p5_hub_memberships_individuals', 'p023_data_submissions', 'p5_programs'));
    }


    /**
     * Remove P5Hub from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $p5_hub = P5Hub::findOrFail($id);
        $p5_hub->delete();

        return redirect()->route('admin.p5_hubs.index');
    }

    /**
     * Delete all selected P5Hub at once.
     *
     * @param Request $request
     */
    public function massDestroy(Request $request)
    {
        if ($request->input('ids')) {
            $entries = P5Hub::whereIn('id', $request->input('ids'))->get();

            foreach ($entries as $entry) {
                $entry->delete();
            }
        }
    }


    /**
     * Restore P5Hub from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function restore($id)
    {
        $p5_hub = P5Hub::onlyTrashed()->findOrFail($id);
        $p5_hub->restore();

        return redirect()->route('admin.p5_hubs.index');
    }

    /**
     * Permanently delete P5Hub from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function perma_del($id)
    {
        $p5_hub = P5Hub::onlyTrashed()->findOrFail($id);
        $p5_hub->forceDelete();

        return redirect()->route('admin.p5_hubs.index');
    }
}
