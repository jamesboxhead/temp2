<?php

namespace App\Http\Controllers\Admin;

use App\P5Organisation;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\StoreP5OrganisationsRequest;
use App\Http\Requests\Admin\UpdateP5OrganisationsRequest;
use App\Http\Controllers\Traits\FileUploadTrait;
use Yajra\DataTables\DataTables;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Input;

use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
class P5OrganisationsController extends Controller
{
    use FileUploadTrait;

    /**
     * Display a listing of P5Organisation.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if ($filterBy = Input::get('filter')) {
            if ($filterBy == 'all') {
                Session::put('P5Organisation.filter', 'all');
            } elseif ($filterBy == 'my') {
                Session::put('P5Organisation.filter', 'my');
            }
        }

        
        if (request()->ajax()) {
            $query = P5Organisation::query();
            $query->with("org_status");
            $query->with("state");
            $query->with("org_tags");
            $query->with("org_cat");
            $query->with("business_model");
            $query->with("p5_anzic_level1");
            $query->with("created_by");
            $template = 'actionsTemplate';
            if(request('show_deleted') == 1) {
                
                $query->onlyTrashed();
                $template = 'restoreTemplate';
            }
            $query->select([
                'p5_organisations.id',
                'p5_organisations.trading_name',
                'p5_organisations.legal_name',
                'p5_organisations.org_status_id',
                'p5_organisations.org_location_address',
                'p5_organisations.address_line_1',
                'p5_organisations.address_line_2',
                'p5_organisations.surburb',
                'p5_organisations.post_code',
                'p5_organisations.state_id',
                'p5_organisations.established',
                'p5_organisations.primary_web_site',
                'p5_organisations.business_model_id',
                'p5_organisations.p5_anzic_level1_id',
                'p5_organisations.general_info',
                'p5_organisations.logo',
                'p5_organisations.primary_email',
                'p5_organisations.url_linkedin',
                'p5_organisations.url_facebook',
                'p5_organisations.url_twitter',
                'p5_organisations.url_instagram',
                'p5_organisations.url_angellist',
                'p5_organisations.url_crunchbase',
                'p5_organisations.map_style_url',
                'p5_organisations.created_by_id',
                'p5_organisations.dq',
            ]);
            $table = Datatables::of($query);

            $table->setRowAttr([
                'data-entry-id' => '{{$id}}',
            ]);
            $table->addColumn('massDelete', '&nbsp;');
            $table->addColumn('actions', '&nbsp;');
            $table->editColumn('actions', function ($row) use ($template) {
                $gateKey  = 'p5_organisation_';
                $routeKey = 'admin.p5_organisations';

                return view($template, compact('row', 'gateKey', 'routeKey'));
            });
            $table->editColumn('trading_name', function ($row) {
                return $row->trading_name ? $row->trading_name : '';
            });
            $table->editColumn('org_status.org_status', function ($row) {
                return $row->org_status ? $row->org_status->org_status : '';
            });
            $table->editColumn('address_line_1', function ($row) {
                return $row->address_line_1 ? $row->address_line_1 : '';
            });
            $table->editColumn('address_line_2', function ($row) {
                return $row->address_line_2 ? $row->address_line_2 : '';
            });
            $table->editColumn('surburb', function ($row) {
                return $row->surburb ? $row->surburb : '';
            });
            $table->editColumn('post_code', function ($row) {
                return $row->post_code ? $row->post_code : '';
            });
            $table->editColumn('state.state', function ($row) {
                return $row->state ? $row->state->state : '';
            });
            $table->editColumn('org_tags.tag', function ($row) {
                if(count($row->org_tags) == 0) {
                    return '';
                }

                return '<span class="label label-info label-many">' . implode('</span><span class="label label-info label-many"> ',
                        $row->org_tags->pluck('tag')->toArray()) . '</span>';
            });
            $table->editColumn('established', function ($row) {
                return $row->established ? $row->established : '';
            });
            $table->editColumn('primary_web_site', function ($row) {
                return $row->primary_web_site ? $row->primary_web_site : '';
            });
            $table->editColumn('org_cat.org_category', function ($row) {
                if(count($row->org_cat) == 0) {
                    return '';
                }

                return '<span class="label label-info label-many">' . implode('</span><span class="label label-info label-many"> ',
                        $row->org_cat->pluck('org_category')->toArray()) . '</span>';
            });
            $table->editColumn('business_model.business_model', function ($row) {
                return $row->business_model ? $row->business_model->business_model : '';
            });
            $table->editColumn('p5_anzic_level1.anzic_description', function ($row) {
                return $row->p5_anzic_level1 ? $row->p5_anzic_level1->anzic_description : '';
            });
            $table->editColumn('general_info', function ($row) {
                return $row->general_info ? $row->general_info : '';
            });
            $table->editColumn('logo', function ($row) {
                if($row->logo) { return '<a href="'. asset(env('UPLOAD_PATH').'/' . $row->logo) .'" target="_blank"><img src="'. asset(env('UPLOAD_PATH').'/thumb/' . $row->logo) .'"/>'; };
            });
            $table->editColumn('primary_email', function ($row) {
                return $row->primary_email ? $row->primary_email : '';
            });
            $table->editColumn('url_linkedin', function ($row) {
                return $row->url_linkedin ? $row->url_linkedin : '';
            });
            $table->editColumn('url_facebook', function ($row) {
                return $row->url_facebook ? $row->url_facebook : '';
            });
            $table->editColumn('url_twitter', function ($row) {
                return $row->url_twitter ? $row->url_twitter : '';
            });
            $table->editColumn('url_instagram', function ($row) {
                return $row->url_instagram ? $row->url_instagram : '';
            });
            $table->editColumn('url_angellist', function ($row) {
                return $row->url_angellist ? $row->url_angellist : '';
            });
            $table->editColumn('url_crunchbase', function ($row) {
                return $row->url_crunchbase ? $row->url_crunchbase : '';
            });
            $table->editColumn('created_by.name', function ($row) {
                return $row->created_by ? $row->created_by->name : '';
            });
            $table->editColumn('dq', function ($row) {
                return $row->dq ? $row->dq : '';
            });

            $table->rawColumns(['actions','org_tags.tag','org_cat.org_category','logo']);

            return $table->make(true);
        }

        return view('admin.p5_organisations.index');
    }

    /**
     * Show the form for creating new P5Organisation.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        
        $org_statuses = \App\P5OrgStatus::get()->pluck('org_status', 'id')->prepend(trans('global.app_please_select'), '');
        $states = \App\P5State::get()->pluck('state', 'id')->prepend(trans('global.app_please_select'), '');
        $org_tags = \App\P5Tag::get()->pluck('tag', 'id');

        $org_cats = \App\P5OrgCategory::get()->pluck('org_category', 'id');

        $business_models = \App\P5BusinessModel::get()->pluck('business_model', 'id')->prepend(trans('global.app_please_select'), '');
        $p5_anzic_level1s = \App\P5Industry::get()->pluck('anzic_description', 'id')->prepend(trans('global.app_please_select'), '');
        $created_bies = \App\User::get()->pluck('name', 'id')->prepend(trans('global.app_please_select'), '');

        return view('admin.p5_organisations.create', compact('org_statuses', 'states', 'org_tags', 'org_cats', 'business_models', 'p5_anzic_level1s', 'created_bies'));
    }

    /**
     * Store a newly created P5Organisation in storage.
     *
     * @param  \App\Http\Requests\StoreP5OrganisationsRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreP5OrganisationsRequest $request)
    {
        $request = $this->saveFiles($request);
        $p5_organisation = P5Organisation::create($request->all());
        $p5_organisation->org_tags()->sync(array_filter((array)$request->input('org_tags')));
        $p5_organisation->org_cat()->sync(array_filter((array)$request->input('org_cat')));



        return redirect()->route('admin.p5_organisations.index');
    }


    /**
     * Show the form for editing P5Organisation.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        
        $org_statuses = \App\P5OrgStatus::get()->pluck('org_status', 'id')->prepend(trans('global.app_please_select'), '');
        $states = \App\P5State::get()->pluck('state', 'id')->prepend(trans('global.app_please_select'), '');
        $org_tags = \App\P5Tag::get()->pluck('tag', 'id');

        $org_cats = \App\P5OrgCategory::get()->pluck('org_category', 'id');

        $business_models = \App\P5BusinessModel::get()->pluck('business_model', 'id')->prepend(trans('global.app_please_select'), '');
        $p5_anzic_level1s = \App\P5Industry::get()->pluck('anzic_description', 'id')->prepend(trans('global.app_please_select'), '');
        $created_bies = \App\User::get()->pluck('name', 'id')->prepend(trans('global.app_please_select'), '');

        $p5_organisation = P5Organisation::findOrFail($id);

        return view('admin.p5_organisations.edit', compact('p5_organisation', 'org_statuses', 'states', 'org_tags', 'org_cats', 'business_models', 'p5_anzic_level1s', 'created_bies'));
    }

    /**
     * Update P5Organisation in storage.
     *
     * @param  \App\Http\Requests\UpdateP5OrganisationsRequest  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateP5OrganisationsRequest $request, $id)
    {
        $request = $this->saveFiles($request);
        $p5_organisation = P5Organisation::findOrFail($id);
        $p5_organisation->update($request->all());
        $p5_organisation->org_tags()->sync(array_filter((array)$request->input('org_tags')));
        $p5_organisation->org_cat()->sync(array_filter((array)$request->input('org_cat')));



        return redirect()->route('admin.p5_organisations.index');
    }


    /**
     * Display P5Organisation.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        
        $org_statuses = \App\P5OrgStatus::get()->pluck('org_status', 'id')->prepend(trans('global.app_please_select'), '');
        $states = \App\P5State::get()->pluck('state', 'id')->prepend(trans('global.app_please_select'), '');
        $org_tags = \App\P5Tag::get()->pluck('tag', 'id');

        $org_cats = \App\P5OrgCategory::get()->pluck('org_category', 'id');

        $business_models = \App\P5BusinessModel::get()->pluck('business_model', 'id')->prepend(trans('global.app_please_select'), '');
        $p5_anzic_level1s = \App\P5Industry::get()->pluck('anzic_description', 'id')->prepend(trans('global.app_please_select'), '');
        $created_bies = \App\User::get()->pluck('name', 'id')->prepend(trans('global.app_please_select'), '');$p5_investments = \App\P5Investment::where('org_invested_in_id', $id)->get();$p022a_org_metrics_details = \App\P022aOrgMetricsDetail::where('result_p5_organisation_id', $id)->get();$p5_hub_memberships = \App\P5HubMembership::where('organisation_id', $id)->get();$p5_org_pos_user_links = \App\P5OrgPosUserLink::where('org_link_id', $id)->get();$p5_intakes = \App\P5Intake::whereHas('org_link',
                    function ($query) use ($id) {
                        $query->where('id', $id);
                    })->get();$p5_investments = \App\P5Investment::where('investor_org_id', $id)->get();

        $p5_organisation = P5Organisation::findOrFail($id);

        return view('admin.p5_organisations.show', compact('p5_organisation', 'p5_investments', 'p022a_org_metrics_details', 'p5_hub_memberships', 'p5_org_pos_user_links', 'p5_intakes', 'p5_investments'));
    }


    /**
     * Remove P5Organisation from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $p5_organisation = P5Organisation::findOrFail($id);
        $p5_organisation->delete();

        return redirect()->route('admin.p5_organisations.index');
    }

    /**
     * Delete all selected P5Organisation at once.
     *
     * @param Request $request
     */
    public function massDestroy(Request $request)
    {
        if ($request->input('ids')) {
            $entries = P5Organisation::whereIn('id', $request->input('ids'))->get();

            foreach ($entries as $entry) {
                $entry->delete();
            }
        }
    }


    /**
     * Restore P5Organisation from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function restore($id)
    {
        $p5_organisation = P5Organisation::onlyTrashed()->findOrFail($id);
        $p5_organisation->restore();

        return redirect()->route('admin.p5_organisations.index');
    }

    /**
     * Permanently delete P5Organisation from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function perma_del($id)
    {
        $p5_organisation = P5Organisation::onlyTrashed()->findOrFail($id);
        $p5_organisation->forceDelete();

        return redirect()->route('admin.p5_organisations.index');
    }
}
