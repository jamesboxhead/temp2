<?php

namespace App\Http\Controllers\Admin;

use App\P016SessionVotingResult;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\StoreP016SessionVotingResultsRequest;
use App\Http\Requests\Admin\UpdateP016SessionVotingResultsRequest;
use Yajra\DataTables\DataTables;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Input;

use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
class P016SessionVotingResultsController extends Controller
{
    /**
     * Display a listing of P016SessionVotingResult.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if ($filterBy = Input::get('filter')) {
            if ($filterBy == 'all') {
                Session::put('P016SessionVotingResult.filter', 'all');
            } elseif ($filterBy == 'my') {
                Session::put('P016SessionVotingResult.filter', 'my');
            }
        }

        
        if (request()->ajax()) {
            $query = P016SessionVotingResult::query();
            $query->with("linked_session");
            $query->with("created_by");
            $template = 'actionsTemplate';
            if(request('show_deleted') == 1) {
                
                $query->onlyTrashed();
                $template = 'restoreTemplate';
            }
            $query->select([
                'p016_session_voting_results.id',
                'p016_session_voting_results.linked_session_id',
                'p016_session_voting_results.created_uid',
                'p016_session_voting_results.option_code',
                'p016_session_voting_results.ip_addr',
                'p016_session_voting_results.date_recorded',
                'p016_session_voting_results.created_by_id',
            ]);
            $table = Datatables::of($query);

            $table->setRowAttr([
                'data-entry-id' => '{{$id}}',
            ]);
            $table->addColumn('massDelete', '&nbsp;');
            $table->addColumn('actions', '&nbsp;');
            $table->editColumn('actions', function ($row) use ($template) {
                $gateKey  = 'p016_session_voting_result_';
                $routeKey = 'admin.p016_session_voting_results';

                return view($template, compact('row', 'gateKey', 'routeKey'));
            });
            $table->editColumn('linked_session.short_description', function ($row) {
                return $row->linked_session ? $row->linked_session->short_description : '';
            });
            $table->editColumn('created_uid', function ($row) {
                return $row->created_uid ? $row->created_uid : '';
            });
            $table->editColumn('option_code', function ($row) {
                return $row->option_code ? $row->option_code : '';
            });
            $table->editColumn('ip_addr', function ($row) {
                return $row->ip_addr ? $row->ip_addr : '';
            });
            $table->editColumn('date_recorded', function ($row) {
                return $row->date_recorded ? $row->date_recorded : '';
            });
            $table->editColumn('created_by.name', function ($row) {
                return $row->created_by ? $row->created_by->name : '';
            });

            $table->rawColumns(['actions']);

            return $table->make(true);
        }

        return view('admin.p016_session_voting_results.index');
    }

    /**
     * Show the form for creating new P016SessionVotingResult.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        
        $linked_sessions = \App\P016Session::get()->pluck('short_description', 'id')->prepend(trans('global.app_please_select'), '');
        $created_bies = \App\User::get()->pluck('name', 'id')->prepend(trans('global.app_please_select'), '');

        return view('admin.p016_session_voting_results.create', compact('linked_sessions', 'created_bies'));
    }

    /**
     * Store a newly created P016SessionVotingResult in storage.
     *
     * @param  \App\Http\Requests\StoreP016SessionVotingResultsRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreP016SessionVotingResultsRequest $request)
    {
        $p016_session_voting_result = P016SessionVotingResult::create($request->all());



        return redirect()->route('admin.p016_session_voting_results.index');
    }


    /**
     * Show the form for editing P016SessionVotingResult.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        
        $linked_sessions = \App\P016Session::get()->pluck('short_description', 'id')->prepend(trans('global.app_please_select'), '');
        $created_bies = \App\User::get()->pluck('name', 'id')->prepend(trans('global.app_please_select'), '');

        $p016_session_voting_result = P016SessionVotingResult::findOrFail($id);

        return view('admin.p016_session_voting_results.edit', compact('p016_session_voting_result', 'linked_sessions', 'created_bies'));
    }

    /**
     * Update P016SessionVotingResult in storage.
     *
     * @param  \App\Http\Requests\UpdateP016SessionVotingResultsRequest  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateP016SessionVotingResultsRequest $request, $id)
    {
        $p016_session_voting_result = P016SessionVotingResult::findOrFail($id);
        $p016_session_voting_result->update($request->all());



        return redirect()->route('admin.p016_session_voting_results.index');
    }


    /**
     * Display P016SessionVotingResult.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $p016_session_voting_result = P016SessionVotingResult::findOrFail($id);

        return view('admin.p016_session_voting_results.show', compact('p016_session_voting_result'));
    }


    /**
     * Remove P016SessionVotingResult from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $p016_session_voting_result = P016SessionVotingResult::findOrFail($id);
        $p016_session_voting_result->delete();

        return redirect()->route('admin.p016_session_voting_results.index');
    }

    /**
     * Delete all selected P016SessionVotingResult at once.
     *
     * @param Request $request
     */
    public function massDestroy(Request $request)
    {
        if ($request->input('ids')) {
            $entries = P016SessionVotingResult::whereIn('id', $request->input('ids'))->get();

            foreach ($entries as $entry) {
                $entry->delete();
            }
        }
    }


    /**
     * Restore P016SessionVotingResult from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function restore($id)
    {
        $p016_session_voting_result = P016SessionVotingResult::onlyTrashed()->findOrFail($id);
        $p016_session_voting_result->restore();

        return redirect()->route('admin.p016_session_voting_results.index');
    }

    /**
     * Permanently delete P016SessionVotingResult from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function perma_del($id)
    {
        $p016_session_voting_result = P016SessionVotingResult::onlyTrashed()->findOrFail($id);
        $p016_session_voting_result->forceDelete();

        return redirect()->route('admin.p016_session_voting_results.index');
    }
}
