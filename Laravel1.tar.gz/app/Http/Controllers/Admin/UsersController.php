<?php

namespace App\Http\Controllers\Admin;

use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\StoreUsersRequest;
use App\Http\Requests\Admin\UpdateUsersRequest;
use App\Http\Controllers\Traits\FileUploadTrait;
use Yajra\DataTables\DataTables;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Input;

use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
class UsersController extends Controller
{
    use FileUploadTrait;

    /**
     * Display a listing of User.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if ($filterBy = Input::get('filter')) {
            if ($filterBy == 'all') {
                Session::put('User.filter', 'all');
            } elseif ($filterBy == 'my') {
                Session::put('User.filter', 'my');
            }
        }

        
        if (request()->ajax()) {
            $query = User::query();
            $query->with("user_tags");
            $query->with("linked_gender");
            $query->with("role");
            $query->with("linked_state");
            $query->with("created_by");
            $template = 'actionsTemplate';
            
            $query->select([
                'users.id',
                'users.name',
                'users.first_name',
                'users.last_name',
                'users.email',
                'users.primary_phone_contact',
                'users.primary_web_address',
                'users.linked_gender_id',
                'users.user_photo',
                'users.address_line_1',
                'users.address_line_2',
                'users.city',
                'users.linked_state_id',
                'users.postcode',
                'users.map_location_address',
                'users.year_of_birth',
                'users.password',
                'users.remember_token',
                'users.created_by_id',
                'users.dq',
            ]);
            $table = Datatables::of($query);

            $table->setRowAttr([
                'data-entry-id' => '{{$id}}',
            ]);
            $table->addColumn('massDelete', '&nbsp;');
            $table->addColumn('actions', '&nbsp;');
            $table->editColumn('actions', function ($row) use ($template) {
                $gateKey  = 'user_';
                $routeKey = 'admin.users';

                return view($template, compact('row', 'gateKey', 'routeKey'));
            });
            $table->editColumn('user_tags.tag', function ($row) {
                if(count($row->user_tags) == 0) {
                    return '';
                }

                return '<span class="label label-info label-many">' . implode('</span><span class="label label-info label-many"> ',
                        $row->user_tags->pluck('tag')->toArray()) . '</span>';
            });
            $table->editColumn('linked_gender.gender_description', function ($row) {
                return $row->linked_gender ? $row->linked_gender->gender_description : '';
            });
            $table->editColumn('user_photo', function ($row) {
                if($row->user_photo) { return '<a href="'. asset(env('UPLOAD_PATH').'/' . $row->user_photo) .'" target="_blank"><img src="'. asset(env('UPLOAD_PATH').'/thumb/' . $row->user_photo) .'"/>'; };
            });
            $table->editColumn('role.title', function ($row) {
                if(count($row->role) == 0) {
                    return '';
                }

                return '<span class="label label-info label-many">' . implode('</span><span class="label label-info label-many"> ',
                        $row->role->pluck('title')->toArray()) . '</span>';
            });
            $table->editColumn('address_line_1', function ($row) {
                return $row->address_line_1 ? $row->address_line_1 : '';
            });
            $table->editColumn('address_line_2', function ($row) {
                return $row->address_line_2 ? $row->address_line_2 : '';
            });
            $table->editColumn('city', function ($row) {
                return $row->city ? $row->city : '';
            });
            $table->editColumn('linked_state.state', function ($row) {
                return $row->linked_state ? $row->linked_state->state : '';
            });
            $table->editColumn('postcode', function ($row) {
                return $row->postcode ? $row->postcode : '';
            });
            $table->editColumn('map_location', function ($row) {
                return $row->map_location ? $row->map_location : '';
            });
            $table->editColumn('password', function ($row) {
                return '---';
            });
            $table->editColumn('remember_token', function ($row) {
                return $row->remember_token ? $row->remember_token : '';
            });
            $table->editColumn('created_by.name', function ($row) {
                return $row->created_by ? $row->created_by->name : '';
            });
            $table->editColumn('dq', function ($row) {
                return $row->dq ? $row->dq : '';
            });

            $table->rawColumns(['actions','user_tags.tag','user_photo','role.title']);

            return $table->make(true);
        }

        return view('admin.users.index');
    }

    /**
     * Show the form for creating new User.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        
        $user_tags = \App\P5Tag::get()->pluck('tag', 'id');

        $linked_genders = \App\P5UserGender::get()->pluck('gender_description', 'id')->prepend(trans('global.app_please_select'), '');
        $roles = \App\Role::get()->pluck('title', 'id');

        $linked_states = \App\P5State::get()->pluck('state', 'id')->prepend(trans('global.app_please_select'), '');
        $created_bies = \App\User::get()->pluck('name', 'id')->prepend(trans('global.app_please_select'), '');

        return view('admin.users.create', compact('user_tags', 'linked_genders', 'roles', 'linked_states', 'created_bies'));
    }

    /**
     * Store a newly created User in storage.
     *
     * @param  \App\Http\Requests\StoreUsersRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreUsersRequest $request)
    {
        $request = $this->saveFiles($request);
        $user = User::create($request->all());
        $user->user_tags()->sync(array_filter((array)$request->input('user_tags')));
        $user->role()->sync(array_filter((array)$request->input('role')));



        return redirect()->route('admin.users.index');
    }


    /**
     * Show the form for editing User.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        
        $user_tags = \App\P5Tag::get()->pluck('tag', 'id');

        $linked_genders = \App\P5UserGender::get()->pluck('gender_description', 'id')->prepend(trans('global.app_please_select'), '');
        $roles = \App\Role::get()->pluck('title', 'id');

        $linked_states = \App\P5State::get()->pluck('state', 'id')->prepend(trans('global.app_please_select'), '');
        $created_bies = \App\User::get()->pluck('name', 'id')->prepend(trans('global.app_please_select'), '');

        $user = User::findOrFail($id);

        return view('admin.users.edit', compact('user', 'user_tags', 'linked_genders', 'roles', 'linked_states', 'created_bies'));
    }

    /**
     * Update User in storage.
     *
     * @param  \App\Http\Requests\UpdateUsersRequest  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateUsersRequest $request, $id)
    {
        $request = $this->saveFiles($request);
        $user = User::findOrFail($id);
        $user->update($request->all());
        $user->user_tags()->sync(array_filter((array)$request->input('user_tags')));
        $user->role()->sync(array_filter((array)$request->input('role')));



        return redirect()->route('admin.users.index');
    }


    /**
     * Display User.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        
        $user_tags = \App\P5Tag::get()->pluck('tag', 'id');

        $linked_genders = \App\P5UserGender::get()->pluck('gender_description', 'id')->prepend(trans('global.app_please_select'), '');
        $roles = \App\Role::get()->pluck('title', 'id');

        $linked_states = \App\P5State::get()->pluck('state', 'id')->prepend(trans('global.app_please_select'), '');
        $created_bies = \App\User::get()->pluck('name', 'id')->prepend(trans('global.app_please_select'), '');$p012_survey_logs = \App\P012SurveyLog::where('survey_target_id', $id)->get();$user_actions = \App\UserAction::where('user_id', $id)->get();$tasks = \App\Task::where('user_id', $id)->get();$p5_org_pos_user_links = \App\P5OrgPosUserLink::where('username_id', $id)->get();$tasks = \App\Task::where('mentor_id', $id)->get();$p5_hub_memberships_individuals = \App\P5HubMembershipsIndividual::where('individual_id', $id)->get();$internal_notifications = \App\InternalNotification::whereHas('users',
                    function ($query) use ($id) {
                        $query->where('id', $id);
                    })->get();$p5_states = \App\P5State::where('created_by_id', $id)->get();$p016_session_voting_options = \App\P016SessionVotingOption::where('created_by_id', $id)->get();$p016_session_voting_results = \App\P016SessionVotingResult::where('created_by_id', $id)->get();$p5_hub_memberships_statuses = \App\P5HubMembershipsStatus::where('created_by_id', $id)->get();$p5_hub_memberships_classes = \App\P5HubMembershipsClass::where('created_by_id', $id)->get();$p5_intakes = \App\P5Intake::whereHas('users_linked',
                    function ($query) use ($id) {
                        $query->where('id', $id);
                    })->get();$p022a_org_metrics_details = \App\P022aOrgMetricsDetail::where('created_by_id', $id)->get();$p5_programs = \App\P5Program::where('created_by_id', $id)->get();$p5_investments = \App\P5Investment::where('investor_individual_id', $id)->get();$p5_intakes = \App\P5Intake::where('created_by_id', $id)->get();$p5_org_pos_user_links = \App\P5OrgPosUserLink::where('created_by_id', $id)->get();$tasks = \App\Task::where('created_by_id', $id)->get();$p016_mobi_meeting_participants = \App\P016MobiMeetingParticipant::where('linked_user_id', $id)->get();$p5_investments = \App\P5Investment::where('created_by_id', $id)->get();$p016_mobi_meeting_participants = \App\P016MobiMeetingParticipant::where('created_by_id', $id)->get();$p016_sessions = \App\P016Session::where('created_by_id', $id)->get();$p023_data_submissions = \App\P023DataSubmission::where('created_by_id', $id)->get();$p5_hubs = \App\P5Hub::where('created_by_id', $id)->get();$p5_hub_memberships_individuals = \App\P5HubMembershipsIndividual::where('created_by_id', $id)->get();$p5_hub_memberships = \App\P5HubMembership::where('created_by_id', $id)->get();$users = \App\User::where('created_by_id', $id)->get();$p5_organisations = \App\P5Organisation::where('created_by_id', $id)->get();

        $user = User::findOrFail($id);

        return view('admin.users.show', compact('user', 'p012_survey_logs', 'user_actions', 'tasks', 'p5_org_pos_user_links', 'tasks', 'p5_hub_memberships_individuals', 'internal_notifications', 'p5_states', 'p016_session_voting_options', 'p016_session_voting_results', 'p5_hub_memberships_statuses', 'p5_hub_memberships_classes', 'p5_intakes', 'p022a_org_metrics_details', 'p5_programs', 'p5_investments', 'p5_intakes', 'p5_org_pos_user_links', 'tasks', 'p016_mobi_meeting_participants', 'p5_investments', 'p016_mobi_meeting_participants', 'p016_sessions', 'p023_data_submissions', 'p5_hubs', 'p5_hub_memberships_individuals', 'p5_hub_memberships', 'users', 'p5_organisations'));
    }


    /**
     * Remove User from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $user = User::findOrFail($id);
        $user->delete();

        return redirect()->route('admin.users.index');
    }

    /**
     * Delete all selected User at once.
     *
     * @param Request $request
     */
    public function massDestroy(Request $request)
    {
        if ($request->input('ids')) {
            $entries = User::whereIn('id', $request->input('ids'))->get();

            foreach ($entries as $entry) {
                $entry->delete();
            }
        }
    }

}
