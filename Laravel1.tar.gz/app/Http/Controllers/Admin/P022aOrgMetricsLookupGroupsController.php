<?php

namespace App\Http\Controllers\Admin;

use App\P022aOrgMetricsLookupGroup;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\StoreP022aOrgMetricsLookupGroupsRequest;
use App\Http\Requests\Admin\UpdateP022aOrgMetricsLookupGroupsRequest;
use Yajra\DataTables\DataTables;

use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
class P022aOrgMetricsLookupGroupsController extends Controller
{
    /**
     * Display a listing of P022aOrgMetricsLookupGroup.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {


        
        if (request()->ajax()) {
            $query = P022aOrgMetricsLookupGroup::query();
            $template = 'actionsTemplate';
            if(request('show_deleted') == 1) {
                
                $query->onlyTrashed();
                $template = 'restoreTemplate';
            }
            $query->select([
                'p022a_org_metrics_lookup_groups.id',
                'p022a_org_metrics_lookup_groups.org_metrics_group',
                'p022a_org_metrics_lookup_groups.sort_code',
            ]);
            $table = Datatables::of($query);

            $table->setRowAttr([
                'data-entry-id' => '{{$id}}',
            ]);
            $table->addColumn('massDelete', '&nbsp;');
            $table->addColumn('actions', '&nbsp;');
            $table->editColumn('actions', function ($row) use ($template) {
                $gateKey  = 'p022a_org_metrics_lookup_group_';
                $routeKey = 'admin.p022a_org_metrics_lookup_groups';

                return view($template, compact('row', 'gateKey', 'routeKey'));
            });
            $table->editColumn('org_metrics_group', function ($row) {
                return $row->org_metrics_group ? $row->org_metrics_group : '';
            });
            $table->editColumn('sort_code', function ($row) {
                return $row->sort_code ? $row->sort_code : '';
            });

            $table->rawColumns(['actions']);

            return $table->make(true);
        }

        return view('admin.p022a_org_metrics_lookup_groups.index');
    }

    /**
     * Show the form for creating new P022aOrgMetricsLookupGroup.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.p022a_org_metrics_lookup_groups.create');
    }

    /**
     * Store a newly created P022aOrgMetricsLookupGroup in storage.
     *
     * @param  \App\Http\Requests\StoreP022aOrgMetricsLookupGroupsRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreP022aOrgMetricsLookupGroupsRequest $request)
    {
        $p022a_org_metrics_lookup_group = P022aOrgMetricsLookupGroup::create($request->all());

        foreach ($request->input('p022a_org_metrics_items', []) as $data) {
            $p022a_org_metrics_lookup_group->p022a_org_metrics_items()->create($data);
        }


        return redirect()->route('admin.p022a_org_metrics_lookup_groups.index');
    }


    /**
     * Show the form for editing P022aOrgMetricsLookupGroup.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $p022a_org_metrics_lookup_group = P022aOrgMetricsLookupGroup::findOrFail($id);

        return view('admin.p022a_org_metrics_lookup_groups.edit', compact('p022a_org_metrics_lookup_group'));
    }

    /**
     * Update P022aOrgMetricsLookupGroup in storage.
     *
     * @param  \App\Http\Requests\UpdateP022aOrgMetricsLookupGroupsRequest  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateP022aOrgMetricsLookupGroupsRequest $request, $id)
    {
        $p022a_org_metrics_lookup_group = P022aOrgMetricsLookupGroup::findOrFail($id);
        $p022a_org_metrics_lookup_group->update($request->all());

        $p022aOrgMetricsItems           = $p022a_org_metrics_lookup_group->p022a_org_metrics_items;
        $currentP022aOrgMetricsItemData = [];
        foreach ($request->input('p022a_org_metrics_items', []) as $index => $data) {
            if (is_integer($index)) {
                $p022a_org_metrics_lookup_group->p022a_org_metrics_items()->create($data);
            } else {
                $id                          = explode('-', $index)[1];
                $currentP022aOrgMetricsItemData[$id] = $data;
            }
        }
        foreach ($p022aOrgMetricsItems as $item) {
            if (isset($currentP022aOrgMetricsItemData[$item->id])) {
                $item->update($currentP022aOrgMetricsItemData[$item->id]);
            } else {
                $item->delete();
            }
        }


        return redirect()->route('admin.p022a_org_metrics_lookup_groups.index');
    }


    /**
     * Display P022aOrgMetricsLookupGroup.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $p022a_org_metrics_items = \App\P022aOrgMetricsItem::where('p022a_org_metric_group_id', $id)->get();

        $p022a_org_metrics_lookup_group = P022aOrgMetricsLookupGroup::findOrFail($id);

        return view('admin.p022a_org_metrics_lookup_groups.show', compact('p022a_org_metrics_lookup_group', 'p022a_org_metrics_items'));
    }


    /**
     * Remove P022aOrgMetricsLookupGroup from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $p022a_org_metrics_lookup_group = P022aOrgMetricsLookupGroup::findOrFail($id);
        $p022a_org_metrics_lookup_group->delete();

        return redirect()->route('admin.p022a_org_metrics_lookup_groups.index');
    }

    /**
     * Delete all selected P022aOrgMetricsLookupGroup at once.
     *
     * @param Request $request
     */
    public function massDestroy(Request $request)
    {
        if ($request->input('ids')) {
            $entries = P022aOrgMetricsLookupGroup::whereIn('id', $request->input('ids'))->get();

            foreach ($entries as $entry) {
                $entry->delete();
            }
        }
    }


    /**
     * Restore P022aOrgMetricsLookupGroup from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function restore($id)
    {
        $p022a_org_metrics_lookup_group = P022aOrgMetricsLookupGroup::onlyTrashed()->findOrFail($id);
        $p022a_org_metrics_lookup_group->restore();

        return redirect()->route('admin.p022a_org_metrics_lookup_groups.index');
    }

    /**
     * Permanently delete P022aOrgMetricsLookupGroup from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function perma_del($id)
    {
        $p022a_org_metrics_lookup_group = P022aOrgMetricsLookupGroup::onlyTrashed()->findOrFail($id);
        $p022a_org_metrics_lookup_group->forceDelete();

        return redirect()->route('admin.p022a_org_metrics_lookup_groups.index');
    }
}
