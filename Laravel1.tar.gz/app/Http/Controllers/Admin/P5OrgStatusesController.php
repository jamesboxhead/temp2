<?php

namespace App\Http\Controllers\Admin;

use App\P5OrgStatus;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\StoreP5OrgStatusesRequest;
use App\Http\Requests\Admin\UpdateP5OrgStatusesRequest;
use Yajra\DataTables\DataTables;

use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
class P5OrgStatusesController extends Controller
{
    /**
     * Display a listing of P5OrgStatus.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {


        
        if (request()->ajax()) {
            $query = P5OrgStatus::query();
            $template = 'actionsTemplate';
            if(request('show_deleted') == 1) {
                
                $query->onlyTrashed();
                $template = 'restoreTemplate';
            }
            $query->select([
                'p5_org_statuses.id',
                'p5_org_statuses.org_status',
                'p5_org_statuses.sort_code',
                'p5_org_statuses.dq',
            ]);
            $table = Datatables::of($query);

            $table->setRowAttr([
                'data-entry-id' => '{{$id}}',
            ]);
            $table->addColumn('massDelete', '&nbsp;');
            $table->addColumn('actions', '&nbsp;');
            $table->editColumn('actions', function ($row) use ($template) {
                $gateKey  = 'p5_org_status_';
                $routeKey = 'admin.p5_org_statuses';

                return view($template, compact('row', 'gateKey', 'routeKey'));
            });
            $table->editColumn('org_status', function ($row) {
                return $row->org_status ? $row->org_status : '';
            });
            $table->editColumn('sort_code', function ($row) {
                return $row->sort_code ? $row->sort_code : '';
            });
            $table->editColumn('dq', function ($row) {
                return $row->dq ? $row->dq : '';
            });

            $table->rawColumns(['actions']);

            return $table->make(true);
        }

        return view('admin.p5_org_statuses.index');
    }

    /**
     * Show the form for creating new P5OrgStatus.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.p5_org_statuses.create');
    }

    /**
     * Store a newly created P5OrgStatus in storage.
     *
     * @param  \App\Http\Requests\StoreP5OrgStatusesRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreP5OrgStatusesRequest $request)
    {
        $p5_org_status = P5OrgStatus::create($request->all());



        return redirect()->route('admin.p5_org_statuses.index');
    }


    /**
     * Show the form for editing P5OrgStatus.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $p5_org_status = P5OrgStatus::findOrFail($id);

        return view('admin.p5_org_statuses.edit', compact('p5_org_status'));
    }

    /**
     * Update P5OrgStatus in storage.
     *
     * @param  \App\Http\Requests\UpdateP5OrgStatusesRequest  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateP5OrgStatusesRequest $request, $id)
    {
        $p5_org_status = P5OrgStatus::findOrFail($id);
        $p5_org_status->update($request->all());



        return redirect()->route('admin.p5_org_statuses.index');
    }


    /**
     * Display P5OrgStatus.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $p5_organisations = \App\P5Organisation::where('org_status_id', $id)->get();

        $p5_org_status = P5OrgStatus::findOrFail($id);

        return view('admin.p5_org_statuses.show', compact('p5_org_status', 'p5_organisations'));
    }


    /**
     * Remove P5OrgStatus from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $p5_org_status = P5OrgStatus::findOrFail($id);
        $p5_org_status->delete();

        return redirect()->route('admin.p5_org_statuses.index');
    }

    /**
     * Delete all selected P5OrgStatus at once.
     *
     * @param Request $request
     */
    public function massDestroy(Request $request)
    {
        if ($request->input('ids')) {
            $entries = P5OrgStatus::whereIn('id', $request->input('ids'))->get();

            foreach ($entries as $entry) {
                $entry->delete();
            }
        }
    }


    /**
     * Restore P5OrgStatus from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function restore($id)
    {
        $p5_org_status = P5OrgStatus::onlyTrashed()->findOrFail($id);
        $p5_org_status->restore();

        return redirect()->route('admin.p5_org_statuses.index');
    }

    /**
     * Permanently delete P5OrgStatus from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function perma_del($id)
    {
        $p5_org_status = P5OrgStatus::onlyTrashed()->findOrFail($id);
        $p5_org_status->forceDelete();

        return redirect()->route('admin.p5_org_statuses.index');
    }
}
