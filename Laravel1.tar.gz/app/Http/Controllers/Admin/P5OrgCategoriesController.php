<?php

namespace App\Http\Controllers\Admin;

use App\P5OrgCategory;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\StoreP5OrgCategoriesRequest;
use App\Http\Requests\Admin\UpdateP5OrgCategoriesRequest;
use Yajra\DataTables\DataTables;

use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
class P5OrgCategoriesController extends Controller
{
    /**
     * Display a listing of P5OrgCategory.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {


        
        if (request()->ajax()) {
            $query = P5OrgCategory::query();
            $template = 'actionsTemplate';
            if(request('show_deleted') == 1) {
                
                $query->onlyTrashed();
                $template = 'restoreTemplate';
            }
            $query->select([
                'p5_org_categories.id',
                'p5_org_categories.org_category',
                'p5_org_categories.sort_code',
                'p5_org_categories.notes',
            ]);
            $table = Datatables::of($query);

            $table->setRowAttr([
                'data-entry-id' => '{{$id}}',
            ]);
            $table->addColumn('massDelete', '&nbsp;');
            $table->addColumn('actions', '&nbsp;');
            $table->editColumn('actions', function ($row) use ($template) {
                $gateKey  = 'p5_org_category_';
                $routeKey = 'admin.p5_org_categories';

                return view($template, compact('row', 'gateKey', 'routeKey'));
            });
            $table->editColumn('org_category', function ($row) {
                return $row->org_category ? $row->org_category : '';
            });
            $table->editColumn('sort_code', function ($row) {
                return $row->sort_code ? $row->sort_code : '';
            });
            $table->editColumn('notes', function ($row) {
                return $row->notes ? $row->notes : '';
            });

            $table->rawColumns(['actions']);

            return $table->make(true);
        }

        return view('admin.p5_org_categories.index');
    }

    /**
     * Show the form for creating new P5OrgCategory.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.p5_org_categories.create');
    }

    /**
     * Store a newly created P5OrgCategory in storage.
     *
     * @param  \App\Http\Requests\StoreP5OrgCategoriesRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreP5OrgCategoriesRequest $request)
    {
        $p5_org_category = P5OrgCategory::create($request->all());



        return redirect()->route('admin.p5_org_categories.index');
    }


    /**
     * Show the form for editing P5OrgCategory.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $p5_org_category = P5OrgCategory::findOrFail($id);

        return view('admin.p5_org_categories.edit', compact('p5_org_category'));
    }

    /**
     * Update P5OrgCategory in storage.
     *
     * @param  \App\Http\Requests\UpdateP5OrgCategoriesRequest  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateP5OrgCategoriesRequest $request, $id)
    {
        $p5_org_category = P5OrgCategory::findOrFail($id);
        $p5_org_category->update($request->all());



        return redirect()->route('admin.p5_org_categories.index');
    }


    /**
     * Display P5OrgCategory.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $p5_organisations = \App\P5Organisation::whereHas('org_cat',
                    function ($query) use ($id) {
                        $query->where('id', $id);
                    })->get();

        $p5_org_category = P5OrgCategory::findOrFail($id);

        return view('admin.p5_org_categories.show', compact('p5_org_category', 'p5_organisations'));
    }


    /**
     * Remove P5OrgCategory from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $p5_org_category = P5OrgCategory::findOrFail($id);
        $p5_org_category->delete();

        return redirect()->route('admin.p5_org_categories.index');
    }

    /**
     * Delete all selected P5OrgCategory at once.
     *
     * @param Request $request
     */
    public function massDestroy(Request $request)
    {
        if ($request->input('ids')) {
            $entries = P5OrgCategory::whereIn('id', $request->input('ids'))->get();

            foreach ($entries as $entry) {
                $entry->delete();
            }
        }
    }


    /**
     * Restore P5OrgCategory from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function restore($id)
    {
        $p5_org_category = P5OrgCategory::onlyTrashed()->findOrFail($id);
        $p5_org_category->restore();

        return redirect()->route('admin.p5_org_categories.index');
    }

    /**
     * Permanently delete P5OrgCategory from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function perma_del($id)
    {
        $p5_org_category = P5OrgCategory::onlyTrashed()->findOrFail($id);
        $p5_org_category->forceDelete();

        return redirect()->route('admin.p5_org_categories.index');
    }
}
