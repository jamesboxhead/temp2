<?php

namespace App\Http\Controllers\Admin;

use App\TasksOutcome;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\StoreTasksOutcomesRequest;
use App\Http\Requests\Admin\UpdateTasksOutcomesRequest;

use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
class TasksOutcomesController extends Controller
{
    /**
     * Display a listing of TasksOutcome.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {


                $tasks_outcomes = TasksOutcome::all();

        return view('admin.tasks_outcomes.index', compact('tasks_outcomes'));
    }

    /**
     * Show the form for creating new TasksOutcome.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.tasks_outcomes.create');
    }

    /**
     * Store a newly created TasksOutcome in storage.
     *
     * @param  \App\Http\Requests\StoreTasksOutcomesRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreTasksOutcomesRequest $request)
    {
        $tasks_outcome = TasksOutcome::create($request->all());



        return redirect()->route('admin.tasks_outcomes.index');
    }


    /**
     * Show the form for editing TasksOutcome.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $tasks_outcome = TasksOutcome::findOrFail($id);

        return view('admin.tasks_outcomes.edit', compact('tasks_outcome'));
    }

    /**
     * Update TasksOutcome in storage.
     *
     * @param  \App\Http\Requests\UpdateTasksOutcomesRequest  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateTasksOutcomesRequest $request, $id)
    {
        $tasks_outcome = TasksOutcome::findOrFail($id);
        $tasks_outcome->update($request->all());



        return redirect()->route('admin.tasks_outcomes.index');
    }


    /**
     * Display TasksOutcome.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $tasks = \App\Task::where('outcome_id', $id)->get();

        $tasks_outcome = TasksOutcome::findOrFail($id);

        return view('admin.tasks_outcomes.show', compact('tasks_outcome', 'tasks'));
    }


    /**
     * Remove TasksOutcome from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $tasks_outcome = TasksOutcome::findOrFail($id);
        $tasks_outcome->delete();

        return redirect()->route('admin.tasks_outcomes.index');
    }

    /**
     * Delete all selected TasksOutcome at once.
     *
     * @param Request $request
     */
    public function massDestroy(Request $request)
    {
        if ($request->input('ids')) {
            $entries = TasksOutcome::whereIn('id', $request->input('ids'))->get();

            foreach ($entries as $entry) {
                $entry->delete();
            }
        }
    }

}
