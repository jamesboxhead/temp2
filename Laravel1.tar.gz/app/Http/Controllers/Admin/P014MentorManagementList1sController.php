<?php
namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use App\Http\Controllers\Controller;

class P014MentorManagementList1sController extends Controller
{
    public function index()
    {
        return view('admin.p014_mentor_management_list1s.index');
    }
}
