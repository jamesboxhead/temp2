<?php

namespace App\Http\Controllers\Admin;

use App\P5State;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\StoreP5StatesRequest;
use App\Http\Requests\Admin\UpdateP5StatesRequest;
use Yajra\DataTables\DataTables;

use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
class P5StatesController extends Controller
{
    /**
     * Display a listing of P5State.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {


        
        if (request()->ajax()) {
            $query = P5State::query();
            $query->with("created_by");
            $template = 'actionsTemplate';
            if(request('show_deleted') == 1) {
                
                $query->onlyTrashed();
                $template = 'restoreTemplate';
            }
            $query->select([
                'p5_states.id',
                'p5_states.state',
                'p5_states.state_long',
                'p5_states.created_by_id',
            ]);
            $table = Datatables::of($query);

            $table->setRowAttr([
                'data-entry-id' => '{{$id}}',
            ]);
            $table->addColumn('massDelete', '&nbsp;');
            $table->addColumn('actions', '&nbsp;');
            $table->editColumn('actions', function ($row) use ($template) {
                $gateKey  = 'p5_state_';
                $routeKey = 'admin.p5_states';

                return view($template, compact('row', 'gateKey', 'routeKey'));
            });
            $table->editColumn('state', function ($row) {
                return $row->state ? $row->state : '';
            });
            $table->editColumn('state_long', function ($row) {
                return $row->state_long ? $row->state_long : '';
            });
            $table->editColumn('created_by.name', function ($row) {
                return $row->created_by ? $row->created_by->name : '';
            });

            $table->rawColumns(['actions']);

            return $table->make(true);
        }

        return view('admin.p5_states.index');
    }

    /**
     * Show the form for creating new P5State.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        
        $created_bies = \App\User::get()->pluck('name', 'id')->prepend(trans('global.app_please_select'), '');

        return view('admin.p5_states.create', compact('created_bies'));
    }

    /**
     * Store a newly created P5State in storage.
     *
     * @param  \App\Http\Requests\StoreP5StatesRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreP5StatesRequest $request)
    {
        $p5_state = P5State::create($request->all());



        return redirect()->route('admin.p5_states.index');
    }


    /**
     * Show the form for editing P5State.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        
        $created_bies = \App\User::get()->pluck('name', 'id')->prepend(trans('global.app_please_select'), '');

        $p5_state = P5State::findOrFail($id);

        return view('admin.p5_states.edit', compact('p5_state', 'created_bies'));
    }

    /**
     * Update P5State in storage.
     *
     * @param  \App\Http\Requests\UpdateP5StatesRequest  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateP5StatesRequest $request, $id)
    {
        $p5_state = P5State::findOrFail($id);
        $p5_state->update($request->all());



        return redirect()->route('admin.p5_states.index');
    }


    /**
     * Display P5State.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        
        $created_bies = \App\User::get()->pluck('name', 'id')->prepend(trans('global.app_please_select'), '');$p5_hubs = \App\P5Hub::where('state_id', $id)->get();$p5_organisations = \App\P5Organisation::where('state_id', $id)->get();$users = \App\User::where('linked_state_id', $id)->get();

        $p5_state = P5State::findOrFail($id);

        return view('admin.p5_states.show', compact('p5_state', 'p5_hubs', 'p5_organisations', 'users'));
    }


    /**
     * Remove P5State from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $p5_state = P5State::findOrFail($id);
        $p5_state->delete();

        return redirect()->route('admin.p5_states.index');
    }

    /**
     * Delete all selected P5State at once.
     *
     * @param Request $request
     */
    public function massDestroy(Request $request)
    {
        if ($request->input('ids')) {
            $entries = P5State::whereIn('id', $request->input('ids'))->get();

            foreach ($entries as $entry) {
                $entry->delete();
            }
        }
    }


    /**
     * Restore P5State from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function restore($id)
    {
        $p5_state = P5State::onlyTrashed()->findOrFail($id);
        $p5_state->restore();

        return redirect()->route('admin.p5_states.index');
    }

    /**
     * Permanently delete P5State from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function perma_del($id)
    {
        $p5_state = P5State::onlyTrashed()->findOrFail($id);
        $p5_state->forceDelete();

        return redirect()->route('admin.p5_states.index');
    }
}
