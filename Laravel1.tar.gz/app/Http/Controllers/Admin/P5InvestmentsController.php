<?php

namespace App\Http\Controllers\Admin;

use App\P5Investment;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\StoreP5InvestmentsRequest;
use App\Http\Requests\Admin\UpdateP5InvestmentsRequest;
use Yajra\DataTables\DataTables;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Input;

use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
class P5InvestmentsController extends Controller
{
    /**
     * Display a listing of P5Investment.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if ($filterBy = Input::get('filter')) {
            if ($filterBy == 'all') {
                Session::put('P5Investment.filter', 'all');
            } elseif ($filterBy == 'my') {
                Session::put('P5Investment.filter', 'my');
            }
        }

        
        if (request()->ajax()) {
            $query = P5Investment::query();
            $query->with("org_invested_in");
            $query->with("p5_actual_investment_souce");
            $query->with("investor_org");
            $query->with("investor_individual");
            $query->with("created_by");
            $template = 'actionsTemplate';
            if(request('show_deleted') == 1) {
                
                $query->onlyTrashed();
                $template = 'restoreTemplate';
            }
            $query->select([
                'p5_investments.id',
                'p5_investments.org_invested_in_id',
                'p5_investments.date_of_investment',
                'p5_investments.amnt_of_investment',
                'p5_investments.investment_currency',
                'p5_investments.p5_actual_investment_souce_id',
                'p5_investments.inverstor_entity_type',
                'p5_investments.investor_org_id',
                'p5_investments.investor_individual_id',
                'p5_investments.notes',
                'p5_investments.dq',
                'p5_investments.created_by_id',
            ]);
            $table = Datatables::of($query);

            $table->setRowAttr([
                'data-entry-id' => '{{$id}}',
            ]);
            $table->addColumn('massDelete', '&nbsp;');
            $table->addColumn('actions', '&nbsp;');
            $table->editColumn('actions', function ($row) use ($template) {
                $gateKey  = 'p5_investment_';
                $routeKey = 'admin.p5_investments';

                return view($template, compact('row', 'gateKey', 'routeKey'));
            });
            $table->editColumn('org_invested_in.trading_name', function ($row) {
                return $row->org_invested_in ? $row->org_invested_in->trading_name : '';
            });
            $table->editColumn('date_of_investment', function ($row) {
                return $row->date_of_investment ? $row->date_of_investment : '';
            });
            $table->editColumn('amnt_of_investment', function ($row) {
                return $row->amnt_of_investment ? $row->amnt_of_investment : '';
            });
            $table->editColumn('investment_currency', function ($row) {
                return $row->investment_currency ? $row->investment_currency : '';
            });
            $table->editColumn('p5_actual_investment_souce.investment_source_description', function ($row) {
                return $row->p5_actual_investment_souce ? $row->p5_actual_investment_souce->investment_source_description : '';
            });
            $table->editColumn('inverstor_entity_type', function ($row) {
                return $row->inverstor_entity_type ? $row->inverstor_entity_type : '';
            });
            $table->editColumn('investor_org.trading_name', function ($row) {
                return $row->investor_org ? $row->investor_org->trading_name : '';
            });
            $table->editColumn('investor_individual.name', function ($row) {
                return $row->investor_individual ? $row->investor_individual->name : '';
            });
            $table->editColumn('notes', function ($row) {
                return $row->notes ? $row->notes : '';
            });
            $table->editColumn('dq', function ($row) {
                return $row->dq ? $row->dq : '';
            });
            $table->editColumn('created_by.name', function ($row) {
                return $row->created_by ? $row->created_by->name : '';
            });

            $table->rawColumns(['actions']);

            return $table->make(true);
        }

        return view('admin.p5_investments.index');
    }

    /**
     * Show the form for creating new P5Investment.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        
        $org_invested_ins = \App\P5Organisation::get()->pluck('trading_name', 'id')->prepend(trans('global.app_please_select'), '');
        $p5_actual_investment_souces = \App\P5InvestmentSource::get()->pluck('investment_source_description', 'id')->prepend(trans('global.app_please_select'), '');
        $investor_orgs = \App\P5Organisation::get()->pluck('trading_name', 'id')->prepend(trans('global.app_please_select'), '');
        $investor_individuals = \App\User::get()->pluck('name', 'id')->prepend(trans('global.app_please_select'), '');
        $created_bies = \App\User::get()->pluck('name', 'id')->prepend(trans('global.app_please_select'), '');
        $enum_inverstor_entity_type = P5Investment::$enum_inverstor_entity_type;
            
        return view('admin.p5_investments.create', compact('enum_inverstor_entity_type', 'org_invested_ins', 'p5_actual_investment_souces', 'investor_orgs', 'investor_individuals', 'created_bies'));
    }

    /**
     * Store a newly created P5Investment in storage.
     *
     * @param  \App\Http\Requests\StoreP5InvestmentsRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreP5InvestmentsRequest $request)
    {
        $p5_investment = P5Investment::create($request->all());



        return redirect()->route('admin.p5_investments.index');
    }


    /**
     * Show the form for editing P5Investment.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        
        $org_invested_ins = \App\P5Organisation::get()->pluck('trading_name', 'id')->prepend(trans('global.app_please_select'), '');
        $p5_actual_investment_souces = \App\P5InvestmentSource::get()->pluck('investment_source_description', 'id')->prepend(trans('global.app_please_select'), '');
        $investor_orgs = \App\P5Organisation::get()->pluck('trading_name', 'id')->prepend(trans('global.app_please_select'), '');
        $investor_individuals = \App\User::get()->pluck('name', 'id')->prepend(trans('global.app_please_select'), '');
        $created_bies = \App\User::get()->pluck('name', 'id')->prepend(trans('global.app_please_select'), '');
        $enum_inverstor_entity_type = P5Investment::$enum_inverstor_entity_type;
            
        $p5_investment = P5Investment::findOrFail($id);

        return view('admin.p5_investments.edit', compact('p5_investment', 'enum_inverstor_entity_type', 'org_invested_ins', 'p5_actual_investment_souces', 'investor_orgs', 'investor_individuals', 'created_bies'));
    }

    /**
     * Update P5Investment in storage.
     *
     * @param  \App\Http\Requests\UpdateP5InvestmentsRequest  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateP5InvestmentsRequest $request, $id)
    {
        $p5_investment = P5Investment::findOrFail($id);
        $p5_investment->update($request->all());



        return redirect()->route('admin.p5_investments.index');
    }


    /**
     * Display P5Investment.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $p5_investment = P5Investment::findOrFail($id);

        return view('admin.p5_investments.show', compact('p5_investment'));
    }


    /**
     * Remove P5Investment from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $p5_investment = P5Investment::findOrFail($id);
        $p5_investment->delete();

        return redirect()->route('admin.p5_investments.index');
    }

    /**
     * Delete all selected P5Investment at once.
     *
     * @param Request $request
     */
    public function massDestroy(Request $request)
    {
        if ($request->input('ids')) {
            $entries = P5Investment::whereIn('id', $request->input('ids'))->get();

            foreach ($entries as $entry) {
                $entry->delete();
            }
        }
    }


    /**
     * Restore P5Investment from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function restore($id)
    {
        $p5_investment = P5Investment::onlyTrashed()->findOrFail($id);
        $p5_investment->restore();

        return redirect()->route('admin.p5_investments.index');
    }

    /**
     * Permanently delete P5Investment from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function perma_del($id)
    {
        $p5_investment = P5Investment::onlyTrashed()->findOrFail($id);
        $p5_investment->forceDelete();

        return redirect()->route('admin.p5_investments.index');
    }
}
