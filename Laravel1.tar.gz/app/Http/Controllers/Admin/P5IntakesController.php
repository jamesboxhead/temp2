<?php

namespace App\Http\Controllers\Admin;

use App\P5Intake;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\StoreP5IntakesRequest;
use App\Http\Requests\Admin\UpdateP5IntakesRequest;
use Yajra\DataTables\DataTables;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Input;

use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
class P5IntakesController extends Controller
{
    /**
     * Display a listing of P5Intake.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if ($filterBy = Input::get('filter')) {
            if ($filterBy == 'all') {
                Session::put('P5Intake.filter', 'all');
            } elseif ($filterBy == 'my') {
                Session::put('P5Intake.filter', 'my');
            }
        }

        
        if (request()->ajax()) {
            $query = P5Intake::query();
            $query->with("program");
            $query->with("org_link");
            $query->with("users_linked");
            $query->with("created_by");
            $template = 'actionsTemplate';
            if(request('show_deleted') == 1) {
                
                $query->onlyTrashed();
                $template = 'restoreTemplate';
            }
            $query->select([
                'p5_intakes.id',
                'p5_intakes.program_id',
                'p5_intakes.intake_group',
                'p5_intakes.start_date',
                'p5_intakes.end_date1',
                'p5_intakes.description',
                'p5_intakes.website',
                'p5_intakes.created_by_id',
                'p5_intakes.dq',
            ]);
            $table = Datatables::of($query);

            $table->setRowAttr([
                'data-entry-id' => '{{$id}}',
            ]);
            $table->addColumn('massDelete', '&nbsp;');
            $table->addColumn('actions', '&nbsp;');
            $table->editColumn('actions', function ($row) use ($template) {
                $gateKey  = 'p5_intake_';
                $routeKey = 'admin.p5_intakes';

                return view($template, compact('row', 'gateKey', 'routeKey'));
            });
            $table->editColumn('program.title', function ($row) {
                return $row->program ? $row->program->title : '';
            });
            $table->editColumn('intake_group', function ($row) {
                return $row->intake_group ? $row->intake_group : '';
            });
            $table->editColumn('start_date', function ($row) {
                return $row->start_date ? $row->start_date : '';
            });
            $table->editColumn('end_date1', function ($row) {
                return $row->end_date1 ? $row->end_date1 : '';
            });
            $table->editColumn('description', function ($row) {
                return $row->description ? $row->description : '';
            });
            $table->editColumn('website', function ($row) {
                return $row->website ? $row->website : '';
            });
            $table->editColumn('org_link.trading_name', function ($row) {
                if(count($row->org_link) == 0) {
                    return '';
                }

                return '<span class="label label-info label-many">' . implode('</span><span class="label label-info label-many"> ',
                        $row->org_link->pluck('trading_name')->toArray()) . '</span>';
            });
            $table->editColumn('users_linked.name', function ($row) {
                if(count($row->users_linked) == 0) {
                    return '';
                }

                return '<span class="label label-info label-many">' . implode('</span><span class="label label-info label-many"> ',
                        $row->users_linked->pluck('name')->toArray()) . '</span>';
            });
            $table->editColumn('created_by.name', function ($row) {
                return $row->created_by ? $row->created_by->name : '';
            });
            $table->editColumn('dq', function ($row) {
                return $row->dq ? $row->dq : '';
            });

            $table->rawColumns(['actions','org_link.trading_name','users_linked.name']);

            return $table->make(true);
        }

        return view('admin.p5_intakes.index');
    }

    /**
     * Show the form for creating new P5Intake.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        
        $programs = \App\P5Program::get()->pluck('title', 'id')->prepend(trans('global.app_please_select'), '');
        $org_links = \App\P5Organisation::get()->pluck('trading_name', 'id');

        $users_linkeds = \App\User::get()->pluck('name', 'id');

        $created_bies = \App\User::get()->pluck('name', 'id')->prepend(trans('global.app_please_select'), '');

        return view('admin.p5_intakes.create', compact('programs', 'org_links', 'users_linkeds', 'created_bies'));
    }

    /**
     * Store a newly created P5Intake in storage.
     *
     * @param  \App\Http\Requests\StoreP5IntakesRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreP5IntakesRequest $request)
    {
        $p5_intake = P5Intake::create($request->all());
        $p5_intake->org_link()->sync(array_filter((array)$request->input('org_link')));
        $p5_intake->users_linked()->sync(array_filter((array)$request->input('users_linked')));



        return redirect()->route('admin.p5_intakes.index');
    }


    /**
     * Show the form for editing P5Intake.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        
        $programs = \App\P5Program::get()->pluck('title', 'id')->prepend(trans('global.app_please_select'), '');
        $org_links = \App\P5Organisation::get()->pluck('trading_name', 'id');

        $users_linkeds = \App\User::get()->pluck('name', 'id');

        $created_bies = \App\User::get()->pluck('name', 'id')->prepend(trans('global.app_please_select'), '');

        $p5_intake = P5Intake::findOrFail($id);

        return view('admin.p5_intakes.edit', compact('p5_intake', 'programs', 'org_links', 'users_linkeds', 'created_bies'));
    }

    /**
     * Update P5Intake in storage.
     *
     * @param  \App\Http\Requests\UpdateP5IntakesRequest  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateP5IntakesRequest $request, $id)
    {
        $p5_intake = P5Intake::findOrFail($id);
        $p5_intake->update($request->all());
        $p5_intake->org_link()->sync(array_filter((array)$request->input('org_link')));
        $p5_intake->users_linked()->sync(array_filter((array)$request->input('users_linked')));



        return redirect()->route('admin.p5_intakes.index');
    }


    /**
     * Display P5Intake.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $p5_intake = P5Intake::findOrFail($id);

        return view('admin.p5_intakes.show', compact('p5_intake'));
    }


    /**
     * Remove P5Intake from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $p5_intake = P5Intake::findOrFail($id);
        $p5_intake->delete();

        return redirect()->route('admin.p5_intakes.index');
    }

    /**
     * Delete all selected P5Intake at once.
     *
     * @param Request $request
     */
    public function massDestroy(Request $request)
    {
        if ($request->input('ids')) {
            $entries = P5Intake::whereIn('id', $request->input('ids'))->get();

            foreach ($entries as $entry) {
                $entry->delete();
            }
        }
    }


    /**
     * Restore P5Intake from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function restore($id)
    {
        $p5_intake = P5Intake::onlyTrashed()->findOrFail($id);
        $p5_intake->restore();

        return redirect()->route('admin.p5_intakes.index');
    }

    /**
     * Permanently delete P5Intake from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function perma_del($id)
    {
        $p5_intake = P5Intake::onlyTrashed()->findOrFail($id);
        $p5_intake->forceDelete();

        return redirect()->route('admin.p5_intakes.index');
    }
}
