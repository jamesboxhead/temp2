<?php

namespace App\Http\Controllers\Admin;

use App\P022aOrgMetricsDetail;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\StoreP022aOrgMetricsDetailsRequest;
use App\Http\Requests\Admin\UpdateP022aOrgMetricsDetailsRequest;
use Yajra\DataTables\DataTables;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Input;

use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
class P022aOrgMetricsDetailsController extends Controller
{
    /**
     * Display a listing of P022aOrgMetricsDetail.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if ($filterBy = Input::get('filter')) {
            if ($filterBy == 'all') {
                Session::put('P022aOrgMetricsDetail.filter', 'all');
            } elseif ($filterBy == 'my') {
                Session::put('P022aOrgMetricsDetail.filter', 'my');
            }
        }

        
        if (request()->ajax()) {
            $query = P022aOrgMetricsDetail::query();
            $query->with("result_p5_organisation");
            $query->with("result_p022_org_metrics_lookup");
            $query->with("created_by");
            $template = 'actionsTemplate';
            if(request('show_deleted') == 1) {
                
                $query->onlyTrashed();
                $template = 'restoreTemplate';
            }
            $query->select([
                'p022a_org_metrics_details.id',
                'p022a_org_metrics_details.result_as_at',
                'p022a_org_metrics_details.result_p5_organisation_id',
                'p022a_org_metrics_details.p022_result_raw',
                'p022a_org_metrics_details.result_p022_org_metrics_lookup_id',
                'p022a_org_metrics_details.result_source',
                'p022a_org_metrics_details.p022_result_value',
                'p022a_org_metrics_details.p022_validation_status',
                'p022a_org_metrics_details.created_by_id',
            ]);
            $table = Datatables::of($query);

            $table->setRowAttr([
                'data-entry-id' => '{{$id}}',
            ]);
            $table->addColumn('massDelete', '&nbsp;');
            $table->addColumn('actions', '&nbsp;');
            $table->editColumn('actions', function ($row) use ($template) {
                $gateKey  = 'p022a_org_metrics_detail_';
                $routeKey = 'admin.p022a_org_metrics_details';

                return view($template, compact('row', 'gateKey', 'routeKey'));
            });
            $table->editColumn('result_as_at', function ($row) {
                return $row->result_as_at ? $row->result_as_at : '';
            });
            $table->editColumn('result_p5_organisation.trading_name', function ($row) {
                return $row->result_p5_organisation ? $row->result_p5_organisation->trading_name : '';
            });
            $table->editColumn('p022_result_raw', function ($row) {
                return $row->p022_result_raw ? $row->p022_result_raw : '';
            });
            $table->editColumn('result_p022_org_metrics_lookup.metric_description', function ($row) {
                return $row->result_p022_org_metrics_lookup ? $row->result_p022_org_metrics_lookup->metric_description : '';
            });
            $table->editColumn('result_source', function ($row) {
                return $row->result_source ? $row->result_source : '';
            });
            $table->editColumn('p022_result_value', function ($row) {
                return $row->p022_result_value ? $row->p022_result_value : '';
            });
            $table->editColumn('p022_validation_status', function ($row) {
                return $row->p022_validation_status ? $row->p022_validation_status : '';
            });
            $table->editColumn('created_by.name', function ($row) {
                return $row->created_by ? $row->created_by->name : '';
            });

            $table->rawColumns(['actions']);

            return $table->make(true);
        }

        return view('admin.p022a_org_metrics_details.index');
    }

    /**
     * Show the form for creating new P022aOrgMetricsDetail.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        
        $result_p5_organisations = \App\P5Organisation::get()->pluck('trading_name', 'id')->prepend(trans('global.app_please_select'), '');
        $result_p022_org_metrics_lookups = \App\P022aOrgMetricsItem::get()->pluck('metric_description', 'id')->prepend(trans('global.app_please_select'), '');
        $created_bies = \App\User::get()->pluck('name', 'id')->prepend(trans('global.app_please_select'), '');

        return view('admin.p022a_org_metrics_details.create', compact('result_p5_organisations', 'result_p022_org_metrics_lookups', 'created_bies'));
    }

    /**
     * Store a newly created P022aOrgMetricsDetail in storage.
     *
     * @param  \App\Http\Requests\StoreP022aOrgMetricsDetailsRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreP022aOrgMetricsDetailsRequest $request)
    {
        $p022a_org_metrics_detail = P022aOrgMetricsDetail::create($request->all());



        return redirect()->route('admin.p022a_org_metrics_details.index');
    }


    /**
     * Show the form for editing P022aOrgMetricsDetail.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        
        $result_p5_organisations = \App\P5Organisation::get()->pluck('trading_name', 'id')->prepend(trans('global.app_please_select'), '');
        $result_p022_org_metrics_lookups = \App\P022aOrgMetricsItem::get()->pluck('metric_description', 'id')->prepend(trans('global.app_please_select'), '');
        $created_bies = \App\User::get()->pluck('name', 'id')->prepend(trans('global.app_please_select'), '');

        $p022a_org_metrics_detail = P022aOrgMetricsDetail::findOrFail($id);

        return view('admin.p022a_org_metrics_details.edit', compact('p022a_org_metrics_detail', 'result_p5_organisations', 'result_p022_org_metrics_lookups', 'created_bies'));
    }

    /**
     * Update P022aOrgMetricsDetail in storage.
     *
     * @param  \App\Http\Requests\UpdateP022aOrgMetricsDetailsRequest  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateP022aOrgMetricsDetailsRequest $request, $id)
    {
        $p022a_org_metrics_detail = P022aOrgMetricsDetail::findOrFail($id);
        $p022a_org_metrics_detail->update($request->all());



        return redirect()->route('admin.p022a_org_metrics_details.index');
    }


    /**
     * Display P022aOrgMetricsDetail.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $p022a_org_metrics_detail = P022aOrgMetricsDetail::findOrFail($id);

        return view('admin.p022a_org_metrics_details.show', compact('p022a_org_metrics_detail'));
    }


    /**
     * Remove P022aOrgMetricsDetail from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $p022a_org_metrics_detail = P022aOrgMetricsDetail::findOrFail($id);
        $p022a_org_metrics_detail->delete();

        return redirect()->route('admin.p022a_org_metrics_details.index');
    }

    /**
     * Delete all selected P022aOrgMetricsDetail at once.
     *
     * @param Request $request
     */
    public function massDestroy(Request $request)
    {
        if ($request->input('ids')) {
            $entries = P022aOrgMetricsDetail::whereIn('id', $request->input('ids'))->get();

            foreach ($entries as $entry) {
                $entry->delete();
            }
        }
    }


    /**
     * Restore P022aOrgMetricsDetail from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function restore($id)
    {
        $p022a_org_metrics_detail = P022aOrgMetricsDetail::onlyTrashed()->findOrFail($id);
        $p022a_org_metrics_detail->restore();

        return redirect()->route('admin.p022a_org_metrics_details.index');
    }

    /**
     * Permanently delete P022aOrgMetricsDetail from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function perma_del($id)
    {
        $p022a_org_metrics_detail = P022aOrgMetricsDetail::onlyTrashed()->findOrFail($id);
        $p022a_org_metrics_detail->forceDelete();

        return redirect()->route('admin.p022a_org_metrics_details.index');
    }
}
