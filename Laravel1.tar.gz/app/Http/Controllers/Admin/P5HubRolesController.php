<?php

namespace App\Http\Controllers\Admin;

use App\P5HubRole;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\StoreP5HubRolesRequest;
use App\Http\Requests\Admin\UpdateP5HubRolesRequest;

use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
class P5HubRolesController extends Controller
{
    /**
     * Display a listing of P5HubRole.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {


        if (request('show_deleted') == 1) {
            if (! Gate::allows('p5_hub_role_delete')) {
                return abort(401);
            }
            $p5_hub_roles = P5HubRole::onlyTrashed()->get();
        } else {
            $p5_hub_roles = P5HubRole::all();
        }

        return view('admin.p5_hub_roles.index', compact('p5_hub_roles'));
    }

    /**
     * Show the form for creating new P5HubRole.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.p5_hub_roles.create');
    }

    /**
     * Store a newly created P5HubRole in storage.
     *
     * @param  \App\Http\Requests\StoreP5HubRolesRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreP5HubRolesRequest $request)
    {
        $p5_hub_role = P5HubRole::create($request->all());



        return redirect()->route('admin.p5_hub_roles.index');
    }


    /**
     * Show the form for editing P5HubRole.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $p5_hub_role = P5HubRole::findOrFail($id);

        return view('admin.p5_hub_roles.edit', compact('p5_hub_role'));
    }

    /**
     * Update P5HubRole in storage.
     *
     * @param  \App\Http\Requests\UpdateP5HubRolesRequest  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateP5HubRolesRequest $request, $id)
    {
        $p5_hub_role = P5HubRole::findOrFail($id);
        $p5_hub_role->update($request->all());



        return redirect()->route('admin.p5_hub_roles.index');
    }


    /**
     * Display P5HubRole.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $p5_hubs = \App\P5Hub::whereHas('hub_roles',
                    function ($query) use ($id) {
                        $query->where('id', $id);
                    })->get();

        $p5_hub_role = P5HubRole::findOrFail($id);

        return view('admin.p5_hub_roles.show', compact('p5_hub_role', 'p5_hubs'));
    }


    /**
     * Remove P5HubRole from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $p5_hub_role = P5HubRole::findOrFail($id);
        $p5_hub_role->delete();

        return redirect()->route('admin.p5_hub_roles.index');
    }

    /**
     * Delete all selected P5HubRole at once.
     *
     * @param Request $request
     */
    public function massDestroy(Request $request)
    {
        if ($request->input('ids')) {
            $entries = P5HubRole::whereIn('id', $request->input('ids'))->get();

            foreach ($entries as $entry) {
                $entry->delete();
            }
        }
    }


    /**
     * Restore P5HubRole from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function restore($id)
    {
        $p5_hub_role = P5HubRole::onlyTrashed()->findOrFail($id);
        $p5_hub_role->restore();

        return redirect()->route('admin.p5_hub_roles.index');
    }

    /**
     * Permanently delete P5HubRole from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function perma_del($id)
    {
        $p5_hub_role = P5HubRole::onlyTrashed()->findOrFail($id);
        $p5_hub_role->forceDelete();

        return redirect()->route('admin.p5_hub_roles.index');
    }
}
