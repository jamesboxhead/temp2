<?php

namespace App\Http\Controllers\Admin;

use App\P016Session;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\StoreP016SessionsRequest;
use App\Http\Requests\Admin\UpdateP016SessionsRequest;
use Yajra\DataTables\DataTables;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Input;

use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
class P016SessionsController extends Controller
{
    /**
     * Display a listing of P016Session.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if ($filterBy = Input::get('filter')) {
            if ($filterBy == 'all') {
                Session::put('P016Session.filter', 'all');
            } elseif ($filterBy == 'my') {
                Session::put('P016Session.filter', 'my');
            }
        }

        
        if (request()->ajax()) {
            $query = P016Session::query();
            $query->with("linked_p5_hub");
            $query->with("linked_session_status");
            $query->with("session_tags");
            $query->with("created_by");
            $template = 'actionsTemplate';
            if(request('show_deleted') == 1) {
                
                $query->onlyTrashed();
                $template = 'restoreTemplate';
            }
            $query->select([
                'p016_sessions.id',
                'p016_sessions.linked_p5_hub_id',
                'p016_sessions.linked_session_status_id',
                'p016_sessions.short_description',
                'p016_sessions.session_long_description',
                'p016_sessions.session_pin',
                'p016_sessions.session_start',
                'p016_sessions.session_end',
                'p016_sessions.session_info',
                'p016_sessions.session_map_location_address',
                'p016_sessions.offer_preso_email',
                'p016_sessions.url_presentation_to_send',
                'p016_sessions.created_by_id',
                'p016_sessions.offer_email_survey_detail',
                'p016_sessions.offer_hub_info',
                'p016_sessions.offer_pass_on_email',
                'p016_sessions.offer_voting',
                'p016_sessions.live_results_url',
                'p016_sessions.voting_duration',
                'p016_sessions.voting_headline',
                'p016_sessions.voting_info_presented',
                'p016_sessions.voting_info_mobile',
            ]);
            $table = Datatables::of($query);

            $table->setRowAttr([
                'data-entry-id' => '{{$id}}',
            ]);
            $table->addColumn('massDelete', '&nbsp;');
            $table->addColumn('actions', '&nbsp;');
            $table->editColumn('actions', function ($row) use ($template) {
                $gateKey  = 'p016_session_';
                $routeKey = 'admin.p016_sessions';

                return view($template, compact('row', 'gateKey', 'routeKey'));
            });
            $table->editColumn('linked_p5_hub.hub_name', function ($row) {
                return $row->linked_p5_hub ? $row->linked_p5_hub->hub_name : '';
            });
            $table->editColumn('linked_session_status.session_status_code', function ($row) {
                return $row->linked_session_status ? $row->linked_session_status->session_status_code : '';
            });
            $table->editColumn('short_description', function ($row) {
                return $row->short_description ? $row->short_description : '';
            });
            $table->editColumn('session_long_description', function ($row) {
                return $row->session_long_description ? $row->session_long_description : '';
            });
            $table->editColumn('session_tags.tag', function ($row) {
                if(count($row->session_tags) == 0) {
                    return '';
                }

                return '<span class="label label-info label-many">' . implode('</span><span class="label label-info label-many"> ',
                        $row->session_tags->pluck('tag')->toArray()) . '</span>';
            });
            $table->editColumn('session_pin', function ($row) {
                return $row->session_pin ? $row->session_pin : '';
            });
            $table->editColumn('session_start', function ($row) {
                return $row->session_start ? $row->session_start : '';
            });
            $table->editColumn('session_end', function ($row) {
                return $row->session_end ? $row->session_end : '';
            });
            $table->editColumn('session_info', function ($row) {
                return $row->session_info ? $row->session_info : '';
            });
            $table->editColumn('session_map_location', function ($row) {
                return $row->session_map_location ? $row->session_map_location : '';
            });
            $table->editColumn('offer_preso_email', function ($row) {
                return \Form::checkbox("offer_preso_email", 1, $row->offer_preso_email == 1, ["disabled"]);
            });
            $table->editColumn('url_presentation_to_send', function ($row) {
                return $row->url_presentation_to_send ? $row->url_presentation_to_send : '';
            });
            $table->editColumn('created_by.name', function ($row) {
                return $row->created_by ? $row->created_by->name : '';
            });
            $table->editColumn('offer_email_survey_detail', function ($row) {
                return \Form::checkbox("offer_email_survey_detail", 1, $row->offer_email_survey_detail == 1, ["disabled"]);
            });
            $table->editColumn('offer_hub_info', function ($row) {
                return \Form::checkbox("offer_hub_info", 1, $row->offer_hub_info == 1, ["disabled"]);
            });
            $table->editColumn('offer_pass_on_email', function ($row) {
                return \Form::checkbox("offer_pass_on_email", 1, $row->offer_pass_on_email == 1, ["disabled"]);
            });
            $table->editColumn('offer_voting', function ($row) {
                return \Form::checkbox("offer_voting", 1, $row->offer_voting == 1, ["disabled"]);
            });
            $table->editColumn('live_results_url', function ($row) {
                return $row->live_results_url ? $row->live_results_url : '';
            });
            $table->editColumn('voting_duration', function ($row) {
                return $row->voting_duration ? $row->voting_duration : '';
            });
            $table->editColumn('voting_headline', function ($row) {
                return $row->voting_headline ? $row->voting_headline : '';
            });
            $table->editColumn('voting_info_presented', function ($row) {
                return $row->voting_info_presented ? $row->voting_info_presented : '';
            });
            $table->editColumn('voting_info_mobile', function ($row) {
                return $row->voting_info_mobile ? $row->voting_info_mobile : '';
            });

            $table->rawColumns(['actions','session_tags.tag','offer_preso_email','offer_email_survey_detail','offer_hub_info','offer_pass_on_email','offer_voting']);

            return $table->make(true);
        }

        return view('admin.p016_sessions.index');
    }

    /**
     * Show the form for creating new P016Session.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        
        $linked_p5_hubs = \App\P5Hub::get()->pluck('hub_name', 'id')->prepend(trans('global.app_please_select'), '');
        $linked_session_statuses = \App\P016SessionStatus::get()->pluck('session_status_code', 'id')->prepend(trans('global.app_please_select'), '');
        $session_tags = \App\P5Tag::get()->pluck('tag', 'id');

        $created_bies = \App\User::get()->pluck('name', 'id')->prepend(trans('global.app_please_select'), '');

        return view('admin.p016_sessions.create', compact('linked_p5_hubs', 'linked_session_statuses', 'session_tags', 'created_bies'));
    }

    /**
     * Store a newly created P016Session in storage.
     *
     * @param  \App\Http\Requests\StoreP016SessionsRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreP016SessionsRequest $request)
    {
        $p016_session = P016Session::create($request->all());
        $p016_session->session_tags()->sync(array_filter((array)$request->input('session_tags')));



        return redirect()->route('admin.p016_sessions.index');
    }


    /**
     * Show the form for editing P016Session.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        
        $linked_p5_hubs = \App\P5Hub::get()->pluck('hub_name', 'id')->prepend(trans('global.app_please_select'), '');
        $linked_session_statuses = \App\P016SessionStatus::get()->pluck('session_status_code', 'id')->prepend(trans('global.app_please_select'), '');
        $session_tags = \App\P5Tag::get()->pluck('tag', 'id');

        $created_bies = \App\User::get()->pluck('name', 'id')->prepend(trans('global.app_please_select'), '');

        $p016_session = P016Session::findOrFail($id);

        return view('admin.p016_sessions.edit', compact('p016_session', 'linked_p5_hubs', 'linked_session_statuses', 'session_tags', 'created_bies'));
    }

    /**
     * Update P016Session in storage.
     *
     * @param  \App\Http\Requests\UpdateP016SessionsRequest  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateP016SessionsRequest $request, $id)
    {
        $p016_session = P016Session::findOrFail($id);
        $p016_session->update($request->all());
        $p016_session->session_tags()->sync(array_filter((array)$request->input('session_tags')));



        return redirect()->route('admin.p016_sessions.index');
    }


    /**
     * Display P016Session.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        
        $linked_p5_hubs = \App\P5Hub::get()->pluck('hub_name', 'id')->prepend(trans('global.app_please_select'), '');
        $linked_session_statuses = \App\P016SessionStatus::get()->pluck('session_status_code', 'id')->prepend(trans('global.app_please_select'), '');
        $session_tags = \App\P5Tag::get()->pluck('tag', 'id');

        $created_bies = \App\User::get()->pluck('name', 'id')->prepend(trans('global.app_please_select'), '');$p016_session_voting_options = \App\P016SessionVotingOption::where('linked_p016_session_id', $id)->get();$p016_session_voting_results = \App\P016SessionVotingResult::where('linked_session_id', $id)->get();$p016_mobi_meeting_participants = \App\P016MobiMeetingParticipant::where('linked_session_id', $id)->get();

        $p016_session = P016Session::findOrFail($id);

        return view('admin.p016_sessions.show', compact('p016_session', 'p016_session_voting_options', 'p016_session_voting_results', 'p016_mobi_meeting_participants'));
    }


    /**
     * Remove P016Session from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $p016_session = P016Session::findOrFail($id);
        $p016_session->delete();

        return redirect()->route('admin.p016_sessions.index');
    }

    /**
     * Delete all selected P016Session at once.
     *
     * @param Request $request
     */
    public function massDestroy(Request $request)
    {
        if ($request->input('ids')) {
            $entries = P016Session::whereIn('id', $request->input('ids'))->get();

            foreach ($entries as $entry) {
                $entry->delete();
            }
        }
    }


    /**
     * Restore P016Session from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function restore($id)
    {
        $p016_session = P016Session::onlyTrashed()->findOrFail($id);
        $p016_session->restore();

        return redirect()->route('admin.p016_sessions.index');
    }

    /**
     * Permanently delete P016Session from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function perma_del($id)
    {
        $p016_session = P016Session::onlyTrashed()->findOrFail($id);
        $p016_session->forceDelete();

        return redirect()->route('admin.p016_sessions.index');
    }
}
