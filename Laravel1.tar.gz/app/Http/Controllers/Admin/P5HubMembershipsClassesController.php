<?php

namespace App\Http\Controllers\Admin;

use App\P5HubMembershipsClass;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\StoreP5HubMembershipsClassesRequest;
use App\Http\Requests\Admin\UpdateP5HubMembershipsClassesRequest;
use Yajra\DataTables\DataTables;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Input;

use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
class P5HubMembershipsClassesController extends Controller
{
    /**
     * Display a listing of P5HubMembershipsClass.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if ($filterBy = Input::get('filter')) {
            if ($filterBy == 'all') {
                Session::put('P5HubMembershipsClass.filter', 'all');
            } elseif ($filterBy == 'my') {
                Session::put('P5HubMembershipsClass.filter', 'my');
            }
        }

        
        if (request()->ajax()) {
            $query = P5HubMembershipsClass::query();
            $query->with("created_by");
            $template = 'actionsTemplate';
            if(request('show_deleted') == 1) {
                
                $query->onlyTrashed();
                $template = 'restoreTemplate';
            }
            $query->select([
                'p5_hub_memberships_classes.id',
                'p5_hub_memberships_classes.class_code',
                'p5_hub_memberships_classes.class',
                'p5_hub_memberships_classes.notes',
                'p5_hub_memberships_classes.sort_order',
                'p5_hub_memberships_classes.dq',
                'p5_hub_memberships_classes.created_by_id',
            ]);
            $table = Datatables::of($query);

            $table->setRowAttr([
                'data-entry-id' => '{{$id}}',
            ]);
            $table->addColumn('massDelete', '&nbsp;');
            $table->addColumn('actions', '&nbsp;');
            $table->editColumn('actions', function ($row) use ($template) {
                $gateKey  = 'p5_hub_memberships_class_';
                $routeKey = 'admin.p5_hub_memberships_classes';

                return view($template, compact('row', 'gateKey', 'routeKey'));
            });
            $table->editColumn('class_code', function ($row) {
                return $row->class_code ? $row->class_code : '';
            });
            $table->editColumn('class', function ($row) {
                return $row->class ? $row->class : '';
            });
            $table->editColumn('notes', function ($row) {
                return $row->notes ? $row->notes : '';
            });
            $table->editColumn('sort_order', function ($row) {
                return $row->sort_order ? $row->sort_order : '';
            });
            $table->editColumn('dq', function ($row) {
                return $row->dq ? $row->dq : '';
            });
            $table->editColumn('created_by.name', function ($row) {
                return $row->created_by ? $row->created_by->name : '';
            });

            $table->rawColumns(['actions']);

            return $table->make(true);
        }

        return view('admin.p5_hub_memberships_classes.index');
    }

    /**
     * Show the form for creating new P5HubMembershipsClass.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        
        $created_bies = \App\User::get()->pluck('name', 'id')->prepend(trans('global.app_please_select'), '');

        return view('admin.p5_hub_memberships_classes.create', compact('created_bies'));
    }

    /**
     * Store a newly created P5HubMembershipsClass in storage.
     *
     * @param  \App\Http\Requests\StoreP5HubMembershipsClassesRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreP5HubMembershipsClassesRequest $request)
    {
        $p5_hub_memberships_class = P5HubMembershipsClass::create($request->all());

        foreach ($request->input('p5_hub_memberships_individuals', []) as $data) {
            $p5_hub_memberships_class->p5_hub_memberships_individuals()->create($data);
        }


        return redirect()->route('admin.p5_hub_memberships_classes.index');
    }


    /**
     * Show the form for editing P5HubMembershipsClass.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        
        $created_bies = \App\User::get()->pluck('name', 'id')->prepend(trans('global.app_please_select'), '');

        $p5_hub_memberships_class = P5HubMembershipsClass::findOrFail($id);

        return view('admin.p5_hub_memberships_classes.edit', compact('p5_hub_memberships_class', 'created_bies'));
    }

    /**
     * Update P5HubMembershipsClass in storage.
     *
     * @param  \App\Http\Requests\UpdateP5HubMembershipsClassesRequest  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateP5HubMembershipsClassesRequest $request, $id)
    {
        $p5_hub_memberships_class = P5HubMembershipsClass::findOrFail($id);
        $p5_hub_memberships_class->update($request->all());

        $p5HubMembershipsIndividuals           = $p5_hub_memberships_class->p5_hub_memberships_individuals;
        $currentP5HubMembershipsIndividualData = [];
        foreach ($request->input('p5_hub_memberships_individuals', []) as $index => $data) {
            if (is_integer($index)) {
                $p5_hub_memberships_class->p5_hub_memberships_individuals()->create($data);
            } else {
                $id                          = explode('-', $index)[1];
                $currentP5HubMembershipsIndividualData[$id] = $data;
            }
        }
        foreach ($p5HubMembershipsIndividuals as $item) {
            if (isset($currentP5HubMembershipsIndividualData[$item->id])) {
                $item->update($currentP5HubMembershipsIndividualData[$item->id]);
            } else {
                $item->delete();
            }
        }


        return redirect()->route('admin.p5_hub_memberships_classes.index');
    }


    /**
     * Display P5HubMembershipsClass.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        
        $created_bies = \App\User::get()->pluck('name', 'id')->prepend(trans('global.app_please_select'), '');$p5_hub_memberships = \App\P5HubMembership::where('linked_membership_class_id', $id)->get();$p5_hub_memberships_individuals = \App\P5HubMembershipsIndividual::where('linked_membership_class_id', $id)->get();

        $p5_hub_memberships_class = P5HubMembershipsClass::findOrFail($id);

        return view('admin.p5_hub_memberships_classes.show', compact('p5_hub_memberships_class', 'p5_hub_memberships', 'p5_hub_memberships_individuals'));
    }


    /**
     * Remove P5HubMembershipsClass from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $p5_hub_memberships_class = P5HubMembershipsClass::findOrFail($id);
        $p5_hub_memberships_class->delete();

        return redirect()->route('admin.p5_hub_memberships_classes.index');
    }

    /**
     * Delete all selected P5HubMembershipsClass at once.
     *
     * @param Request $request
     */
    public function massDestroy(Request $request)
    {
        if ($request->input('ids')) {
            $entries = P5HubMembershipsClass::whereIn('id', $request->input('ids'))->get();

            foreach ($entries as $entry) {
                $entry->delete();
            }
        }
    }


    /**
     * Restore P5HubMembershipsClass from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function restore($id)
    {
        $p5_hub_memberships_class = P5HubMembershipsClass::onlyTrashed()->findOrFail($id);
        $p5_hub_memberships_class->restore();

        return redirect()->route('admin.p5_hub_memberships_classes.index');
    }

    /**
     * Permanently delete P5HubMembershipsClass from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function perma_del($id)
    {
        $p5_hub_memberships_class = P5HubMembershipsClass::onlyTrashed()->findOrFail($id);
        $p5_hub_memberships_class->forceDelete();

        return redirect()->route('admin.p5_hub_memberships_classes.index');
    }
}
