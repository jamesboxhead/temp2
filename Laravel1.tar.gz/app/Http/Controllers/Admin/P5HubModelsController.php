<?php

namespace App\Http\Controllers\Admin;

use App\P5HubModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\StoreP5HubModelsRequest;
use App\Http\Requests\Admin\UpdateP5HubModelsRequest;
use Yajra\DataTables\DataTables;

use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
class P5HubModelsController extends Controller
{
    /**
     * Display a listing of P5HubModel.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {


        
        if (request()->ajax()) {
            $query = P5HubModel::query();
            $template = 'actionsTemplate';
            if(request('show_deleted') == 1) {
                
                $query->onlyTrashed();
                $template = 'restoreTemplate';
            }
            $query->select([
                'p5_hub_models.id',
                'p5_hub_models.hub_model',
                'p5_hub_models.sort_code',
                'p5_hub_models.dq',
            ]);
            $table = Datatables::of($query);

            $table->setRowAttr([
                'data-entry-id' => '{{$id}}',
            ]);
            $table->addColumn('massDelete', '&nbsp;');
            $table->addColumn('actions', '&nbsp;');
            $table->editColumn('actions', function ($row) use ($template) {
                $gateKey  = 'p5_hub_model_';
                $routeKey = 'admin.p5_hub_models';

                return view($template, compact('row', 'gateKey', 'routeKey'));
            });
            $table->editColumn('hub_model', function ($row) {
                return $row->hub_model ? $row->hub_model : '';
            });
            $table->editColumn('dq', function ($row) {
                return $row->dq ? $row->dq : '';
            });

            $table->rawColumns(['actions']);

            return $table->make(true);
        }

        return view('admin.p5_hub_models.index');
    }

    /**
     * Show the form for creating new P5HubModel.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.p5_hub_models.create');
    }

    /**
     * Store a newly created P5HubModel in storage.
     *
     * @param  \App\Http\Requests\StoreP5HubModelsRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreP5HubModelsRequest $request)
    {
        $p5_hub_model = P5HubModel::create($request->all());



        return redirect()->route('admin.p5_hub_models.index');
    }


    /**
     * Show the form for editing P5HubModel.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $p5_hub_model = P5HubModel::findOrFail($id);

        return view('admin.p5_hub_models.edit', compact('p5_hub_model'));
    }

    /**
     * Update P5HubModel in storage.
     *
     * @param  \App\Http\Requests\UpdateP5HubModelsRequest  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateP5HubModelsRequest $request, $id)
    {
        $p5_hub_model = P5HubModel::findOrFail($id);
        $p5_hub_model->update($request->all());



        return redirect()->route('admin.p5_hub_models.index');
    }


    /**
     * Display P5HubModel.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $p5_hubs = \App\P5Hub::where('hub_model_id', $id)->get();

        $p5_hub_model = P5HubModel::findOrFail($id);

        return view('admin.p5_hub_models.show', compact('p5_hub_model', 'p5_hubs'));
    }


    /**
     * Remove P5HubModel from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $p5_hub_model = P5HubModel::findOrFail($id);
        $p5_hub_model->delete();

        return redirect()->route('admin.p5_hub_models.index');
    }

    /**
     * Delete all selected P5HubModel at once.
     *
     * @param Request $request
     */
    public function massDestroy(Request $request)
    {
        if ($request->input('ids')) {
            $entries = P5HubModel::whereIn('id', $request->input('ids'))->get();

            foreach ($entries as $entry) {
                $entry->delete();
            }
        }
    }


    /**
     * Restore P5HubModel from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function restore($id)
    {
        $p5_hub_model = P5HubModel::onlyTrashed()->findOrFail($id);
        $p5_hub_model->restore();

        return redirect()->route('admin.p5_hub_models.index');
    }

    /**
     * Permanently delete P5HubModel from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function perma_del($id)
    {
        $p5_hub_model = P5HubModel::onlyTrashed()->findOrFail($id);
        $p5_hub_model->forceDelete();

        return redirect()->route('admin.p5_hub_models.index');
    }
}
