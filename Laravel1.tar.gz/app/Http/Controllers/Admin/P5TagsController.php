<?php

namespace App\Http\Controllers\Admin;

use App\P5Tag;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\StoreP5TagsRequest;
use App\Http\Requests\Admin\UpdateP5TagsRequest;
use Yajra\DataTables\DataTables;

use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
class P5TagsController extends Controller
{
    /**
     * Display a listing of P5Tag.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {


        
        if (request()->ajax()) {
            $query = P5Tag::query();
            $template = 'actionsTemplate';
            if(request('show_deleted') == 1) {
                
                $query->onlyTrashed();
                $template = 'restoreTemplate';
            }
            $query->select([
                'p5_tags.id',
                'p5_tags.tag',
                'p5_tags.notes',
                'p5_tags.dq',
            ]);
            $table = Datatables::of($query);

            $table->setRowAttr([
                'data-entry-id' => '{{$id}}',
            ]);
            $table->addColumn('massDelete', '&nbsp;');
            $table->addColumn('actions', '&nbsp;');
            $table->editColumn('actions', function ($row) use ($template) {
                $gateKey  = 'p5_tag_';
                $routeKey = 'admin.p5_tags';

                return view($template, compact('row', 'gateKey', 'routeKey'));
            });
            $table->editColumn('tag', function ($row) {
                return $row->tag ? $row->tag : '';
            });
            $table->editColumn('notes', function ($row) {
                return $row->notes ? $row->notes : '';
            });
            $table->editColumn('dq', function ($row) {
                return $row->dq ? $row->dq : '';
            });

            $table->rawColumns(['actions']);

            return $table->make(true);
        }

        return view('admin.p5_tags.index');
    }

    /**
     * Show the form for creating new P5Tag.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.p5_tags.create');
    }

    /**
     * Store a newly created P5Tag in storage.
     *
     * @param  \App\Http\Requests\StoreP5TagsRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreP5TagsRequest $request)
    {
        $p5_tag = P5Tag::create($request->all());



        return redirect()->route('admin.p5_tags.index');
    }


    /**
     * Show the form for editing P5Tag.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $p5_tag = P5Tag::findOrFail($id);

        return view('admin.p5_tags.edit', compact('p5_tag'));
    }

    /**
     * Update P5Tag in storage.
     *
     * @param  \App\Http\Requests\UpdateP5TagsRequest  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateP5TagsRequest $request, $id)
    {
        $p5_tag = P5Tag::findOrFail($id);
        $p5_tag->update($request->all());



        return redirect()->route('admin.p5_tags.index');
    }


    /**
     * Display P5Tag.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $users = \App\User::whereHas('user_tags',
                    function ($query) use ($id) {
                        $query->where('id', $id);
                    })->get();$p016_sessions = \App\P016Session::whereHas('session_tags',
                    function ($query) use ($id) {
                        $query->where('id', $id);
                    })->get();$p5_hubs = \App\P5Hub::whereHas('hub_tags',
                    function ($query) use ($id) {
                        $query->where('id', $id);
                    })->get();$p5_programs = \App\P5Program::whereHas('prog_tags',
                    function ($query) use ($id) {
                        $query->where('id', $id);
                    })->get();$p5_organisations = \App\P5Organisation::whereHas('org_tags',
                    function ($query) use ($id) {
                        $query->where('id', $id);
                    })->get();

        $p5_tag = P5Tag::findOrFail($id);

        return view('admin.p5_tags.show', compact('p5_tag', 'users', 'p016_sessions', 'p5_hubs', 'p5_programs', 'p5_organisations'));
    }


    /**
     * Remove P5Tag from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $p5_tag = P5Tag::findOrFail($id);
        $p5_tag->delete();

        return redirect()->route('admin.p5_tags.index');
    }

    /**
     * Delete all selected P5Tag at once.
     *
     * @param Request $request
     */
    public function massDestroy(Request $request)
    {
        if ($request->input('ids')) {
            $entries = P5Tag::whereIn('id', $request->input('ids'))->get();

            foreach ($entries as $entry) {
                $entry->delete();
            }
        }
    }


    /**
     * Restore P5Tag from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function restore($id)
    {
        $p5_tag = P5Tag::onlyTrashed()->findOrFail($id);
        $p5_tag->restore();

        return redirect()->route('admin.p5_tags.index');
    }

    /**
     * Permanently delete P5Tag from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function perma_del($id)
    {
        $p5_tag = P5Tag::onlyTrashed()->findOrFail($id);
        $p5_tag->forceDelete();

        return redirect()->route('admin.p5_tags.index');
    }
}
