<?php
namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\Traits\FilterByUser;

/**
 * Class P016SessionVotingOption
 *
 * @package App
 * @property string $linked_p016_session
 * @property string $option_code
 * @property string $option_displayed
 * @property text $option_more_info
 * @property string $sort_order
 * @property string $created_by
*/
class P016SessionVotingOption extends Model
{
    use SoftDeletes, FilterByUser;

    protected $fillable = ['option_code', 'option_displayed', 'option_more_info', 'sort_order', 'linked_p016_session_id', 'created_by_id'];
    public static $searchable = [
    ];
    
    public static function boot()
    {
        parent::boot();

        P016SessionVotingOption::observe(new \App\Observers\UserActionsObserver);
    }

    /**
     * Set to null if empty
     * @param $input
     */
    public function setLinkedP016SessionIdAttribute($input)
    {
        $this->attributes['linked_p016_session_id'] = $input ? $input : null;
    }

    /**
     * Set to null if empty
     * @param $input
     */
    public function setCreatedByIdAttribute($input)
    {
        $this->attributes['created_by_id'] = $input ? $input : null;
    }
    
    public function linked_p016_session()
    {
        return $this->belongsTo(P016Session::class, 'linked_p016_session_id')->withTrashed();
    }
    
    public function created_by()
    {
        return $this->belongsTo(User::class, 'created_by_id');
    }
    
}
