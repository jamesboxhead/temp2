<?php
namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * Class P016SessionStatus
 *
 * @package App
 * @property string $session_status_code
 * @property string $sort_code
*/
class P016SessionStatus extends Model
{
    use SoftDeletes;

    protected $fillable = ['session_status_code', 'sort_code'];
    public static $searchable = [
    ];
    
    public static function boot()
    {
        parent::boot();

        P016SessionStatus::observe(new \App\Observers\UserActionsObserver);
    }
    
}
