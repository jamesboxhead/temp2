<?php

$factory->define(App\P022aOrgMetricsDetail::class, function (Faker\Generator $faker) {
    return [
        "result_as_at" => $faker->date("d/m/Y", $max = 'now'),
        "result_p5_organisation_id" => factory('App\P5Organisation')->create(),
        "p022_result_raw" => $faker->name,
        "result_p022_org_metrics_lookup_id" => factory('App\P022aOrgMetricsItem')->create(),
        "result_source" => $faker->name,
        "p022_result_value" => $faker->randomNumber(2),
        "p022_validation_status" => $faker->name,
        "created_by_id" => factory('App\User')->create(),
    ];
});
