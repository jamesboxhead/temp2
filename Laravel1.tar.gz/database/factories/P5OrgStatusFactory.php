<?php

$factory->define(App\P5OrgStatus::class, function (Faker\Generator $faker) {
    return [
        "org_status" => $faker->name,
        "sort_code" => $faker->name,
        "dq" => $faker->name,
    ];
});
