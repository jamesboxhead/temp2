<?php

$factory->define(App\P5UserGender::class, function (Faker\Generator $faker) {
    return [
        "gender_description" => $faker->name,
        "gender_code" => $faker->name,
        "gender_fa_icon" => $faker->name,
        "sort_code" => $faker->name,
    ];
});
