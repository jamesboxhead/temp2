<?php

$factory->define(App\MonthlyReport::class, function (Faker\Generator $faker) {
    return [

    ];
});
