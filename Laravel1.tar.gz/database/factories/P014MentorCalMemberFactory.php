<?php

$factory->define(App\P014MentorCalMember::class, function (Faker\Generator $faker) {
    return [

    ];
});
