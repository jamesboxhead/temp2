<?php

$factory->define(App\P014MentorCalHub::class, function (Faker\Generator $faker) {
    return [

    ];
});
