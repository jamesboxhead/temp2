<?php

$factory->define(App\P5Tag::class, function (Faker\Generator $faker) {
    return [
        "tag" => $faker->name,
        "notes" => $faker->name,
        "dq" => $faker->name,
    ];
});
