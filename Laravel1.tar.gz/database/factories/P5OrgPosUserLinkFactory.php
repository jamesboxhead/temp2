<?php

$factory->define(App\P5OrgPosUserLink::class, function (Faker\Generator $faker) {
    return [
        "username_id" => factory('App\User')->create(),
        "org_link_id" => factory('App\P5Organisation')->create(),
        "org_relationship_id" => factory('App\P5Position')->create(),
        "relationship_is_current" => 1,
        "relationship_started" => $faker->date("d/m/Y", $max = 'now'),
        "relationship_ended" => $faker->date("d/m/Y", $max = 'now'),
        "notes" => $faker->name,
        "dq" => $faker->name,
        "created_by_id" => factory('App\User')->create(),
    ];
});
