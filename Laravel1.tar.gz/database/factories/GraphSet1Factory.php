<?php

$factory->define(App\GraphSet1::class, function (Faker\Generator $faker) {
    return [

    ];
});
