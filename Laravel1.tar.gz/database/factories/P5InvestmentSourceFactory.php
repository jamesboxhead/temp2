<?php

$factory->define(App\P5InvestmentSource::class, function (Faker\Generator $faker) {
    return [
        "investment_source_description" => $faker->name,
        "sort_code" => $faker->name,
    ];
});
