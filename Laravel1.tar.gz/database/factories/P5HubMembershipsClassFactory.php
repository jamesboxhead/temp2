<?php

$factory->define(App\P5HubMembershipsClass::class, function (Faker\Generator $faker) {
    return [
        "class_code" => $faker->name,
        "class" => $faker->name,
        "notes" => $faker->name,
        "sort_order" => $faker->name,
        "dq" => $faker->name,
        "created_by_id" => factory('App\User')->create(),
    ];
});
