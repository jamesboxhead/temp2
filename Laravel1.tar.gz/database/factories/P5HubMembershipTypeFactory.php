<?php

$factory->define(App\P5HubMembershipType::class, function (Faker\Generator $faker) {
    return [
        "description" => $faker->name,
        "sort_order" => $faker->name,
        "dq" => $faker->name,
    ];
});
