<?php

$factory->define(App\P012Survey::class, function (Faker\Generator $faker) {
    return [

    ];
});
