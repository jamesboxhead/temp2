<?php

$factory->define(App\P5Investment::class, function (Faker\Generator $faker) {
    return [
        "org_invested_in_id" => factory('App\P5Organisation')->create(),
        "date_of_investment" => $faker->date("d/m/Y", $max = 'now'),
        "amnt_of_investment" => $faker->randomNumber(2),
        "investment_currency" => $faker->name,
        "p5_actual_investment_souce_id" => factory('App\P5InvestmentSource')->create(),
        "inverstor_entity_type" => collect(["Incorporated","Individual",])->random(),
        "investor_org_id" => factory('App\P5Organisation')->create(),
        "investor_individual_id" => factory('App\User')->create(),
        "notes" => $faker->name,
        "dq" => $faker->name,
        "created_by_id" => factory('App\User')->create(),
    ];
});
