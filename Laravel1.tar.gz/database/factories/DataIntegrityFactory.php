<?php

$factory->define(App\DataIntegrity::class, function (Faker\Generator $faker) {
    return [

    ];
});
