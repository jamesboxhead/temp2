<?php

$factory->define(App\User::class, function (Faker\Generator $faker) {
    return [
        "name" => $faker->name,
        "first_name" => $faker->name,
        "last_name" => $faker->name,
        "email" => $faker->safeEmail,
        "primary_phone_contact" => $faker->name,
        "primary_web_address" => $faker->name,
        "linked_gender_id" => factory('App\P5UserGender')->create(),
        "address_line_1" => $faker->name,
        "address_line_2" => $faker->name,
        "city" => $faker->name,
        "linked_state_id" => factory('App\P5State')->create(),
        "postcode" => $faker->name,
        "year_of_birth" => $faker->randomNumber(2),
        "password" => str_random(10),
        "remember_token" => $faker->name,
        "created_by_id" => factory('App\User')->create(),
        "dq" => $faker->name,
    ];
});
