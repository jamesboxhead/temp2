<?php

$factory->define(App\P009FieldLevel::class, function (Faker\Generator $faker) {
    return [
        "graph_id" => factory('App\P009Graph')->create(),
        "level" => $faker->randomNumber(2),
        "level_num_table" => $faker->name,
        "level_num_show_field" => $faker->name,
        "level_num_join_field" => $faker->name,
        "level_num_join_statement" => $faker->name,
        "level_num_method" => $faker->name,
        "level_num_groupby" => $faker->name,
        "created_by_id" => factory('App\User')->create(),
    ];
});
