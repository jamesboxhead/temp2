<?php

$factory->define(App\TasksOutcome::class, function (Faker\Generator $faker) {
    return [
        "outcome" => $faker->name,
        "sort_code" => $faker->name,
    ];
});
