<?php

$factory->define(App\P014Reportset2::class, function (Faker\Generator $faker) {
    return [

    ];
});
