<?php

$factory->define(App\P5Position::class, function (Faker\Generator $faker) {
    return [
        "pos_title" => $faker->name,
        "sort_code" => $faker->name,
        "dq" => $faker->name,
    ];
});
