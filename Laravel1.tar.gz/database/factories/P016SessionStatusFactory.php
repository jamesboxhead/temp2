<?php

$factory->define(App\P016SessionStatus::class, function (Faker\Generator $faker) {
    return [
        "session_status_code" => $faker->name,
        "sort_code" => $faker->name,
    ];
});
