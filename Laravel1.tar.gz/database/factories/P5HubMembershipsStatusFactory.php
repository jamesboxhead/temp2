<?php

$factory->define(App\P5HubMembershipsStatus::class, function (Faker\Generator $faker) {
    return [
        "status_code" => $faker->name,
        "status" => $faker->name,
        "sort_code" => $faker->name,
        "status_notes" => $faker->name,
        "dq" => $faker->name,
        "created_by_id" => factory('App\User')->create(),
    ];
});
