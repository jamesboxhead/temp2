<?php

$factory->define(App\P022AnzsisReporting::class, function (Faker\Generator $faker) {
    return [

    ];
});
