<?php

$factory->define(App\P5Organisation::class, function (Faker\Generator $faker) {
    return [
        "trading_name" => $faker->name,
        "legal_name" => $faker->name,
        "org_status_id" => factory('App\P5OrgStatus')->create(),
        "address_line_1" => $faker->name,
        "address_line_2" => $faker->name,
        "surburb" => $faker->name,
        "post_code" => $faker->name,
        "state_id" => factory('App\P5State')->create(),
        "established" => $faker->date("d/m/Y", $max = 'now'),
        "primary_web_site" => $faker->name,
        "business_model_id" => factory('App\P5BusinessModel')->create(),
        "p5_anzic_level1_id" => factory('App\P5Industry')->create(),
        "general_info" => $faker->name,
        "primary_email" => $faker->safeEmail,
        "url_linkedin" => $faker->name,
        "url_facebook" => $faker->name,
        "url_twitter" => $faker->name,
        "url_instagram" => $faker->name,
        "url_angellist" => $faker->name,
        "url_crunchbase" => $faker->name,
        "map_style_url" => $faker->name,
        "created_by_id" => factory('App\User')->create(),
        "dq" => $faker->name,
    ];
});
