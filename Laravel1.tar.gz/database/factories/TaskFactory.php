<?php

$factory->define(App\Task::class, function (Faker\Generator $faker) {
    return [
        "user_id" => factory('App\User')->create(),
        "mentor_id" => factory('App\User')->create(),
        "due_date" => $faker->date("d/m/Y", $max = 'now'),
        "status_id" => factory('App\TaskStatus')->create(),
        "outcome_id" => factory('App\TasksOutcome')->create(),
        "meeting_time" => $faker->randomNumber(2),
        "name" => $faker->name,
        "notes" => $faker->name,
        "dq" => $faker->name,
        "created_by_id" => factory('App\User')->create(),
    ];
});
