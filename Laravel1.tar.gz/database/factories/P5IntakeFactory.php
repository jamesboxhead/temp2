<?php

$factory->define(App\P5Intake::class, function (Faker\Generator $faker) {
    return [
        "program_id" => factory('App\P5Program')->create(),
        "intake_group" => $faker->name,
        "start_date" => $faker->date("d/m/Y", $max = 'now'),
        "end_date1" => $faker->date("d/m/Y", $max = 'now'),
        "description" => $faker->name,
        "website" => $faker->name,
        "created_by_id" => factory('App\User')->create(),
        "dq" => $faker->name,
    ];
});
