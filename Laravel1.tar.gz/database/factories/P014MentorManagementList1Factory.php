<?php

$factory->define(App\P014MentorManagementList1::class, function (Faker\Generator $faker) {
    return [

    ];
});
