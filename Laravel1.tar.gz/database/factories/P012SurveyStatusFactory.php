<?php

$factory->define(App\P012SurveyStatus::class, function (Faker\Generator $faker) {
    return [

    ];
});
