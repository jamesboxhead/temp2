<?php

$factory->define(App\P5HubMembershipsIndividual::class, function (Faker\Generator $faker) {
    return [
        "hub_id" => factory('App\P5Hub')->create(),
        "individual_id" => factory('App\User')->create(),
        "member_type_id" => factory('App\P5HubMembershipType')->create(),
        "linked_hub_membership_status_id" => factory('App\P5HubMembershipsStatus')->create(),
        "linked_membership_class_id" => factory('App\P5HubMembershipsClass')->create(),
        "membership_number" => $faker->name,
        "membership_start" => $faker->date("d/m/Y", $max = 'now'),
        "membership_end" => $faker->date("d/m/Y", $max = 'now'),
        "billing_fee" => $faker->name,
        "billing_period" => $faker->name,
        "billing_payment_method" => $faker->name,
        "on_group_facebook" => $faker->name,
        "on_group_mailer" => $faker->name,
        "on_group_meetup" => $faker->name,
        "on_signup_sheet" => $faker->name,
        "notes" => $faker->name,
        "dq" => $faker->name,
        "created_by_id" => factory('App\User')->create(),
    ];
});
