<?php

$factory->define(App\P5State::class, function (Faker\Generator $faker) {
    return [
        "state" => $faker->name,
        "state_long" => $faker->name,
        "created_by_id" => factory('App\User')->create(),
    ];
});
