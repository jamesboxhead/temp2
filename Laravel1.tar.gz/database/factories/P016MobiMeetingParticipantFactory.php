<?php

$factory->define(App\P016MobiMeetingParticipant::class, function (Faker\Generator $faker) {
    return [
        "linked_session_id" => factory('App\P016Session')->create(),
        "created_uid" => $faker->name,
        "participant_status" => $faker->name,
        "participant_email" => $faker->name,
        "ip_addr" => $faker->name,
        "date_recorded" => $faker->date("d/m/Y H:i:s", $max = 'now'),
        "offer_preso_email_status" => $faker->name,
        "offer_email_survey_detail_status" => $faker->name,
        "offer_hub_info_status" => $faker->name,
        "offer_pass_on_email_status" => $faker->name,
        "linked_user_id" => factory('App\User')->create(),
        "created_by_id" => factory('App\User')->create(),
    ];
});
