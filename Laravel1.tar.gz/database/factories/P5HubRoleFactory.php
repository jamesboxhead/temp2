<?php

$factory->define(App\P5HubRole::class, function (Faker\Generator $faker) {
    return [
        "hub_role" => $faker->name,
        "maps_styleurl" => $faker->name,
        "dq" => $faker->name,
    ];
});
