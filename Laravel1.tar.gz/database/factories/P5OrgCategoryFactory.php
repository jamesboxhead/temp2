<?php

$factory->define(App\P5OrgCategory::class, function (Faker\Generator $faker) {
    return [
        "org_category" => $faker->name,
        "sort_code" => $faker->name,
        "notes" => $faker->name,
    ];
});
