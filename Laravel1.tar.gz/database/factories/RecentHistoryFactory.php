<?php

$factory->define(App\RecentHistory::class, function (Faker\Generator $faker) {
    return [

    ];
});
