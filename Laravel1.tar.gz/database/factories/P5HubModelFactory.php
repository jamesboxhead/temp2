<?php

$factory->define(App\P5HubModel::class, function (Faker\Generator $faker) {
    return [
        "hub_model" => $faker->name,
        "sort_code" => $faker->name,
        "dq" => $faker->name,
    ];
});
