<?php

$factory->define(App\P009Graph::class, function (Faker\Generator $faker) {
    return [
        "sort_code" => $faker->name,
        "dataset_title" => $faker->name,
        "graph_root" => $faker->name,
        "graph_name" => $faker->name,
        "graph_description" => $faker->name,
        "created_by_id" => factory('App\User')->create(),
    ];
});
