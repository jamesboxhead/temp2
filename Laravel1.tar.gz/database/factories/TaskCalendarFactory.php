<?php

$factory->define(App\TaskCalendar::class, function (Faker\Generator $faker) {
    return [

    ];
});
