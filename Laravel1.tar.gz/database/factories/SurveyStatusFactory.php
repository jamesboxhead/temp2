<?php

$factory->define(App\SurveyStatus::class, function (Faker\Generator $faker) {
    return [

    ];
});
