<?php

$factory->define(App\P012SurveyLog::class, function (Faker\Generator $faker) {
    return [
        "survey_target_id" => factory('App\User')->create(),
        "p012_survey_code" => $faker->name,
        "ext_survey_code" => $faker->name,
        "p012_survey_status" => $faker->name,
        "ext_survey_status" => $faker->name,
        "linked_task_id" => factory('App\Task')->create(),
        "created_by_id" => factory('App\User')->create(),
    ];
});
