<?php

$factory->define(App\P014SurveyStatus::class, function (Faker\Generator $faker) {
    return [

    ];
});
