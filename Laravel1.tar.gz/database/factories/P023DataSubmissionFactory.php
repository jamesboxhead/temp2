<?php

$factory->define(App\P023DataSubmission::class, function (Faker\Generator $faker) {
    return [
        "submission_code" => $faker->name,
        "linked_p5_hubs_id" => factory('App\P5Hub')->create(),
        "linked_p023_data_standards_id" => factory('App\P023DataStandard')->create(),
        "data_element_as_at" => $faker->date("d/m/Y", $max = 'now'),
        "data_element_x_text" => $faker->name,
        "data_element_x_date" => $faker->date("d/m/Y", $max = 'now'),
        "data_element_x_num" => $faker->randomNumber(2),
        "data_element_x_sort_order" => $faker->name,
        "data_element_y_text" => $faker->name,
        "data_element_y_date" => $faker->date("d/m/Y", $max = 'now'),
        "data_element_y_num" => $faker->randomNumber(2),
        "data_element_label" => $faker->name,
        "created_by_id" => factory('App\User')->create(),
    ];
});
