<?php

$factory->define(App\P023DataStandard::class, function (Faker\Generator $faker) {
    return [
        "data_standard_code" => $faker->name,
        "data_standard_short" => $faker->name,
        "data_standard_fa_icon" => $faker->name,
        "data_standard_notes" => $faker->name,
        "dash_board_title" => $faker->name,
        "dash_board_x_label" => $faker->name,
        "dash_board_y_label" => $faker->name,
        "dash_board_attr1" => $faker->name,
        "dash_board_attr2" => $faker->name,
        "dash_board_attr3" => $faker->name,
        "dash_board_attr4" => $faker->name,
        "dash_board_attr5" => $faker->name,
        "dash_board_notes" => $faker->name,
        "dash_board_short_notes" => $faker->name,
    ];
});
