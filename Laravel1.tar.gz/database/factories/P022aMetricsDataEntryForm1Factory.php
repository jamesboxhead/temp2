<?php

$factory->define(App\P022aMetricsDataEntryForm1::class, function (Faker\Generator $faker) {
    return [

    ];
});
