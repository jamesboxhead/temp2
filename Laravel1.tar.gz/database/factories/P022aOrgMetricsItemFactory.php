<?php

$factory->define(App\P022aOrgMetricsItem::class, function (Faker\Generator $faker) {
    return [
        "metric_description" => $faker->name,
        "metric_display_format" => $faker->name,
        "metric_units" => $faker->name,
        "p022a_org_metric_group_id" => factory('App\P022aOrgMetricsLookupGroup')->create(),
        "notes" => $faker->name,
        "sort_order" => $faker->name,
    ];
});
