<?php

$factory->define(App\P5Program::class, function (Faker\Generator $faker) {
    return [
        "title" => $faker->name,
        "description" => $faker->name,
        "established" => $faker->date("d/m/Y", $max = 'now'),
        "website" => $faker->name,
        "hub_link_id" => factory('App\P5Hub')->create(),
        "created_by_id" => factory('App\User')->create(),
        "dq" => $faker->name,
    ];
});
