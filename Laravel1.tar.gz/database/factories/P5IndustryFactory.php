<?php

$factory->define(App\P5Industry::class, function (Faker\Generator $faker) {
    return [
        "anzsic_lvl1_code" => $faker->name,
        "anzic_description" => $faker->name,
        "notes" => $faker->name,
    ];
});
