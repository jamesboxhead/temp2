<?php

$factory->define(App\P5BusinessModel::class, function (Faker\Generator $faker) {
    return [
        "business_model" => $faker->name,
        "description" => $faker->name,
        "sort_code" => $faker->name,
    ];
});
