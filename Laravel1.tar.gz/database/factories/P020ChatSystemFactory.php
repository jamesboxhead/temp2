<?php

$factory->define(App\P020ChatSystem::class, function (Faker\Generator $faker) {
    return [

    ];
});
