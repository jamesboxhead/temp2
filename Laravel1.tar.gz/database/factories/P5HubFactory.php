<?php

$factory->define(App\P5Hub::class, function (Faker\Generator $faker) {
    return [
        "hub_name" => $faker->name,
        "hub_description" => $faker->name,
        "website" => $faker->name,
        "email" => $faker->safeEmail,
        "state_id" => factory('App\P5State')->create(),
        "hub_model_id" => factory('App\P5HubModel')->create(),
        "public_view" => 1,
        "address_line_1" => $faker->name,
        "address_line_2" => $faker->name,
        "city" => $faker->name,
        "postcode" => $faker->name,
        "wm_id" => $faker->randomNumber(2),
        "created_by_id" => factory('App\User')->create(),
        "dq" => $faker->name,
    ];
});
