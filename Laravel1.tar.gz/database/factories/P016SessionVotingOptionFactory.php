<?php

$factory->define(App\P016SessionVotingOption::class, function (Faker\Generator $faker) {
    return [
        "linked_p016_session_id" => factory('App\P016Session')->create(),
        "option_code" => $faker->name,
        "option_displayed" => $faker->name,
        "option_more_info" => $faker->name,
        "sort_order" => $faker->name,
        "created_by_id" => factory('App\User')->create(),
    ];
});
