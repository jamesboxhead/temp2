<?php

$factory->define(App\P016SessionVotingResult::class, function (Faker\Generator $faker) {
    return [
        "linked_session_id" => factory('App\P016Session')->create(),
        "created_uid" => $faker->name,
        "option_code" => $faker->name,
        "ip_addr" => $faker->name,
        "date_recorded" => $faker->date("d/m/Y H:i:s", $max = 'now'),
        "created_by_id" => factory('App\User')->create(),
    ];
});
