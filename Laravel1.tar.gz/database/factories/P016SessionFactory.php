<?php

$factory->define(App\P016Session::class, function (Faker\Generator $faker) {
    return [
        "linked_p5_hub_id" => factory('App\P5Hub')->create(),
        "linked_session_status_id" => factory('App\P016SessionStatus')->create(),
        "short_description" => $faker->name,
        "session_long_description" => $faker->name,
        "session_pin" => $faker->name,
        "session_start" => $faker->date("d/m/Y H:i:s", $max = 'now'),
        "session_end" => $faker->date("d/m/Y H:i:s", $max = 'now'),
        "session_info" => $faker->name,
        "offer_preso_email" => 0,
        "url_presentation_to_send" => $faker->name,
        "created_by_id" => factory('App\User')->create(),
        "offer_email_survey_detail" => 0,
        "offer_hub_info" => 0,
        "offer_pass_on_email" => 0,
        "offer_voting" => 0,
        "live_results_url" => $faker->name,
        "voting_duration" => $faker->randomNumber(2),
        "voting_headline" => $faker->name,
        "voting_info_presented" => $faker->name,
        "voting_info_mobile" => $faker->name,
    ];
});
