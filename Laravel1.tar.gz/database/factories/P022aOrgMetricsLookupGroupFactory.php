<?php

$factory->define(App\P022aOrgMetricsLookupGroup::class, function (Faker\Generator $faker) {
    return [
        "org_metrics_group" => $faker->name,
        "sort_code" => $faker->name,
    ];
});
