<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Create1518525850P016SessionsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        if(! Schema::hasTable('p016_sessions')) {
            Schema::create('p016_sessions', function (Blueprint $table) {
                $table->increments('id');
                $table->string('short_description')->nullable();
                $table->text('session_long_description')->nullable();
                $table->string('session_pin')->nullable();
                $table->string('url_presentation_to_send')->nullable();
                $table->datetime('session_start')->nullable();
                $table->datetime('session_end')->nullable();
                $table->text('session_info')->nullable();
                $table->string('session_map_location_address')->nullable();
                $table->double('session_map_location_latitude')->nullable();
                $table->double('session_map_location_longitude')->nullable();
                
                $table->timestamps();
                $table->softDeletes();

                $table->index(['deleted_at']);
            });
        }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('p016_sessions');
    }
}
