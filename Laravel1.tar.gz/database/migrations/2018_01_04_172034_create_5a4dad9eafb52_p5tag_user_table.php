<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Create5a4dad9eafb52P5tagUserTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        if(! Schema::hasTable('p5tag_user')) {
            Schema::create('p5tag_user', function (Blueprint $table) {
                $table->integer('p5tag_id')->unsigned()->nullable();
                $table->foreign('p5tag_id', 'fk_p_103331_103170_user_p_5a4dad9eafc8c')->references('id')->on('p5tags')->onDelete('cascade');
                $table->integer('user_id')->unsigned()->nullable();
                $table->foreign('user_id', 'fk_p_103170_103331_p5tag__5a4dad9eafd48')->references('id')->on('users')->onDelete('cascade');
                
            });
        }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('p5tag_user');
    }
}
