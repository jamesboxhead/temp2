<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Add5a7d48e6783d0RelationshipsToP5InvestmentTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('p5_investments', function(Blueprint $table) {
            if (!Schema::hasColumn('p5_investments', 'org_invested_in_id')) {
                $table->integer('org_invested_in_id')->unsigned()->nullable();
                $table->foreign('org_invested_in_id', '103628_5a4de0d7049c8')->references('id')->on('p5_organisations')->onDelete('cascade');
                }
                if (!Schema::hasColumn('p5_investments', 'p5_actual_investment_souce_id')) {
                $table->integer('p5_actual_investment_souce_id')->unsigned()->nullable();
                $table->foreign('p5_actual_investment_souce_id', '103628_5a790304d2a4a')->references('id')->on('p5_investment_sources')->onDelete('cascade');
                }
                if (!Schema::hasColumn('p5_investments', 'investor_org_id')) {
                $table->integer('investor_org_id')->unsigned()->nullable();
                $table->foreign('investor_org_id', '103628_5a7bc70454a4f')->references('id')->on('p5_organisations')->onDelete('cascade');
                }
                if (!Schema::hasColumn('p5_investments', 'investor_individual_id')) {
                $table->integer('investor_individual_id')->unsigned()->nullable();
                $table->foreign('investor_individual_id', '103628_5a7bc70464e81')->references('id')->on('users')->onDelete('cascade');
                }
                if (!Schema::hasColumn('p5_investments', 'created_by_id')) {
                $table->integer('created_by_id')->unsigned()->nullable();
                $table->foreign('created_by_id', '103628_5a4de0d7182c7')->references('id')->on('users')->onDelete('cascade');
                }
                
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('p5_investments', function(Blueprint $table) {
            
        });
    }
}
