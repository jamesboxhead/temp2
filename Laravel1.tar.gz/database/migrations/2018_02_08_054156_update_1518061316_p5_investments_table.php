<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Update1518061316P5InvestmentsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('p5_investments', function (Blueprint $table) {
            if(Schema::hasColumn('p5_investments', 'investor_hub_id')) {
                $table->dropForeign('103628_5a4de0d70e53d');
                $table->dropIndex('103628_5a4de0d70e53d');
                $table->dropColumn('investor_hub_id');
            }
            
        });
Schema::table('p5_investments', function (Blueprint $table) {
            
if (!Schema::hasColumn('p5_investments', 'inverstor_entity_type')) {
                $table->enum('inverstor_entity_type', array('Incorporated', 'Individual'))->nullable();
                }
        });

    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('p5_investments', function (Blueprint $table) {
            $table->dropColumn('inverstor_entity_type');
            
        });
Schema::table('p5_investments', function (Blueprint $table) {
                        
        });

    }
}
