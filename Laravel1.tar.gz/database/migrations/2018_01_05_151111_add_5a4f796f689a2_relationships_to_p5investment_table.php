<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Add5a4f796f689a2RelationshipsToP5InvestmentTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('p5_investments', function(Blueprint $table) {
            if (!Schema::hasColumn('p5_investments', 'org_invested_in_id')) {
                $table->integer('org_invested_in_id')->unsigned()->nullable();
                $table->foreign('org_invested_in_id', '103628_5a4de0d7049c8')->references('id')->on('p5_organisations')->onDelete('cascade');
                }
                if (!Schema::hasColumn('p5_investments', 'investor_hub_id')) {
                $table->integer('investor_hub_id')->unsigned()->nullable();
                $table->foreign('investor_hub_id', '103628_5a4de0d70e53d')->references('id')->on('p5_hubs')->onDelete('cascade');
                }
                if (!Schema::hasColumn('p5_investments', 'created_by_id')) {
                $table->integer('created_by_id')->unsigned()->nullable();
                $table->foreign('created_by_id', '103628_5a4de0d7182c7')->references('id')->on('users')->onDelete('cascade');
                }
                
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('p5_investments', function(Blueprint $table) {
            
        });
    }
}
