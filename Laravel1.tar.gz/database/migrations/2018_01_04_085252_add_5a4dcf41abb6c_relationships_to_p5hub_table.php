<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Add5a4dcf41abb6cRelationshipsToP5HubTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('p5_hubs', function(Blueprint $table) {
            if (!Schema::hasColumn('p5_hubs', 'state_id')) {
                $table->integer('state_id')->unsigned()->nullable();
                $table->foreign('state_id', '103569_5a4dbad5181b3')->references('id')->on('p5_states')->onDelete('cascade');
                }
                if (!Schema::hasColumn('p5_hubs', 'hub_model_id')) {
                $table->integer('hub_model_id')->unsigned()->nullable();
                $table->foreign('hub_model_id', '103569_5a4dc4371f123')->references('id')->on('p5_hub_models')->onDelete('cascade');
                }
                if (!Schema::hasColumn('p5_hubs', 'created_by_id')) {
                $table->integer('created_by_id')->unsigned()->nullable();
                $table->foreign('created_by_id', '103569_5a4dbad51e586')->references('id')->on('users')->onDelete('cascade');
                }
                
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('p5_hubs', function(Blueprint $table) {
            
        });
    }
}
