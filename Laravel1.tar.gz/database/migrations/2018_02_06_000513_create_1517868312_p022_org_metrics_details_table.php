<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Create1517868312P022OrgMetricsDetailsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        if(! Schema::hasTable('p022_org_metrics_details')) {
            Schema::create('p022_org_metrics_details', function (Blueprint $table) {
                $table->increments('id');
                $table->date('result_as_at')->nullable();
                $table->string('p022_result_raw')->nullable();
                $table->string('result_source')->nullable();
                $table->text('result_notes')->nullable();
                $table->string('p022_result_validation_status')->nullable();
                $table->integer('p022_result_value')->nullable();
                
                $table->timestamps();
                $table->softDeletes();

                $table->index(['deleted_at']);
            });
        }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('p022_org_metrics_details');
    }
}
