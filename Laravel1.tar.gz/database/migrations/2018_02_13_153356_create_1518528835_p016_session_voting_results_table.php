<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Create1518528835P016SessionVotingResultsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        if(! Schema::hasTable('p016_session_voting_results')) {
            Schema::create('p016_session_voting_results', function (Blueprint $table) {
                $table->increments('id');
                $table->string('created_uid')->nullable();
                $table->string('option_code')->nullable();
                $table->string('ip_addr')->nullable();
                $table->datetime('date_recorded')->nullable();
                
                $table->timestamps();
                $table->softDeletes();

                $table->index(['deleted_at']);
            });
        }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('p016_session_voting_results');
    }
}
