<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Drop5a78458de8dd75a78458de6ff8P5HubP5OrganisationTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::dropIfExists('p5_hub_p5_organisation');
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        if(! Schema::hasTable('p5_hub_p5_organisation')) {
            Schema::create('p5_hub_p5_organisation', function (Blueprint $table) {
                $table->increments('id');
                $table->integer('p5_hub_id')->unsigned()->nullable();
            $table->foreign('p5_hub_id', 'fk_p_103569_103591_p5orga_5a4dcf8a74cab')->references('id')->on('p5_hubs');
                $table->integer('p5_organisation_id')->unsigned()->nullable();
            $table->foreign('p5_organisation_id', 'fk_p_103591_103569_p5hub__5a4dcf8a758fb')->references('id')->on('p5_organisations');
                
                $table->timestamps();
                $table->softDeletes();
            });
        }
    }
}
