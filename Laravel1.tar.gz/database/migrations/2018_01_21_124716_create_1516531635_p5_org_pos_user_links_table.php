<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Create1516531635P5OrgPosUserLinksTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        if(! Schema::hasTable('p5_org_pos_user_links')) {
            Schema::create('p5_org_pos_user_links', function (Blueprint $table) {
                $table->increments('id');
                $table->tinyInteger('relationship_is_current')->nullable()->default(1);
                $table->date('relationship_started')->nullable();
                $table->date('relationship_ended')->nullable();
                
                $table->timestamps();
                
            });
        }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('p5_org_pos_user_links');
    }
}
