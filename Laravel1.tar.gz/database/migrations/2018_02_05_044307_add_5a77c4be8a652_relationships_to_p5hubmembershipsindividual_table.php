<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Add5a77c4be8a652RelationshipsToP5HubMembershipsIndividualTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('p5_hub_memberships_individuals', function(Blueprint $table) {
            if (!Schema::hasColumn('p5_hub_memberships_individuals', 'hub_id')) {
                $table->integer('hub_id')->unsigned()->nullable();
                $table->foreign('hub_id', '114640_5a77c4bc1916e')->references('id')->on('p5_hubs')->onDelete('cascade');
                }
                if (!Schema::hasColumn('p5_hub_memberships_individuals', 'individual_id')) {
                $table->integer('individual_id')->unsigned()->nullable();
                $table->foreign('individual_id', '114640_5a77c4bc38b36')->references('id')->on('users')->onDelete('cascade');
                }
                if (!Schema::hasColumn('p5_hub_memberships_individuals', 'member_type_id')) {
                $table->integer('member_type_id')->unsigned()->nullable();
                $table->foreign('member_type_id', '114640_5a77c4bc583a1')->references('id')->on('p5_hub_membership_types')->onDelete('cascade');
                }
                
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('p5_hub_memberships_individuals', function(Blueprint $table) {
            
        });
    }
}
