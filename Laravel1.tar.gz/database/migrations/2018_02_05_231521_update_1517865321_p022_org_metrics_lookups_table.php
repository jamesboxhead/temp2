<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Update1517865321P022OrgMetricsLookupsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('p022_org_metrics_lookups', function (Blueprint $table) {
            
if (!Schema::hasColumn('p022_org_metrics_lookups', 'notes')) {
                $table->text('notes')->nullable();
                }
        });

    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('p022_org_metrics_lookups', function (Blueprint $table) {
            $table->dropColumn('notes');
            
        });

    }
}
