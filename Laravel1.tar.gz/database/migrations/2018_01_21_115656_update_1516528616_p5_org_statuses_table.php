<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Update1516528616P5OrgStatusesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('p5_org_statuses', function (Blueprint $table) {
            if(Schema::hasColumn('p5_org_statuses', 'created_by_id')) {
                $table->dropForeign('103578_5a4dc03fabe8a');
                $table->dropIndex('103578_5a4dc03fabe8a');
                $table->dropColumn('created_by_id');
            }
            
        });

    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('p5_org_statuses', function (Blueprint $table) {
                        
        });

    }
}
