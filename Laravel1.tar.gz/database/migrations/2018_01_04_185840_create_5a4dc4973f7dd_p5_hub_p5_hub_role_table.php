<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Create5a4dc4973f7ddP5HubP5HubRoleTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        if(! Schema::hasTable('p5_hub_p5_hub_role')) {
            Schema::create('p5_hub_p5_hub_role', function (Blueprint $table) {
                $table->integer('p5_hub_id')->unsigned()->nullable();
                $table->foreign('p5_hub_id', 'fk_p_103569_103565_p5hubr_5a4dc4973f8c8')->references('id')->on('p5_hubs')->onDelete('cascade');
                $table->integer('p5_hub_role_id')->unsigned()->nullable();
                $table->foreign('p5_hub_role_id', 'fk_p_103565_103569_p5hub__5a4dc4973f95c')->references('id')->on('p5_hub_roles')->onDelete('cascade');
                
            });
        }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('p5_hub_p5_hub_role');
    }
}
