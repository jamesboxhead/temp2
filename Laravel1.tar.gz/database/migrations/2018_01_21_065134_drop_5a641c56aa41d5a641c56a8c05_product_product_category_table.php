<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Drop5a641c56aa41d5a641c56a8c05ProductProductCategoryTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::dropIfExists('product_product_category');
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        if(! Schema::hasTable('product_product_category')) {
            Schema::create('product_product_category', function (Blueprint $table) {
                $table->increments('id');
                $table->integer('product_id')->unsigned()->nullable();
            $table->foreign('product_id', 'fk_p_103188_103186_produc_5a4c852369ddd')->references('id')->on('products');
                $table->integer('product_category_id')->unsigned()->nullable();
            $table->foreign('product_category_id', 'fk_p_103186_103188_produc_5a4c8523694e8')->references('id')->on('product_categories');
                
                $table->timestamps();
                
            });
        }
    }
}
