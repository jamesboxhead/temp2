<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Add5a76608752f33RelationshipsToTaskTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('tasks', function(Blueprint $table) {
            if (!Schema::hasColumn('tasks', 'user_id')) {
                $table->integer('user_id')->unsigned()->nullable();
                $table->foreign('user_id', '103192_5a4c8532d4b21')->references('id')->on('users')->onDelete('cascade');
                }
                if (!Schema::hasColumn('tasks', 'mentor_id')) {
                $table->integer('mentor_id')->unsigned()->nullable();
                $table->foreign('mentor_id', '103192_5a647c34d36fa')->references('id')->on('users')->onDelete('cascade');
                }
                if (!Schema::hasColumn('tasks', 'status_id')) {
                $table->integer('status_id')->unsigned()->nullable();
                $table->foreign('status_id', '103192_5a4c8532cd2ef')->references('id')->on('task_statuses')->onDelete('cascade');
                }
                if (!Schema::hasColumn('tasks', 'outcome_id')) {
                $table->integer('outcome_id')->unsigned()->nullable();
                $table->foreign('outcome_id', '103192_5a67335269fad')->references('id')->on('tasks_outcomes')->onDelete('cascade');
                }
                if (!Schema::hasColumn('tasks', 'created_by_id')) {
                $table->integer('created_by_id')->unsigned()->nullable();
                $table->foreign('created_by_id', '103192_5a647afd0efc9')->references('id')->on('users')->onDelete('cascade');
                }
                
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('tasks', function(Blueprint $table) {
            
        });
    }
}
