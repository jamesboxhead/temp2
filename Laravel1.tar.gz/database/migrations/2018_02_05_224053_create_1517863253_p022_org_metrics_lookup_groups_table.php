<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Create1517863253P022OrgMetricsLookupGroupsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        if(! Schema::hasTable('p022_org_metrics_lookup_groups')) {
            Schema::create('p022_org_metrics_lookup_groups', function (Blueprint $table) {
                $table->increments('id');
                $table->string('org_metrics_group')->nullable();
                $table->string('sort_code')->nullable();
                
                $table->timestamps();
                $table->softDeletes();

                $table->index(['deleted_at']);
            });
        }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('p022_org_metrics_lookup_groups');
    }
}
