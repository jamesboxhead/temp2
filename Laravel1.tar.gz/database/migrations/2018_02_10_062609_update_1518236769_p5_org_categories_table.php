<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Update1518236769P5OrgCategoriesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('p5_org_categories', function (Blueprint $table) {
            
if (!Schema::hasColumn('p5_org_categories', 'notes')) {
                $table->text('notes')->nullable();
                }
        });

    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('p5_org_categories', function (Blueprint $table) {
            $table->dropColumn('notes');
            
        });

    }
}
