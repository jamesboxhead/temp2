<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Add5a4dba3c025eaRelationshipsToP5Hubs1Table extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('p5_hubs1s', function(Blueprint $table) {
            if (!Schema::hasColumn('p5_hubs1s', 'state_id')) {
                $table->integer('state_id')->unsigned()->nullable();
                $table->foreign('state_id', '103568_5a4dba39be50a')->references('id')->on('p5states')->onDelete('cascade');
                }
                if (!Schema::hasColumn('p5_hubs1s', 'created_by_id')) {
                $table->integer('created_by_id')->unsigned()->nullable();
                $table->foreign('created_by_id', '103568_5a4dba39c796d')->references('id')->on('users')->onDelete('cascade');
                }
                
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('p5_hubs1s', function(Blueprint $table) {
            
        });
    }
}
