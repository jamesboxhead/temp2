<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Create5a78bf87a11eaP21OrgMetricsLookupP21OrgMetricsLookupGroupTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        if(! Schema::hasTable('p21_org_metrics_lookup_p21_org_metrics_lookup_group')) {
            Schema::create('p21_org_metrics_lookup_p21_org_metrics_lookup_group', function (Blueprint $table) {
                $table->integer('p21_org_metrics_lookup_id')->unsigned()->nullable();
                $table->foreign('p21_org_metrics_lookup_id', 'fk_p_114888_114889_p21org_5a78bf87a1314')->references('id')->on('p21_org_metrics_lookups')->onDelete('cascade');
                $table->integer('p21_org_metrics_lookup_group_id')->unsigned()->nullable();
                $table->foreign('p21_org_metrics_lookup_group_id', 'fk_p_114889_114888_p21org_5a78bf87a13aa')->references('id')->on('p21_org_metrics_lookup_groups')->onDelete('cascade');
                
            });
        }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('p21_org_metrics_lookup_p21_org_metrics_lookup_group');
    }
}
