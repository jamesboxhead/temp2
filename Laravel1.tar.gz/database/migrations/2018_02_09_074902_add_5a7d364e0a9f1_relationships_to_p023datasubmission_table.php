<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Add5a7d364e0a9f1RelationshipsToP023DataSubmissionTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('p023_data_submissions', function(Blueprint $table) {
            if (!Schema::hasColumn('p023_data_submissions', 'linked_p5_hubs_id')) {
                $table->integer('linked_p5_hubs_id')->unsigned()->nullable();
                $table->foreign('linked_p5_hubs_id', '115176_5a798d1c17534')->references('id')->on('p5_hubs')->onDelete('cascade');
                }
                if (!Schema::hasColumn('p023_data_submissions', 'linked_p023_data_standards_id')) {
                $table->integer('linked_p023_data_standards_id')->unsigned()->nullable();
                $table->foreign('linked_p023_data_standards_id', '115176_5a79890495f1b')->references('id')->on('p023_data_standards')->onDelete('cascade');
                }
                if (!Schema::hasColumn('p023_data_submissions', 'created_by_id')) {
                $table->integer('created_by_id')->unsigned()->nullable();
                $table->foreign('created_by_id', '115176_5a798904aa721')->references('id')->on('users')->onDelete('cascade');
                }
                
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('p023_data_submissions', function(Blueprint $table) {
            
        });
    }
}
