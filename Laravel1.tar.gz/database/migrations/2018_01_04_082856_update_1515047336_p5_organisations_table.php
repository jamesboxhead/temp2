<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Update1515047336P5OrganisationsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('p5_organisations', function (Blueprint $table) {
            if(Schema::hasColumn('p5_organisations', 'org_status')) {
                $table->dropColumn('org_status');
            }
            
        });

    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('p5_organisations', function (Blueprint $table) {
                        $table->string('org_status')->nullable();
                
        });

    }
}
