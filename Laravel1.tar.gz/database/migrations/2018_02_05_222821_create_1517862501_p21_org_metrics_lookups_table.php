<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Create1517862501P21OrgMetricsLookupsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        if(! Schema::hasTable('p21_org_metrics_lookups')) {
            Schema::create('p21_org_metrics_lookups', function (Blueprint $table) {
                $table->increments('id');
                $table->string('metric_description')->nullable();
                $table->string('metric_display_format')->nullable();
                $table->string('metric_units')->nullable();
                $table->string('sort_order')->nullable();
                
                $table->timestamps();
                $table->softDeletes();

                $table->index(['deleted_at']);
            });
        }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('p21_org_metrics_lookups');
    }
}
