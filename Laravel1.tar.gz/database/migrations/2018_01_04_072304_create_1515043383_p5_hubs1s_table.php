<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Create1515043383P5Hubs1sTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        if(! Schema::hasTable('p5_hubs1s')) {
            Schema::create('p5_hubs1s', function (Blueprint $table) {
                $table->increments('id');
                $table->string('hub_name')->nullable();
                $table->text('hub_description')->nullable();
                $table->string('website')->nullable();
                $table->string('email')->nullable();
                $table->string('logo')->nullable();
                $table->string('address_line_1')->nullable();
                $table->string('address_line_2')->nullable();
                $table->string('city')->nullable();
                $table->string('postcode')->nullable();
                $table->string('map_location_address');
                $table->double('map_location_latitude');
                $table->double('map_location_longitude');
                $table->string('map_stuleurl');
                $table->integer('wm_id')->nullable()->unsigned();
                
                $table->timestamps();
                $table->softDeletes();

                $table->index(['deleted_at']);
            });
        }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('p5_hubs1s');
    }
}
