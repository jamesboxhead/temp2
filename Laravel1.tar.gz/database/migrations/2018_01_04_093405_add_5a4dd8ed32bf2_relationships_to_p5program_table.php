<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Add5a4dd8ed32bf2RelationshipsToP5ProgramTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('p5_programs', function(Blueprint $table) {
            if (!Schema::hasColumn('p5_programs', 'hub_link_id')) {
                $table->integer('hub_link_id')->unsigned()->nullable();
                $table->foreign('hub_link_id', '103614_5a4dd7d473206')->references('id')->on('p5_hubs')->onDelete('cascade');
                }
                if (!Schema::hasColumn('p5_programs', 'created_by_id')) {
                $table->integer('created_by_id')->unsigned()->nullable();
                $table->foreign('created_by_id', '103614_5a4dd7d486923')->references('id')->on('users')->onDelete('cascade');
                }
                
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('p5_programs', function(Blueprint $table) {
            
        });
    }
}
