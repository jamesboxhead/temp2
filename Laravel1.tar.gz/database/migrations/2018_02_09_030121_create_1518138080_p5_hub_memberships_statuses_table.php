<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Create1518138080P5HubMembershipsStatusesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        if(! Schema::hasTable('p5_hub_memberships_statuses')) {
            Schema::create('p5_hub_memberships_statuses', function (Blueprint $table) {
                $table->increments('id');
                $table->string('status_code')->nullable();
                $table->string('status')->nullable();
                $table->string('status_notes')->nullable();
                $table->string('dq')->nullable();
                
                $table->timestamps();
                $table->softDeletes();

                $table->index(['deleted_at']);
            });
        }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('p5_hub_memberships_statuses');
    }
}
