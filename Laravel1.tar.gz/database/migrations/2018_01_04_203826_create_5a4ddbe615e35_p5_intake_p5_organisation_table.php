<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Create5a4ddbe615e35P5IntakeP5OrganisationTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        if(! Schema::hasTable('p5_intake_p5_organisation')) {
            Schema::create('p5_intake_p5_organisation', function (Blueprint $table) {
                $table->integer('p5_intake_id')->unsigned()->nullable();
                $table->foreign('p5_intake_id', 'fk_p_103617_103591_p5orga_5a4ddbe615f90')->references('id')->on('p5_intakes')->onDelete('cascade');
                $table->integer('p5_organisation_id')->unsigned()->nullable();
                $table->foreign('p5_organisation_id', 'fk_p_103591_103617_p5inta_5a4ddbe616061')->references('id')->on('p5_organisations')->onDelete('cascade');
                
            });
        }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('p5_intake_p5_organisation');
    }
}
