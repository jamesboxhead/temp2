<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Update1517381217P5ProgramsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('p5_programs', function (Blueprint $table) {
            if(Schema::hasColumn('p5_programs', 'created_by_id')) {
                $table->dropForeign('103614_5a4dd7d486923');
                $table->dropIndex('103614_5a4dd7d486923');
                $table->dropColumn('created_by_id');
            }
            
        });

    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('p5_programs', function (Blueprint $table) {
                        
        });

    }
}
