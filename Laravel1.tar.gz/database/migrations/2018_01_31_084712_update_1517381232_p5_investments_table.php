<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Update1517381232P5InvestmentsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('p5_investments', function (Blueprint $table) {
            if(Schema::hasColumn('p5_investments', 'created_by_id')) {
                $table->dropForeign('103628_5a4de0d7182c7');
                $table->dropIndex('103628_5a4de0d7182c7');
                $table->dropColumn('created_by_id');
            }
            
        });

    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('p5_investments', function (Blueprint $table) {
                        
        });

    }
}
