<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Update1517441651P5TagsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('p5_tags', function (Blueprint $table) {
            
if (!Schema::hasColumn('p5_tags', 'dq')) {
                $table->string('dq')->nullable();
                }
        });

    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('p5_tags', function (Blueprint $table) {
            $table->dropColumn('dq');
            
        });

    }
}
