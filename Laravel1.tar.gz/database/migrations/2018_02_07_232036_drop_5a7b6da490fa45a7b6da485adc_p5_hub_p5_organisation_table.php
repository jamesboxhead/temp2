<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Drop5a7b6da490fa45a7b6da485adcP5HubP5OrganisationTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::dropIfExists('p5_hub_p5_organisation');
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        if(! Schema::hasTable('p5_hub_p5_organisation')) {
            Schema::create('p5_hub_p5_organisation', function (Blueprint $table) {
                $table->increments('id');
                $table->integer('p5_hub_id')->unsigned()->nullable();
            $table->foreign('p5_hub_id', 'fk_103569_p5hub_p5organisation_id')->references('id')->on('p5_hubs');
                $table->integer('p5_organisation_id')->unsigned()->nullable();
            $table->foreign('p5_organisation_id', 'fk_103591_p5organisation_p5hub_id')->references('id')->on('p5_organisations');
                
                $table->timestamps();
                $table->softDeletes();
            });
        }
    }
}
