<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Drop5a78d87079c43P022OrgMetricsLookupGroupsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::dropIfExists('p022_org_metrics_lookup_groups');
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        if(! Schema::hasTable('p022_org_metrics_lookup_groups')) {
            Schema::create('p022_org_metrics_lookup_groups', function (Blueprint $table) {
                $table->increments('id');
                $table->string('org_metrics_group')->nullable();
                $table->string('sort_code')->nullable();
                
                $table->timestamps();
                $table->softDeletes();

            $table->index(['deleted_at']);
            });
        }
    }
}
