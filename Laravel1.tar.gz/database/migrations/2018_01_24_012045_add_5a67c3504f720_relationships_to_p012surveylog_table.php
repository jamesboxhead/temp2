<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Add5a67c3504f720RelationshipsToP012SurveyLogTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('p012_survey_logs', function(Blueprint $table) {
            if (!Schema::hasColumn('p012_survey_logs', 'survey_target_id')) {
                $table->integer('survey_target_id')->unsigned()->nullable();
                $table->foreign('survey_target_id', '110529_5a67c34ddada9')->references('id')->on('users')->onDelete('cascade');
                }
                if (!Schema::hasColumn('p012_survey_logs', 'linked_task_id')) {
                $table->integer('linked_task_id')->unsigned()->nullable();
                $table->foreign('linked_task_id', '110529_5a67c34de7c19')->references('id')->on('tasks')->onDelete('cascade');
                }
                if (!Schema::hasColumn('p012_survey_logs', 'created_by_id')) {
                $table->integer('created_by_id')->unsigned()->nullable();
                $table->foreign('created_by_id', '110529_5a67c34df2fc1')->references('id')->on('users')->onDelete('cascade');
                }
                
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('p012_survey_logs', function(Blueprint $table) {
            
        });
    }
}
