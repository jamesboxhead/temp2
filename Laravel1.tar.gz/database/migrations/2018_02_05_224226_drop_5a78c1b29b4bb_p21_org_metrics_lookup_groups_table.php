<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Drop5a78c1b29b4bbP21OrgMetricsLookupGroupsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::dropIfExists('p21_org_metrics_lookup_groups');
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        if(! Schema::hasTable('p21_org_metrics_lookup_groups')) {
            Schema::create('p21_org_metrics_lookup_groups', function (Blueprint $table) {
                $table->increments('id');
                $table->string('org_metrics_group')->nullable();
                $table->string('sort_code')->nullable();
                
                $table->timestamps();
                $table->softDeletes();

            $table->index(['deleted_at']);
            });
        }
    }
}
