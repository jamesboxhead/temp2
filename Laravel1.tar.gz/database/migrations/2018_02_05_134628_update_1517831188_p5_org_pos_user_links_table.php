<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Update1517831188P5OrgPosUserLinksTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('p5_org_pos_user_links', function (Blueprint $table) {
            if(! Schema::hasColumn('p5_org_pos_user_links', 'deleted_at')) {
                $table->softDeletes();
            }
            
        });

    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('p5_org_pos_user_links', function (Blueprint $table) {
            if(Schema::hasColumn('p5_org_pos_user_links', 'deleted_at')) {
                $table->dropColumn('deleted_at');
            }
            
        });

    }
}
