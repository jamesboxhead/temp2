<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Add5a72504409149RelationshipsToP5HubMembershipTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('p5_hub_memberships', function(Blueprint $table) {
            if (!Schema::hasColumn('p5_hub_memberships', 'hub_id')) {
                $table->integer('hub_id')->unsigned()->nullable();
                $table->foreign('hub_id', '112081_5a6d7db0d515b')->references('id')->on('p5_hubs')->onDelete('cascade');
                }
                if (!Schema::hasColumn('p5_hub_memberships', 'organisation_id')) {
                $table->integer('organisation_id')->unsigned()->nullable();
                $table->foreign('organisation_id', '112081_5a6d7db0e1b7a')->references('id')->on('p5_organisations')->onDelete('cascade');
                }
                if (!Schema::hasColumn('p5_hub_memberships', 'member_type_id')) {
                $table->integer('member_type_id')->unsigned()->nullable();
                $table->foreign('member_type_id', '112081_5a6da023cb09b')->references('id')->on('p5_hub_membership_types')->onDelete('cascade');
                }
                if (!Schema::hasColumn('p5_hub_memberships', 'created_by_id')) {
                $table->integer('created_by_id')->unsigned()->nullable();
                $table->foreign('created_by_id', '112081_5a6d7db0ed521')->references('id')->on('users')->onDelete('cascade');
                }
                
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('p5_hub_memberships', function(Blueprint $table) {
            
        });
    }
}
