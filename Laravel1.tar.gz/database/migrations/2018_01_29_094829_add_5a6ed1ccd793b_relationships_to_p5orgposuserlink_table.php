<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Add5a6ed1ccd793bRelationshipsToP5OrgPosUserLinkTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('p5_org_pos_user_links', function(Blueprint $table) {
            if (!Schema::hasColumn('p5_org_pos_user_links', 'username_id')) {
                $table->integer('username_id')->unsigned()->nullable();
                $table->foreign('username_id', '109703_5a646fb560f0f')->references('id')->on('users')->onDelete('cascade');
                }
                if (!Schema::hasColumn('p5_org_pos_user_links', 'org_link_id')) {
                $table->integer('org_link_id')->unsigned()->nullable();
                $table->foreign('org_link_id', '109703_5a646fb56a336')->references('id')->on('p5_organisations')->onDelete('cascade');
                }
                if (!Schema::hasColumn('p5_org_pos_user_links', 'org_relationship_id')) {
                $table->integer('org_relationship_id')->unsigned()->nullable();
                $table->foreign('org_relationship_id', '109703_5a646fb5737c2')->references('id')->on('p5_positions')->onDelete('cascade');
                }
                if (!Schema::hasColumn('p5_org_pos_user_links', 'created_by_id')) {
                $table->integer('created_by_id')->unsigned()->nullable();
                $table->foreign('created_by_id', '109703_5a646fb57bf3f')->references('id')->on('users')->onDelete('cascade');
                }
                
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('p5_org_pos_user_links', function(Blueprint $table) {
            
        });
    }
}
