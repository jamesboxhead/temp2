<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Add5a82dd9e83b1dRelationshipsToP016SessionTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('p016_sessions', function(Blueprint $table) {
            if (!Schema::hasColumn('p016_sessions', 'linked_p5_hub_id')) {
                $table->integer('linked_p5_hub_id')->unsigned()->nullable();
                $table->foreign('linked_p5_hub_id', '118540_5a82dd9c9be2b')->references('id')->on('p5_hubs')->onDelete('cascade');
                }
                if (!Schema::hasColumn('p016_sessions', 'created_by_id')) {
                $table->integer('created_by_id')->unsigned()->nullable();
                $table->foreign('created_by_id', '118540_5a82dd9cb1598')->references('id')->on('users')->onDelete('cascade');
                }
                
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('p016_sessions', function(Blueprint $table) {
            
        });
    }
}
