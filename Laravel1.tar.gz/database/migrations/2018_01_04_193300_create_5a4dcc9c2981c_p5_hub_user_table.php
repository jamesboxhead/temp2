<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Create5a4dcc9c2981cP5HubUserTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        if(! Schema::hasTable('p5_hub_user')) {
            Schema::create('p5_hub_user', function (Blueprint $table) {
                $table->integer('p5_hub_id')->unsigned()->nullable();
                $table->foreign('p5_hub_id', 'fk_p_103569_103170_user_p_5a4dcc9c298fb')->references('id')->on('p5_hubs')->onDelete('cascade');
                $table->integer('user_id')->unsigned()->nullable();
                $table->foreign('user_id', 'fk_p_103170_103569_p5hub__5a4dcc9c29978')->references('id')->on('users')->onDelete('cascade');
                
            });
        }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('p5_hub_user');
    }
}
