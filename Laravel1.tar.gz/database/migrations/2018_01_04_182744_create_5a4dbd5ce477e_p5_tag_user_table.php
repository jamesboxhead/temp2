<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Create5a4dbd5ce477eP5TagUserTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        if(! Schema::hasTable('p5_tag_user')) {
            Schema::create('p5_tag_user', function (Blueprint $table) {
                $table->integer('p5_tag_id')->unsigned()->nullable();
                $table->foreign('p5_tag_id', 'fk_p_103573_103170_user_p_5a4dbd5ce4869')->references('id')->on('p5_tags')->onDelete('cascade');
                $table->integer('user_id')->unsigned()->nullable();
                $table->foreign('user_id', 'fk_p_103170_103573_p5tag__5a4dbd5ce48e7')->references('id')->on('users')->onDelete('cascade');
                
            });
        }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('p5_tag_user');
    }
}
