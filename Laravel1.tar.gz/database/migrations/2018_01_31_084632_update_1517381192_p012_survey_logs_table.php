<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Update1517381192P012SurveyLogsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('p012_survey_logs', function (Blueprint $table) {
            if(Schema::hasColumn('p012_survey_logs', 'created_by_id')) {
                $table->dropForeign('110529_5a67c34df2fc1');
                $table->dropIndex('110529_5a67c34df2fc1');
                $table->dropColumn('created_by_id');
            }
            
        });

    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('p012_survey_logs', function (Blueprint $table) {
                        
        });

    }
}
