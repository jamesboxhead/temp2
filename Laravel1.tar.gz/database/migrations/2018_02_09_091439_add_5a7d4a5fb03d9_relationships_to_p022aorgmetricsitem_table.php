<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Add5a7d4a5fb03d9RelationshipsToP022aOrgMetricsItemTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('p022a_org_metrics_items', function(Blueprint $table) {
            if (!Schema::hasColumn('p022a_org_metrics_items', 'p022a_org_metric_group_id')) {
                $table->integer('p022a_org_metric_group_id')->unsigned()->nullable();
                $table->foreign('p022a_org_metric_group_id', '114905_5a78da3ecfdd9')->references('id')->on('p022a_org_metrics_lookup_groups')->onDelete('cascade');
                }
                
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('p022a_org_metrics_items', function(Blueprint $table) {
            
        });
    }
}
