<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Add5a7d31636edf9RelationshipsToP5IntakeTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('p5_intakes', function(Blueprint $table) {
            if (!Schema::hasColumn('p5_intakes', 'program_id')) {
                $table->integer('program_id')->unsigned()->nullable();
                $table->foreign('program_id', '103617_5a4ddb5bdbcfc')->references('id')->on('p5_programs')->onDelete('cascade');
                }
                if (!Schema::hasColumn('p5_intakes', 'created_by_id')) {
                $table->integer('created_by_id')->unsigned()->nullable();
                $table->foreign('created_by_id', '103617_5a4ddb5be5aa3')->references('id')->on('users')->onDelete('cascade');
                }
                
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('p5_intakes', function(Blueprint $table) {
            
        });
    }
}
