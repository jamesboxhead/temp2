<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Add5a4c8ebaac6f7RelationshipsToP5hubTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('p5hubs', function(Blueprint $table) {
            if (!Schema::hasColumn('p5hubs', 'state_id')) {
                $table->integer('state_id')->unsigned()->nullable();
                $table->foreign('state_id', '103224_5a4c8e3a5273d')->references('id')->on('p5states')->onDelete('cascade');
                }
                if (!Schema::hasColumn('p5hubs', 'created_by_id')) {
                $table->integer('created_by_id')->unsigned()->nullable();
                $table->foreign('created_by_id', '103224_5a4c8e3a5c709')->references('id')->on('users')->onDelete('cascade');
                }
                
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('p5hubs', function(Blueprint $table) {
            
        });
    }
}
