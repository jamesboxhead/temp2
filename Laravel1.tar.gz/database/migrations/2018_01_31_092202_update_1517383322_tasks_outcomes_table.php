<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Update1517383322TasksOutcomesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('tasks_outcomes', function (Blueprint $table) {
            if(! Schema::hasColumn('tasks_outcomes', 'deleted_at')) {
                $table->softDeletes();
            }
            
        });

    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('tasks_outcomes', function (Blueprint $table) {
            if(Schema::hasColumn('tasks_outcomes', 'deleted_at')) {
                $table->dropColumn('deleted_at');
            }
            
        });

    }
}
