<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Create1515053269P5InvestmentsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        if(! Schema::hasTable('p5_investments')) {
            Schema::create('p5_investments', function (Blueprint $table) {
                $table->increments('id');
                $table->date('date_of_investment')->nullable();
                $table->decimal('amnt_of_investment', 15, 2)->nullable();
                $table->string('investment_currency')->nullable();
                
                $table->timestamps();
                $table->softDeletes();

                $table->index(['deleted_at']);
            });
        }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('p5_investments');
    }
}
