<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Update1518138893P5HubMembershipsClassesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('p5_hub_memberships_classes', function (Blueprint $table) {
            
if (!Schema::hasColumn('p5_hub_memberships_classes', 'notes')) {
                $table->string('notes')->nullable();
                }
        });

    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('p5_hub_memberships_classes', function (Blueprint $table) {
            $table->dropColumn('notes');
            
        });

    }
}
