<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Create5a4ddcd29e038P5IntakeUserTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        if(! Schema::hasTable('p5_intake_user')) {
            Schema::create('p5_intake_user', function (Blueprint $table) {
                $table->integer('p5_intake_id')->unsigned()->nullable();
                $table->foreign('p5_intake_id', 'fk_p_103617_103170_user_p_5a4ddcd29e10f')->references('id')->on('p5_intakes')->onDelete('cascade');
                $table->integer('user_id')->unsigned()->nullable();
                $table->foreign('user_id', 'fk_p_103170_103617_p5inta_5a4ddcd29e18d')->references('id')->on('users')->onDelete('cascade');
                
            });
        }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('p5_intake_user');
    }
}
