<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Add5a78c62f417e6RelationshipsToP022OrgMetricsDatumTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('p022_org_metrics_datas', function(Blueprint $table) {
            if (!Schema::hasColumn('p022_org_metrics_datas', 'p5_organisations_id')) {
                $table->integer('p5_organisations_id')->unsigned()->nullable();
                $table->foreign('p5_organisations_id', '114896_5a78c57fbe64b')->references('id')->on('p5_organisations')->onDelete('cascade');
                }
                if (!Schema::hasColumn('p022_org_metrics_datas', 'p022_org_metrics_lookup_id')) {
                $table->integer('p022_org_metrics_lookup_id')->unsigned()->nullable();
                $table->foreign('p022_org_metrics_lookup_id', '114896_5a78c57fd4116')->references('id')->on('p022_org_metrics_lookups')->onDelete('cascade');
                }
                if (!Schema::hasColumn('p022_org_metrics_datas', 'created_by_id')) {
                $table->integer('created_by_id')->unsigned()->nullable();
                $table->foreign('created_by_id', '114896_5a78c57fe86c4')->references('id')->on('users')->onDelete('cascade');
                }
                
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('p022_org_metrics_datas', function(Blueprint $table) {
            
        });
    }
}
