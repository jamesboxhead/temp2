<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Update1518037813UsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('users', function (Blueprint $table) {
            if(! Schema::hasColumn('users', 'deleted_at')) {
                $table->softDeletes();
            }
            
        });
Schema::table('users', function (Blueprint $table) {
            
if (!Schema::hasColumn('users', 'address_line_1')) {
                $table->string('address_line_1')->nullable();
                }
if (!Schema::hasColumn('users', 'address_line_2')) {
                $table->string('address_line_2')->nullable();
                }
if (!Schema::hasColumn('users', 'city')) {
                $table->string('city')->nullable();
                }
if (!Schema::hasColumn('users', 'postcode')) {
                $table->string('postcode')->nullable();
                }
if (!Schema::hasColumn('users', 'map_location_address')) {
                $table->string('map_location_address')->nullable();
                $table->double('map_location_latitude')->nullable();
                $table->double('map_location_longitude')->nullable();
                }
        });

    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('users', function (Blueprint $table) {
            $table->dropColumn('address_line_1');
            $table->dropColumn('address_line_2');
            $table->dropColumn('city');
            $table->dropColumn('postcode');
            $table->dropColumn('map_location_address');
            $table->dropColumn('map_location_latitude');
            $table->dropColumn('map_location_longitude');
            
        });
Schema::table('users', function (Blueprint $table) {
            if(Schema::hasColumn('users', 'deleted_at')) {
                $table->dropColumn('deleted_at');
            }
            
        });

    }
}
