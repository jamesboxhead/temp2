<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Create1517869967P022aOrgMetricsDetailsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        if(! Schema::hasTable('p022a_org_metrics_details')) {
            Schema::create('p022a_org_metrics_details', function (Blueprint $table) {
                $table->increments('id');
                $table->date('result_as_at')->nullable();
                $table->string('p022_result_raw')->nullable();
                $table->string('result_source')->nullable();
                $table->integer('p022_result_value')->nullable();
                $table->string('p022_validation_status')->nullable();
                
                $table->timestamps();
                $table->softDeletes();

                $table->index(['deleted_at']);
            });
        }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('p022a_org_metrics_details');
    }
}
