<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Create1514966584P5hubsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        if(! Schema::hasTable('p5hubs')) {
            Schema::create('p5hubs', function (Blueprint $table) {
                $table->increments('id');
                $table->string('hub_name')->nullable();
                $table->text('hub_description')->nullable();
                $table->string('website')->nullable();
                $table->string('email')->nullable();
                $table->string('logo')->nullable();
                $table->string('address_line_1')->nullable();
                $table->string('address_line_2')->nullable();
                $table->string('city')->nullable();
                $table->string('postcode')->nullable();
                
                $table->timestamps();
                $table->softDeletes();

                $table->index(['deleted_at']);
            });
        }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('p5hubs');
    }
}
