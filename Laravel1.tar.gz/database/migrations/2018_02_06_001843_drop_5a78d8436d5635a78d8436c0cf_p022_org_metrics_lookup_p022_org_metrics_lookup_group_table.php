<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Drop5a78d8436d5635a78d8436c0cfP022OrgMetricsLookupP022OrgMetricsLookupGroupTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::dropIfExists('p022_org_metrics_lookup_p022_org_metrics_lookup_group');
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        if(! Schema::hasTable('p022_org_metrics_lookup_p022_org_metrics_lookup_group')) {
            Schema::create('p022_org_metrics_lookup_p022_org_metrics_lookup_group', function (Blueprint $table) {
                $table->increments('id');
                $table->integer('p022_org_metrics_lookup_id')->unsigned()->nullable();
            $table->foreign('p022_org_metrics_lookup_id', 'fk_p_114894_114895_p022or_5a78c29f6cc76')->references('id')->on('p022_org_metrics_lookups');
                $table->integer('p022_org_metrics_lookup_group_id')->unsigned()->nullable();
            $table->foreign('p022_org_metrics_lookup_group_id', 'fk_p_114895_114894_p022or_5a78c29f6d89f')->references('id')->on('p022_org_metrics_lookup_groups');
                
                $table->timestamps();
                $table->softDeletes();
            });
        }
    }
}
