<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Create1517914369P023DataSubmissionsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        if(! Schema::hasTable('p023_data_submissions')) {
            Schema::create('p023_data_submissions', function (Blueprint $table) {
                $table->increments('id');
                $table->string('submission_code')->nullable();
                $table->date('data_element_as_at')->nullable();
                $table->string('data_element_x_text')->nullable();
                $table->date('data_element_x_date')->nullable();
                $table->integer('data_element_x_num')->nullable();
                $table->string('data_element_x_sort_order')->nullable();
                $table->string('data_element_y_text')->nullable();
                $table->date('data_element_y_date')->nullable();
                $table->integer('data_element_y_num')->nullable();
                $table->string('data_element_label')->nullable();
                
                $table->timestamps();
                $table->softDeletes();

                $table->index(['deleted_at']);
            });
        }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('p023_data_submissions');
    }
}
