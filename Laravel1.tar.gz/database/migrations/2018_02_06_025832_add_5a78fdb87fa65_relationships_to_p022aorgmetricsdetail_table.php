<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Add5a78fdb87fa65RelationshipsToP022aOrgMetricsDetailTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('p022a_org_metrics_details', function(Blueprint $table) {
            if (!Schema::hasColumn('p022a_org_metrics_details', 'result_p5_organisation_id')) {
                $table->integer('result_p5_organisation_id')->unsigned()->nullable();
                $table->foreign('result_p5_organisation_id', '114906_5a78db9198a46')->references('id')->on('p5_organisations')->onDelete('cascade');
                }
                if (!Schema::hasColumn('p022a_org_metrics_details', 'result_p022_org_metrics_lookup_id')) {
                $table->integer('result_p022_org_metrics_lookup_id')->unsigned()->nullable();
                $table->foreign('result_p022_org_metrics_lookup_id', '114906_5a78db91ad39e')->references('id')->on('p022a_org_metrics_items')->onDelete('cascade');
                }
                if (!Schema::hasColumn('p022a_org_metrics_details', 'created_by_id')) {
                $table->integer('created_by_id')->unsigned()->nullable();
                $table->foreign('created_by_id', '114906_5a78db91c0d68')->references('id')->on('users')->onDelete('cascade');
                }
                
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('p022a_org_metrics_details', function(Blueprint $table) {
            
        });
    }
}
