<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Add5a6d7e3653006RelationshipsToP009FieldLevelTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('p009_field_levels', function(Blueprint $table) {
            if (!Schema::hasColumn('p009_field_levels', 'graph_id')) {
                $table->integer('graph_id')->unsigned()->nullable();
                $table->foreign('graph_id', '112067_5a6d76f05b578')->references('id')->on('p009_graphs')->onDelete('cascade');
                }
                if (!Schema::hasColumn('p009_field_levels', 'created_by_id')) {
                $table->integer('created_by_id')->unsigned()->nullable();
                $table->foreign('created_by_id', '112067_5a6d76f069f0c')->references('id')->on('users')->onDelete('cascade');
                }
                
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('p009_field_levels', function(Blueprint $table) {
            
        });
    }
}
