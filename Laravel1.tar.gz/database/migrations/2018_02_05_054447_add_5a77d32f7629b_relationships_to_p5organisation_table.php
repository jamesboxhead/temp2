<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Add5a77d32f7629bRelationshipsToP5OrganisationTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('p5_organisations', function(Blueprint $table) {
            if (!Schema::hasColumn('p5_organisations', 'org_status_id')) {
                $table->integer('org_status_id')->unsigned()->nullable();
                $table->foreign('org_status_id', '103591_5a4dc9aa022cf')->references('id')->on('p5_org_statuses')->onDelete('cascade');
                }
                if (!Schema::hasColumn('p5_organisations', 'state_id')) {
                $table->integer('state_id')->unsigned()->nullable();
                $table->foreign('state_id', '103591_5a4dc8cc5a5ed')->references('id')->on('p5_states')->onDelete('cascade');
                }
                if (!Schema::hasColumn('p5_organisations', 'business_model_id')) {
                $table->integer('business_model_id')->unsigned()->nullable();
                $table->foreign('business_model_id', '103591_5a77d32c37e7e')->references('id')->on('p5_business_models')->onDelete('cascade');
                }
                if (!Schema::hasColumn('p5_organisations', 'p5_anzic_level1_id')) {
                $table->integer('p5_anzic_level1_id')->unsigned()->nullable();
                $table->foreign('p5_anzic_level1_id', '103591_5a77d1394f88c')->references('id')->on('p5_industries')->onDelete('cascade');
                }
                if (!Schema::hasColumn('p5_organisations', 'created_by_id')) {
                $table->integer('created_by_id')->unsigned()->nullable();
                $table->foreign('created_by_id', '103591_5a4dc8cc741b2')->references('id')->on('users')->onDelete('cascade');
                }
                
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('p5_organisations', function(Blueprint $table) {
            
        });
    }
}
